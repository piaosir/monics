/**
 * API Client for interacting with the ADC API
 * Handles communication with the backend server for device control and data acquisition
 * Now with support for both WebSocket and TCP protocols
 */

class ApiClient {
    constructor(baseUrl = CONFIG.API_ENDPOINT) {
        this.baseUrl = baseUrl;
        this.websocket = null;
        this.tcpClient = null;
        this.eventHandlers = {
            'data': [],
            'status': [],
            'error': []
        };
        this.connectionStatus = false;
        this.connectionType = 'websocket'; // 'websocket' or 'tcp'
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 5;
        this.reconnectInterval = 3000; // 3 seconds
    }

    /**
     * Initialize the API client and connection
     * @param {string} connectionType - Type of connection to use ('websocket' or 'tcp')
     * @returns {Promise} Promise resolving when connection is established
     */
    async initialize(connectionType = 'websocket') {
        this.connectionType = connectionType;

        try {
            // Test REST API availability
            const response = await this.get('/status');
            if (response.status !== 'ok') {
                throw new Error('API server is not responding correctly');
            }

            // Setup connection based on type
            if (connectionType === 'websocket') {
                // Setup WebSocket for streaming data
                this.setupWebSocket();
            } else if (connectionType === 'tcp') {
                // Setup TCP connection if TCP client is available
                if (window.TCPClient) {
                    this.tcpClient = new TCPClient();
                    await this.setupTCP();
                } else {
                    throw new Error('TCP client is not available');
                }
            }

            return true;
        } catch (error) {
            console.error('Failed to initialize API client:', error);
            this.dispatchEvent('error', { message: 'Failed to connect to API server' });
            return false;
        }
    }

    /**
     * Set up WebSocket connection for streaming IQ data
     */
    setupWebSocket() {
        this.closeWebSocket(); // Close any existing connection

        try {
            this.websocket = new WebSocket(CONFIG.WEBSOCKET_ENDPOINT);

            // Set binary type for IQ data
            this.websocket.binaryType = 'arraybuffer';

            this.websocket.onopen = () => {
                this.connectionStatus = true;
                this.reconnectAttempts = 0;
                this.dispatchEvent('status', { connected: true });
                console.log('WebSocket connection established');
            };

            this.websocket.onmessage = (event) => {
                try {
                    if (event.data instanceof ArrayBuffer) {
                        // Process binary IQ data
                        const iqData = this.parseIQData(event.data);
                        this.dispatchEvent('data', { iq: iqData });
                    } else {
                        // Process JSON message
                        const data = JSON.parse(event.data);
                        this.dispatchEvent('data', data);
                    }
                } catch (error) {
                    console.error('Error parsing WebSocket data:', error);
                }
            };

            this.websocket.onclose = () => {
                this.connectionStatus = false;
                this.dispatchEvent('status', { connected: false });
                console.log('WebSocket connection closed');

                // Try to reconnect after delay if not max attempts
                if (this.reconnectAttempts < this.maxReconnectAttempts) {
                    this.reconnectAttempts++;
                    setTimeout(() => {
                        if (!this.connectionStatus) {
                            console.log(`Reconnect attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts}`);
                            this.setupWebSocket();
                        }
                    }, this.reconnectInterval);
                } else {
                    console.log('Maximum reconnect attempts reached');
                }
            };

            this.websocket.onerror = (error) => {
                console.error('WebSocket error:', error);
                this.dispatchEvent('error', { message: 'WebSocket connection error' });
            };
        } catch (error) {
            console.error('Failed to setup WebSocket:', error);
        }
    }

    /**
     * Set up TCP client connection
     * @returns {Promise} Promise resolving when TCP connection is established
     */
    async setupTCP() {
        if (!this.tcpClient) {
            throw new Error('TCP client is not initialized');
        }

        // Register TCP event handlers
        this.tcpClient.on('data', (data) => {
            this.dispatchEvent('data', { iq: data });
        });

        this.tcpClient.on('connect', () => {
            this.connectionStatus = true;
            this.reconnectAttempts = 0;
            this.dispatchEvent('status', { connected: true });
            console.log('TCP connection established');
        });

        this.tcpClient.on('disconnect', () => {
            this.connectionStatus = false;
            this.dispatchEvent('status', { connected: false });
            console.log('TCP connection closed');
        });

        this.tcpClient.on('error', (error) => {
            console.error('TCP error:', error);
            this.dispatchEvent('error', { message: `TCP connection error: ${error.message}` });
        });

        // Connect to TCP server
        try {
            await this.tcpClient.connect();
            return true;
        } catch (error) {
            console.error('Failed to connect to TCP server:', error);
            throw error;
        }
    }

    /**
     * Parse binary IQ data from WebSocket
     * @param {ArrayBuffer} buffer - Binary buffer from WebSocket
     * @returns {Object} Parsed IQ data
     */
    parseIQData(buffer) {
        // This implementation depends on the format received from the ADC
        // This is a sample implementation for 16-bit signed integers, little-endian
        const dataView = new DataView(buffer);
        const samplesCount = buffer.byteLength / 4; // Assuming I/Q pairs as 16-bit ints (4 bytes total)

        const iData = new Float32Array(samplesCount);
        const qData = new Float32Array(samplesCount);

        for (let i = 0; i < samplesCount; i++) {
            // Read I/Q samples as 16-bit integers
            const iSample = dataView.getInt16(i * 4, true); // true = little endian
            const qSample = dataView.getInt16(i * 4 + 2, true);

            // Normalize to range [-1, 1]
            iData[i] = iSample / 32768.0;
            qData[i] = qSample / 32768.0;
        }

        return { i: iData, q: qData };
    }

    /**
     * Close WebSocket connection
     */
    closeWebSocket() {
        if (this.websocket && this.websocket.readyState < 2) {
            this.websocket.close();
        }
    }

    /**
     * Close TCP connection
     */
    closeTCP() {
        if (this.tcpClient) {
            this.tcpClient.disconnect();
        }
    }

    /**
     * Close all connections
     */
    closeConnections() {
        this.closeWebSocket();
        this.closeTCP();
    }

    /**
     * Send command via the active connection
     * @param {Object} command - Command to send
     * @returns {boolean} Success status
     */
    sendCommand(command) {
        if (this.connectionType === 'websocket') {
            return this.sendWebSocketCommand(command);
        } else if (this.connectionType === 'tcp') {
            return this.sendTCPCommand(command);
        }
        return false;
    }

    /**
     * Send command via WebSocket
     * @param {Object} command - Command to send
     * @returns {boolean} Success status
     */
    sendWebSocketCommand(command) {
        if (!this.websocket || this.websocket.readyState !== WebSocket.OPEN) {
            console.error('WebSocket is not open');
            return false;
        }

        try {
            this.websocket.send(JSON.stringify(command));
            return true;
        } catch (error) {
            console.error('Error sending WebSocket command:', error);
            return false;
        }
    }

    /**
     * Send command via TCP
     * @param {Object} command - Command to send
     * @returns {boolean} Success status
     */
    sendTCPCommand(command) {
        if (!this.tcpClient || !this.tcpClient.connected) {
            console.error('TCP connection is not open');
            return false;
        }

        try {
            return this.tcpClient.sendCommand(command);
        } catch (error) {
            console.error('Error sending TCP command:', error);
            return false;
        }
    }

    /**
     * Perform GET request to API
     * @param {string} endpoint - API endpoint
     * @param {Object} params - Query parameters
     * @returns {Promise<Object>} Response data
     */
    async get(endpoint, params = {}) {
        const url = new URL(this.baseUrl + endpoint);
        Object.keys(params).forEach(key => {
            url.searchParams.append(key, params[key]);
        });

        try {
            const response = await fetch(url);
            if (!response.ok) {
                throw new Error(`HTTP error ${response.status}`);
            }
            return await response.json();
        } catch (error) {
            console.error(`GET request failed for ${endpoint}:`, error);
            throw error;
        }
    }

    /**
     * Perform POST request to API
     * @param {string} endpoint - API endpoint
     * @param {Object} data - Data to send
     * @returns {Promise<Object>} Response data
     */
    async post(endpoint, data = {}) {
        try {
            const response = await fetch(this.baseUrl + endpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });

            if (!response.ok) {
                throw new Error(`HTTP error ${response.status}`);
            }

            return await response.json();
        } catch (error) {
            console.error(`POST request failed for ${endpoint}:`, error);
            throw error;
        }
    }

    /**
     * Configure device settings
     * @param {Object} settings - Device settings
     * @returns {Promise<Object>} Response data
     */
    async configureDevice(settings) {
        return this.post('/device/configure', settings);
    }

    /**
     * Start data streaming
     * @param {Object} params - Streaming parameters
     * @returns {Promise<Object>} Response data
     */
    async startStreaming(params) {
        return this.post('/device/stream/start', params);
    }

    /**
     * Stop data streaming
     * @returns {Promise<Object>} Response data
     */
    async stopStreaming() {
        return this.post('/device/stream/stop');
    }

    /**
     * Get available devices
     * @returns {Promise<Array>} List of available devices
     */
    async getAvailableDevices() {
        return this.get('/device/list');
    }

    /**
     * Register event handler
     * @param {string} event - Event name
     * @param {Function} callback - Event callback
     */
    on(event, callback) {
        if (!this.eventHandlers[event]) {
            this.eventHandlers[event] = [];
        }
        this.eventHandlers[event].push(callback);
    }

    /**
     * Unregister event handler
     * @param {string} event - Event name
     * @param {Function} callback - Event callback
     */
    off(event, callback) {
        if (this.eventHandlers[event]) {
            this.eventHandlers[event] = this.eventHandlers[event].filter(cb => cb !== callback);
        }
    }

    /**
     * Dispatch event to registered handlers
     * @param {string} event - Event name
     * @param {Object} data - Event data
     */
    dispatchEvent(event, data) {
        if (this.eventHandlers[event]) {
            this.eventHandlers[event].forEach(callback => {
                try {
                    callback(data);
                } catch (error) {
                    console.error('Error in event handler:', error);
                }
            });
        }
    }

    /**
     * Get connection status
     * @returns {boolean} Connection status
     */
    isConnected() {
        return this.connectionStatus;
    }

    /**
     * Get connection type
     * @returns {string} Connection type ('websocket' or 'tcp')
     */
    getConnectionType() {
        return this.connectionType;
    }

    /**
     * Set connection type
     * @param {string} type - Connection type ('websocket' or 'tcp')
     */
    setConnectionType(type) {
        if (type === 'websocket' || type === 'tcp') {
            this.connectionType = type;
        }
    }
}

// Export singleton instance
const apiClient = new ApiClient();