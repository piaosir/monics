/**
 * Carrier Analyzer for satellite signal analysis
 * Detects and analyzes carriers in the spectrum
 */

class CarrierAnalyzer {
    constructor() {
        this.threshold = CONFIG.CARRIER.DEFAULT_THRESHOLD;
        this.minSnrForAnalysis = CONFIG.CARRIER.MIN_SNR_FOR_ANALYSIS;
        this.carriers = [];
        this.frequencyData = null;
        this.powerData = null;
        this.sampleRate = CONFIG.DEVICE.DEFAULT_SAMPLE_RATE * 1e6;
        this.centerFreq = CONFIG.DEVICE.DEFAULT_CENTER_FREQ * 1e6;
    }

    /**
     * Set detection threshold
     * @param {number} threshold - Detection threshold in dBm
     */
    setThreshold(threshold) {
        this.threshold = threshold;
    }

    /**
     * Set sample rate
     * @param {number} sampleRate - Sample rate in Hz
     */
    setSampleRate(sampleRate) {
        this.sampleRate = sampleRate;
    }

    /**
     * Set center frequency
     * @param {number} centerFreq - Center frequency in Hz
     */
    setCenterFrequency(centerFreq) {
        this.centerFreq = centerFreq;
    }

    /**
     * Analyze spectrum for carriers
     * @param {Array} frequencyData - Frequency data in Hz
     * @param {Array} powerData - Power spectrum data in dBm
     * @param {Object} iqData - IQ data for detailed analysis
     * @returns {Array} Detected carriers
     */
    analyzeSpectrum(frequencyData, powerData, iqData) {
        this.frequencyData = frequencyData;
        this.powerData = powerData;
        
        // Reset carriers
        this.carriers = [];
        
        // Get noise floor
        const noiseFloor = DSPUtils.estimateNoiseFloor(powerData);
        
        // Find significant peaks
        const peaks = DSPUtils.findPeaks(powerData, this.threshold - noiseFloor);
        
        // Process each peak as a potential carrier
        for (const peak of peaks) {
            if (peak.value < this.threshold) continue;
            
            // Get frequency of the peak
            const peakFreq = frequencyData[peak.index];
            
            // Calculate SNR
            const snr = DSPUtils.calculateSNR(powerData, peak.index);
            
            // Create carrier entry
            const carrier = {
                frequency: peakFreq,
                power: peak.value,
                snr: snr,
                bandwidth: this.estimateCarrierBandwidth(peak.index, powerData, frequencyData, noiseFloor + 3)
            };
            
            // Perform detailed analysis if SNR is sufficient
            if (snr >= this.minSnrForAnalysis && iqData) {
                this.analyzeCarrierDetails(carrier, iqData, peak.index, frequencyData);
            }
            
            // Add to carriers
            this.carriers.push(carrier);
        }
        
        return this.carriers;
    }

    /**
     * Estimate carrier bandwidth
     * @param {number} peakIndex - Peak index
     * @param {Array} powerData - Power data
     * @param {Array} frequencyData - Frequency data
     * @param {number} threshold - Power threshold for bandwidth estimation
     * @returns {number} Bandwidth in Hz
     */
    estimateCarrierBandwidth(peakIndex, powerData, frequencyData, threshold) {
        // Find lower frequency bound (3dB below peak)
        let lowerIndex = peakIndex;
        while (lowerIndex > 0 && powerData[lowerIndex] > threshold) {
            lowerIndex--;
        }
        
        // Find upper frequency bound
        let upperIndex = peakIndex;
        while (upperIndex < powerData.length - 1 && powerData[upperIndex] > threshold) {
            upperIndex++;
        }
        
        // Calculate bandwidth
        return frequencyData[upperIndex] - frequencyData[lowerIndex];
    }

    /**
     * Analyze carrier details using IQ data
     * @param {Object} carrier - Carrier object to update
     * @param {Object} iqData - IQ data
     * @param {number} peakIndex - Index of the peak in frequency data
     * @param {Array} frequencyData - Frequency data
     */
    analyzeCarrierDetails(carrier, iqData, peakIndex, frequencyData) {
        // This is a simplified carrier analysis
        // In a real implementation, this would perform:
        // - Symbol rate estimation
        // - Modulation type detection
        // - FEC rate estimation
        // - Frequency offset measurement
        
        // Extract the relevant portion of the spectrum (filter around carrier)
        const centerFreq = carrier.frequency;
        
        // Estimate symbol rate from bandwidth
        // This is a rough approximation that works for many digital modulations
        // Assumes bandwidth is approximately equal to symbol rate (QPSK case)
        const symbolRate = carrier.bandwidth * 0.8; // 80% of occupied bandwidth is a common approximation
        
        // Estimate Es/N0 from SNR and modulation
        // For QPSK, Es/N0 ≈ SNR
        const esn0 = carrier.snr;
        
        // Estimate C/N (carrier-to-noise ratio)
        const cn = carrier.snr + 10 * Math.log10(carrier.bandwidth / this.sampleRate);
        
        // Try to determine modulation type
        const modulation = this.estimateModulationType(carrier, iqData, frequencyData, peakIndex);
        
        // Update carrier with detailed analysis
        carrier.symbolRate = symbolRate;
        carrier.esn0 = esn0;
        carrier.cn = cn;
        carrier.modulation = modulation;
        
        // Estimate frequency offset (difference from expected center)
        const freqRes = (frequencyData[1] - frequencyData[0]);
        const fractionalBin = this.estimateFractionalBinOffset(powerData, peakIndex);
        carrier.frequencyOffset = fractionalBin * freqRes;
    }

    /**
     * Estimate the fractional bin offset of a peak for more accurate frequency estimation
     * @param {Array} powerData - Power spectrum data
     * @param {number} peakIndex - Index of peak in power data
     * @returns {number} Fractional bin offset (-0.5 to 0.5)
     */
    estimateFractionalBinOffset(powerData, peakIndex) {
        // Skip if peak is at the edge of the spectrum
        if (peakIndex <= 0 || peakIndex >= powerData.length - 1) {
            return 0;
        }
        
        // Use parabolic interpolation for better frequency estimation
        const y1 = powerData[peakIndex - 1];
        const y2 = powerData[peakIndex];
        const y3 = powerData[peakIndex + 1];
        
        // Calculate fractional bin offset using quadratic interpolation
        const delta = (y3 - y1) / (2 * (2 * y2 - y1 - y3));
        
        // Limit to reasonable range
        return Math.max(-0.5, Math.min(0.5, delta));
    }

    /**
     * Estimate modulation type from carrier parameters
     * @param {Object} carrier - Carrier object
     * @param {Object} iqData - IQ data
     * @param {Array} frequencyData - Frequency data 
     * @param {number} peakIndex - Peak index
     * @returns {string} Modulation type
     */
    estimateModulationType(carrier, iqData, frequencyData, peakIndex) {
        // This is a simplified modulation detection algorithm
        // In a real implementation, it would use more sophisticated techniques
        
        // Use bandwidth efficiency as a simple metric
        // bandwidth_efficiency = symbol_rate / bandwidth
        const bandwidthEfficiency = 0.8; // Assuming symbol rate is 80% of bandwidth
        
        if (bandwidthEfficiency < 0.5) {
            return 'BPSK';
        } else if (bandwidthEfficiency < 0.9) {
            return 'QPSK';
        } else if (bandwidthEfficiency < 1.5) {
            return '8PSK';
        } else if (bandwidthEfficiency < 2.5) {
            return '16QAM';
        } else if (bandwidthEfficiency < 4.0) {
            return '64QAM';
        } else {
            return '256QAM';
        }
    }

    /**
     * Get detailed analysis results for a specific carrier
     * @param {number} index - Carrier index
     * @returns {Object} Carrier analysis results
     */
    getCarrierAnalysis(index) {
        if (index < 0 || index >= this.carriers.length) {
            return null;
        }
        
        const carrier = this.carriers[index];
        
        // Format carrier data for display
        return {
            frequency: (carrier.frequency / 1e6).toFixed(6) + ' MHz',
            power: carrier.power.toFixed(2) + ' dBm',
            bandwidth: (carrier.bandwidth / 1e3).toFixed(2) + ' kHz',
            symbolRate: carrier.symbolRate ? (carrier.symbolRate / 1e3).toFixed(2) + ' ksps' : 'N/A',
            modulation: carrier.modulation || 'Unknown',
            snr: carrier.snr.toFixed(2) + ' dB',
            esn0: carrier.esn0 ? carrier.esn0.toFixed(2) + ' dB' : 'N/A',
            cn: carrier.cn ? carrier.cn.toFixed(2) + ' dB' : 'N/A',
            frequencyOffset: carrier.frequencyOffset ? 
                (carrier.frequencyOffset / 1e3).toFixed(2) + ' kHz' : 'N/A'
        };
    }

    /**
     * Get all carriers
     * @returns {Array} All detected carriers
     */
    getCarriers() {
        return this.carriers;
    }
}