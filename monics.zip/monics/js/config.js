/**
 * Configuration file for GEO Satellite Digital Spectrum Analyzer
 * Contains global settings and constants used throughout the application
 */

const CONFIG = {
    // API and WebSocket connections
    API_ENDPOINT: 'http://localhost:3000/api',
    WEBSOCKET_ENDPOINT: 'ws://localhost:3000/ws',

    // TCP connection settings
    TCP: {
        ENABLED: true,
        SERVER: 'localhost',
        PORT: 8888,
        BUFFER_SIZE: 65536,
        RECONNECT_INTERVAL: 3000, // ms
        DATA_FORMAT: 'int16',     // 'int16', 'float32', 'int8'
        ENDIANNESS: 'little',     // 'little' or 'big'
        TIMEOUT: 5000             // connection timeout (ms)
    },
    // �������˲�������
    BANDWIDTH: {
        DEFAULT_BANDWIDTH: 250,    // MHz
        MIN_BANDWIDTH: 1,         // MHz
        MAX_BANDWIDTH: 500,       // MHz
        CUSTOM_PRESETS: [10, 25, 50, 100, 250, 500],

        // �ֱ���� (Resolution Bandwidth) ����
        DEFAULT_RBW: 10,          // kHz
        RBW_PRESETS: [1, 3, 10, 30, 100, 300, 1000],
        AUTO_RBW: true,           // �Զ�����RBW

        // ��Ƶ���� (Video Bandwidth) ����
        DEFAULT_VBW: 10,          // kHz
        VBW_PRESETS: [1, 3, 10, 30, 100, 300, 1000],
        AUTO_VBW: true,           // �Զ�����VBW
        VBW_RBW_RATIO: 1          // VBW/RBW����
    },
    // Default device settings
    DEVICE: {
        DEFAULT_DEVICE_TYPE: 'AD9361',
        DEFAULT_SAMPLE_RATE: 245.76, // MSPS
        DEFAULT_CENTER_FREQ: 1500,   // MHz
        DEFAULT_GAIN_MODE: 'auto',
        DEFAULT_GAIN_VALUE: 50,      // dB
        SUPPORTED_DEVICES: {
            'AD9361': {
                MAX_SAMPLE_RATE: 61.44,
                MAX_BW: 56,
                FREQ_RANGE: [70, 6000]
            },
            'AD9363': {
                MAX_SAMPLE_RATE: 61.44,
                MAX_BW: 56,
                FREQ_RANGE: [325, 3800]
            },
            'AD9364': {
                MAX_SAMPLE_RATE: 61.44,
                MAX_BW: 56,
                FREQ_RANGE: [70, 6000]
            },
            'AD9371': {
                MAX_SAMPLE_RATE: 122.88,
                MAX_BW: 100,
                FREQ_RANGE: [300, 6000]
            },
            'ADRV9002': {
                MAX_SAMPLE_RATE: 245.76,
                MAX_BW: 200,
                FREQ_RANGE: [30, 6000]
            },
            'AD9680': {
                MAX_SAMPLE_RATE: 1000,
                MAX_BW: 500,
                FREQ_RANGE: [0, 2000]
            },
            'AD9625': {
                MAX_SAMPLE_RATE: 2500,
                MAX_BW: 1200,
                FREQ_RANGE: [0, 3000]
            },
            'AD9208': {
                MAX_SAMPLE_RATE: 3000,
                MAX_BW: 1500,
                FREQ_RANGE: [0, 4000]
            },
            'ADS54J60': {
                MAX_SAMPLE_RATE: 1000,
                MAX_BW: 500,
                FREQ_RANGE: [0, 2000]
            },
            'LTC2000': {
                MAX_SAMPLE_RATE: 2500,
                MAX_BW: 1200,
                FREQ_RANGE: [0, 3000]
            }
        }
    },

    // Default spectrum display settings
    SPECTRUM: {
        DEFAULT_SPAN: 250,          // MHz
        DEFAULT_RBW: 10,            // kHz
        DEFAULT_FFT_SIZE: 4096,     // points
        DEFAULT_WINDOW: 'hann',
        DEFAULT_DISPLAY_MODE: 'normal',
        DEFAULT_DYNAMIC_RANGE: 70,  // dB
        DEFAULT_REF_LEVEL: 0,       // dBm
        MAX_MARKERS: 8,
        AVAILABLE_WINDOWS: ['rectangular', 'hann', 'hamming', 'blackman', 'flattop'],
        DISPLAY_MODES: ['normal', 'max-hold', 'average', 'min-max']
    },

    // Default waterfall display settings
    WATERFALL: {
        DEFAULT_TIME_SPAN: 60,      // seconds
        DEFAULT_COLOR_MAP: 'viridis',
        DEFAULT_RESOLUTION: 512,    // time resolution
        COLOR_MAPS: ['viridis', 'jet', 'hot', 'cool', 'gray']
    },

    // Default constellation display settings
    CONSTELLATION: {
        DEFAULT_MODULATION: 'auto',
        DEFAULT_POINTS: 1000,
        SUPPORTED_MODULATIONS: ['BPSK', 'QPSK', '8PSK', '16QAM', '32QAM', '64QAM', '256QAM']
    },

    // Default interference analyzer settings
    INTERFERENCE: {
        DEFAULT_DETECTION_THRESHOLD: -40, // dBm
        DEFAULT_SENSITIVITY: 'medium',
        DETECTION_TYPES: ['CW', 'Pulsed', 'Sweep', 'WBFM', 'CDMA', 'Adjacent']
    },

    // Default carrier analyzer settings
    CARRIER: {
        DEFAULT_THRESHOLD: -30,     // dBm
        MIN_SNR_FOR_ANALYSIS: 10,   // dB
        SUPPORTED_ANALYSIS: ['symbol_rate', 'bandwidth', 'power', 'frequency_offset']
    },

    // Default data export settings
    EXPORT: {
        DEFAULT_FORMAT: 'csv',
        FORMATS: ['csv', 'json', 'binary', 'raw_iq'],
        DEFAULT_DIR: './exports'
    },

    // UI settings
    UI: {
        UPDATE_INTERVAL: 100,       // ms
        NOTIFICATION_TIMEOUT: 3000, // ms
        DEFAULT_THEME: 'dark',
        THEMES: ['dark', 'light', 'blue']
    },

    // Modulation analyzer settings
    MODULATION: {
        AUTOMATIC_RECOGNITION: true,
        DEFAULT_SYMBOL_RATE: 1,     // Msym/s
        MIN_CONSTELLATION_POINTS: 100
    },

    // ADC settings
    ADC: {
        SUPPORTED_FORMATS: ['int8', 'int16', 'int32', 'float32'],
        DEFAULT_FORMAT: 'int16',
        SUPPORTED_ENDIANNESS: ['little', 'big'],
        DEFAULT_ENDIANNESS: 'little',
        MAX_BUFFER_SIZE: 1048576,   // 1MB
        BITS_PER_SAMPLE: {
            'int8': 8,
            'int16': 16,
            'int32': 32,
            'float32': 32
        }
    },

    // Recording settings
    RECORDING: {
        MAX_DURATION: 3600,         // seconds
        DEFAULT_DURATION: 10,       // seconds
        MAX_FILE_SIZE: 1073741824,  // 1GB
        FORMATS: ['binary', 'wav', 'siq', 'csv'],
        DEFAULT_FORMAT: 'binary'
    }
};

// Prevent accidental modification of the configuration
Object.freeze(CONFIG);