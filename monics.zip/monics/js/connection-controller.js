/**
 * 连接配置控制器 - 处理不同类型设备的连接和状态管理
 */
class ConnectionController {
    constructor() {
        this.currentConnectionType = 'tcp';
        this.currentDeviceType = 'AD9361';
        this.isConnected = false;
        this.isConnecting = false;
        this.connectionStatus = 'disconnected';
        this.connectionInfo = {};
        
        // 设备协议映射
        this.deviceProtocols = {
            'GE7800': 'ge7800',
            'TA8030': 'ta8030',
            'HT8200': 'ht8200',
            'HL8600': 'standard',
            'HD9010': 'standard',
            'FM3250': 'standard',
            'AD9361': 'standard',
            'AD9363': 'standard',
            'AD9364': 'standard',
            'AD9371': 'standard'
        };
        
        // 设备特有参数映射
        this.deviceSpecificParams = {
            'GE7800': {
                defaultPort: 7800,
                dataFormat: 'int16',
                headerSize: 16,
                commandSequence: [0xAA, 0xBB, 0xCC, 0xDD]
            },
            'TA8030': {
                defaultPort: 8030,
                dataFormat: 'int16',
                headerSize: 8,
                commandSequence: [0xA0, 0x00, 0x00, 0x00]
            },
            'HT8200': {
                defaultPort: 8200,
                dataFormat: 'float32',
                headerSize: 12,
                commandSequence: [0x48, 0x54, 0x82, 0x00]
            },
            'HL8600': {
                defaultPort: 8600,
                dataFormat: 'int16',
                headerSize: 4,
                commandSequence: [0xAB, 0xCD, 0xEF, 0x01]
            },
            'HD9010': {
                defaultPort: 9010,
                dataFormat: 'int16',
                headerSize: 0,
                commandSequence: [0x00, 0x01, 0x02, 0x03]
            },
            'FM3250': {
                defaultPort: 3250,
                dataFormat: 'int16',
                headerSize: 0,
                commandSequence: []
            },
            'AD9361': {
                defaultPort: 8080,
                dataFormat: 'int16',
                headerSize: 0,
                commandSequence: []
            }
        };
    }
    
    /**
     * 初始化连接控制器
     * @param {SDRDevice} device - 设备对象
     * @param {TCPClient} tcpClient - TCP客户端对象
     * @param {Object} apiClient - API客户端对象
     * @param {UIController} uiController - UI控制器对象
     */
    initialize(device, tcpClient, apiClient, uiController) {
        this.device = device;
        this.tcpClient = tcpClient;
        this.apiClient = apiClient;
        this.uiController = uiController;
        
        // 初始化事件监听器
        this.initEventListeners();
    }
    
    /**
     * 初始化事件监听器
     */
    initEventListeners() {
        // 连接方式选择变更
        document.getElementById('connectionMethod').addEventListener('change', () => this.onConnectionMethodChange());
        
        // 设备类型选择变更
        document.getElementById('deviceType').addEventListener('change', () => this.onDeviceTypeChange());
        
        // 协议格式变更
        document.getElementById('tcpProtocol').addEventListener('change', () => this.onProtocolChange());
        
        // 测试连接按钮
        document.getElementById('testConnectionBtn').addEventListener('click', () => this.testConnection());
        
        // 连接按钮
        document.getElementById('connectBtn').addEventListener('click', () => this.connect());
        
        // 断开按钮
        document.getElementById('disconnectBtn').addEventListener('click', () => this.disconnect());
    }
    
    /**
     * 连接方式变更事件处理
     */
    onConnectionMethodChange() {
        const connectionMethod = document.getElementById('connectionMethod').value;
        this.currentConnectionType = connectionMethod;
        
        // 隐藏所有连接设置面板
        const connectionSettings = document.querySelectorAll('.connection-settings');
        connectionSettings.forEach(setting => setting.style.display = 'none');
        
        // 显示当前选择的连接设置面板
        const currentSettings = document.getElementById(`${connectionMethod}Settings`);
        if (currentSettings) {
            currentSettings.style.display = 'block';
        }
        
        // 更新状态显示
        this.updateStatusDisplay();
    }
    
    /**
     * 设备类型变更事件处理
     */
    onDeviceTypeChange() {
        const deviceType = document.getElementById('deviceType').value;
        this.currentDeviceType = deviceType;
        
        // 获取设备特定参数
        const deviceParams = this.deviceSpecificParams[deviceType] || {};
        
        // 自动设置相关参数
        if (this.currentConnectionType === 'tcp') {
            document.getElementById('tcpPort').value = deviceParams.defaultPort || 8080;
            document.getElementById('tcpFormat').value = deviceParams.dataFormat || 'int16';
            
            // 更新协议选择
            const protocol = this.deviceProtocols[deviceType] || 'standard';
            document.getElementById('tcpProtocol').value = protocol;
        }
        
        // 更新设备特定参数区域
        this.updateDeviceSpecificParams();
        
        // 更新状态显示
        this.updateStatusDisplay();
    }
    
    /**
     * 协议变更事件处理
     */
    onProtocolChange() {
        const protocol = document.getElementById('tcpProtocol').value;
        
        // 移除旧的设备特定参数区域
        const existingParams = document.getElementById('deviceSpecificParams');
        if (existingParams) {
            existingParams.remove();
        }
        
        // 如果选择自定义协议，添加自定义协议参数输入
        if (protocol === 'custom') {
            this.addCustomProtocolParams();
        } else {
            this.updateDeviceSpecificParams();
        }
    }
    
    /**
     * 添加自定义协议参数输入区域
     */
    addCustomProtocolParams() {
        // 获取TCP设置容器
        const tcpSettings = document.getElementById('tcpSettings');
        
        // 创建自定义协议参数区域
        const customParams = document.createElement('div');
        customParams.id = 'deviceSpecificParams';
        customParams.className = 'device-specific-params';
        
        customParams.innerHTML = `
            <h4>自定义协议参数</h4>
            <div class="additional-params">
                <table>
                    <tr>
                        <td>头部大小(字节):</td>
                        <td><input type="number" id="customHeaderSize" min="0" value="0"></td>
                    </tr>
                    <tr>
                        <td>命令序列(十六进制):</td>
                        <td><input type="text" id="customCommandSequence" placeholder="例如: AA BB CC DD"></td>
                    </tr>
                    <tr>
                        <td>数据起始标记:</td>
                        <td><input type="text" id="customDataMarker" placeholder="例如: ABCD1234"></td>
                    </tr>
                    <tr>
                        <td>数据包大小字段偏移:</td>
                        <td><input type="number" id="customSizeOffset" min="0" value="0"></td>
                    </tr>
                </table>
            </div>
        `;
        
        // 添加到TCP设置容器
        tcpSettings.appendChild(customParams);
    }
    
    /**
     * 更新设备特定参数区域
     */
    updateDeviceSpecificParams() {
        // 获取设备信息
        const deviceType = this.currentDeviceType;
        const deviceParams = this.deviceSpecificParams[deviceType] || {};
        const protocol = this.deviceProtocols[deviceType] || 'standard';
        
        // 移除旧的设备特定参数区域
        const existingParams = document.getElementById('deviceSpecificParams');
        if (existingParams) {
            existingParams.remove();
        }
        
        // 如果不是标准协议，添加设备特定参数
        if (protocol !== 'standard') {
            // 获取TCP设置容器
            const tcpSettings = document.getElementById('tcpSettings');
            
            // 创建设备特定参数区域
            const specificParams = document.createElement('div');
            specificParams.id = 'deviceSpecificParams';
            specificParams.className = 'device-specific-params';
            
            specificParams.innerHTML = `
                <h4>${deviceType} 专用参数</h4>
                <div class="additional-params">
                    <table>
                        <tr>
                            <td>头部大小:</td>
                            <td>${deviceParams.headerSize || 0} 字节</td>
                        </tr>
                        <tr>
                            <td>命令序列:</td>
                            <td>${deviceParams.commandSequence ? this.formatHexArray(deviceParams.commandSequence) : '无'}</td>
                        </tr>
                        ${this.getDeviceSpecificConfigHtml(deviceType)}
                    </table>
                </div>
            `;
            
            // 添加到TCP设置容器
            tcpSettings.appendChild(specificParams);
        }
    }
    
    /**
     * 获取设备特定配置的HTML
     * @param {string} deviceType - 设备类型
     * @returns {string} HTML字符串
     */
    getDeviceSpecificConfigHtml(deviceType) {
        // 不同设备的特定配置项
        switch(deviceType) {
            case 'GE7800':
                return `
                    <tr>
                        <td>CAS-ID:</td>
                        <td><input type="text" id="ge7800CasId" value="0001"></td>
                    </tr>
                    <tr>
                        <td>支持硬件解码:</td>
                        <td>
                            <select id="ge7800HwDecode">
                                <option value="true">是</option>
                                <option value="false">否</option>
                            </select>
                        </td>
                    </tr>
                `;
            case 'TA8030':
                return `
                    <tr>
                        <td>设备ID:</td>
                        <td><input type="number" id="ta8030DeviceId" value="1"></td>
                    </tr>
                    <tr>
                        <td>自动ACK:</td>
                        <td>
                            <select id="ta8030AutoAck">
                                <option value="true">启用</option>
                                <option value="false">禁用</option>
                            </select>
                        </td>
                    </tr>
                `;
            case 'HT8200':
                return `
                    <tr>
                        <td>传输模式:</td>
                        <td>
                            <select id="ht8200TransferMode">
                                <option value="continuous">连续传输</option>
                                <option value="packet">数据包模式</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>分片大小(字节):</td>
                        <td><input type="number" id="ht8200ChunkSize" value="8192"></td>
                    </tr>
                `;
            default:
                return '';
        }
    }
    
    /**
     * 格式化十六进制数组为可读字符串
     * @param {Array} hexArray - 十六进制数组
     * @returns {string} 格式化后的字符串
     */
    formatHexArray(hexArray) {
        if (!hexArray || hexArray.length === 0) return '无';
        return hexArray.map(byte => byte.toString(16).padStart(2, '0').toUpperCase()).join(' ');
    }
    
    /**
     * 测试连接
     */
    async testConnection() {
        // 更新UI状态
        const statusDot = document.getElementById('connectionStatusDot');
        const statusText = document.getElementById('connectionStatusText');
        statusDot.className = 'status-dot connecting';
        statusText.textContent = '测试连接中...';
        
        // 移除之前的测试结果
        const existingResult = document.querySelector('.connection-test-result');
        if (existingResult) {
            existingResult.remove();
        }
        
        // 获取连接参数
        const connectionParams = this.getConnectionParams();
        
        try {
            let testResult;
            
            // 根据连接方式测试连接
            switch(this.currentConnectionType) {
                case 'tcp':
                    testResult = await this.testTcpConnection(connectionParams);
                    break;
                case 'api':
                    testResult = await this.testApiConnection(connectionParams);
                    break;
                case 'udp':
                    testResult = await this.testUdpConnection(connectionParams);
                    break;
                case 'usb':
                    testResult = await this.testUsbConnection(connectionParams);
                    break;
                default:
                    throw new Error(`不支持的连接方式: ${this.currentConnectionType}`);
            }
            
            // 更新UI状态
            statusDot.className = 'status-dot';
            statusText.textContent = '未连接';
            
            // 显示测试结果
            this.showConnectionTestResult(testResult.success, testResult.message, testResult.details);
        } catch (error) {
            // 更新UI状态
            statusDot.className = 'status-dot';
            statusText.textContent = '未连接';
            
            // 显示错误信息
            this.showConnectionTestResult(false, '连接测试失败', error.message);
        }
    }
    
    /**
     * 测试TCP连接
     * @param {Object} params - 连接参数
     * @returns {Object} 测试结果
     */
    async testTcpConnection(params) {
        return new Promise((resolve, reject) => {
            // 创建临时TCP连接进行测试
            const tempTcpClient = new TCPClient();
            
            // 设置超时
            const timeout = setTimeout(() => {
                tempTcpClient.disconnect();
                reject(new Error('连接超时，请检查地址和端口是否正确'));
            }, 5000);
            
            // 测试连接
            tempTcpClient.on('connect', () => {
                clearTimeout(timeout);
                
                // 尝试获取设备信息
                tempTcpClient.sendCommand({
                    command: 'getInfo',
                    deviceType: this.currentDeviceType,
                    protocol: params.protocol
                });
                
                // 设置数据接收超时
                setTimeout(() => {
                    tempTcpClient.disconnect();
                    resolve({
                        success: true,
                        message: '连接成功，但未能获取设备信息',
                        details: '服务器接受了连接，但未返回设备信息响应'
                    });
                }, 2000);
            });
            
            tempTcpClient.on('data', (data) => {
                clearTimeout(timeout);
                tempTcpClient.disconnect();
                
                // 尝试解析设备信息
                let deviceInfo;
                try {
                    deviceInfo = this.parseDeviceInfo(data, params.protocol);
                } catch (e) {
                    deviceInfo = { type: '未知', sampleRates: ['未知'], status: 'ready' };
                }
                
                resolve({
                    success: true,
                    message: '连接成功，接收到设备响应',
                    details: `设备类型: ${deviceInfo.type}, 状态: ${deviceInfo.status || 'ready'}`
                });
            });
            
            tempTcpClient.on('error', (error) => {
                clearTimeout(timeout);
                tempTcpClient.disconnect();
                reject(error);
            });
            
            // 开始连接
            tempTcpClient.connect(params.server, params.port).catch(reject);
        });
    }
    
    /**
     * 测试API连接
     * @param {Object} params - 连接参数
     * @returns {Object} 测试结果
     */
    async testApiConnection(params) {
        // 使用临时API客户端测试连接
        const apiEndpoint = params.apiEndpoint;
        
        try {
            // 发送测试请求
            const response = await fetch(`${apiEndpoint}/info`, {
                method: 'GET',
                timeout: 5000
            });
            
            if (!response.ok) {
                throw new Error(`API服务器返回错误代码: ${response.status}`);
            }
            
            const data = await response.json();
            
            return {
                success: true,
                message: 'API连接成功',
                details: `服务器版本: ${data.version || 'unknown'}, 设备支持: ${data.devices?.join(', ') || 'unknown'}`
            };
        } catch (error) {
            throw new Error(`API连接失败: ${error.message}`);
        }
    }
    
    /**
     * 测试UDP连接
     * @param {Object} params - 连接参数
     * @returns {Object} 测试结果
     */
    async testUdpConnection(params) {
        // UDP测试通常只能发送数据，无法确认连接状态
        // 这里我们模拟一个测试过程
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve({
                    success: true,
                    message: 'UDP端口可用',
                    details: `UDP通信已配置为${params.server}:${params.port}，但无法测试远程主机是否接收`
                });
            }, 1000);
        });
    }
    
    /**
     * 测试USB连接
     * @param {Object} params - 连接参数
     * @returns {Object} 测试结果
     */
    async testUsbConnection(params) {
        // 如果浏览器支持WebUSB API
        if (navigator.usb) {
            try {
                // 检查是否已授权访问设备
                const devices = await navigator.usb.getDevices();
                const device = devices.find(d => 
                    d.vendorId === parseInt(params.vendorId, 16) && 
                    d.productId === parseInt(params.productId, 16)
                );
                
                if (device) {
                    return {
                        success: true,
                        message: 'USB设备已授权',
                        details: `设备名称: ${device.productName || 'unknown'}`
                    };
                } else {
                    return {
                        success: false,
                        message: '未找到授权的USB设备',
                        details: '请点击连接按钮并在弹出的对话框中选择设备'
                    };
                }
            } catch (error) {
                throw new Error(`USB设备访问错误: ${error.message}`);
            }
        } else {
            throw new Error('当前浏览器不支持WebUSB API，无法使用USB连接');
        }
    }
    
    /**
     * 显示连接测试结果
     * @param {boolean} success - 是否成功
     * @param {string} message - 消息
     * @param {string} details - 详细信息
     */
    showConnectionTestResult(success, message, details) {
        // 创建结果元素
        const resultElement = document.createElement('div');
        resultElement.className = `connection-test-result ${success ? 'success' : 'error'}`;
        
        resultElement.innerHTML = `
            <strong>${message}</strong>
            <p>${details || ''}</p>
        `;
        
        // 添加到连接状态面板
        const statusPanel = document.querySelector('.connection-status-panel');
        statusPanel.appendChild(resultElement);
    }
    
    /**
     * 执行设备连接
     */
    async connect() {
        // 如果已连接，请先断开
        if (this.isConnected) {
            await this.disconnect();
        }
        
        // 更新UI状态
        const statusDot = document.getElementById('connectionStatusDot');
        const statusText = document.getElementById('connectionStatusText');
        const connectBtn = document.getElementById('connectBtn');
        const disconnectBtn = document.getElementById('disconnectBtn');
        
        statusDot.className = 'status-dot connecting';
        statusText.textContent = '正在连接...';
        connectBtn.disabled = true;
        this.isConnecting = true;
        
        // 移除之前的测试结果
        const existingResult = document.querySelector('.connection-test-result');
        if (existingResult) {
            existingResult.remove();
        }
        
        // 获取连接参数
        const connectionParams = this.getConnectionParams();
        
        try {
            // 记录连接开始时间
            const startTime = Date.now();
            
            // 根据连接方式执行连接
            switch(this.currentConnectionType) {
                case 'tcp':
                    await this.connectTcp(connectionParams);
                    break;
                case 'api':
                    await this.connectApi(connectionParams);
                    break;
                case 'udp':
                    await this.connectUdp(connectionParams);
                    break;
                case 'usb':
                    await this.connectUsb(connectionParams);
                    break;
                default:
                    throw new Error(`不支持的连接方式: ${this.currentConnectionType}`);
            }
            
            // 连接成功
            const connectionTime = Date.now() - startTime;
            
            // 更新连接状态
            this.isConnected = true;
            this.isConnecting = false;
            this.connectionStatus = 'connected';
            this.connectionInfo = {
                deviceType: this.currentDeviceType,
                connectionType: this.currentConnectionType,
                ...connectionParams,
                connectedAt: new Date().toISOString(),
                connectionTime: connectionTime
            };
            
            // 更新UI状态
            statusDot.className = 'status-dot connected';
            statusText.textContent = '已连接';
            connectBtn.disabled = false;
            disconnectBtn.disabled = false;
            
            // 更新连接信息显示
            this.updateConnectionInfoDisplay();
            
            // 显示成功通知
            this.uiController.showNotification('设备连接成功', 'success');
        } catch (error) {
            // 连接失败
            this.isConnecting = false;
            
            // 更新UI状态
            statusDot.className = 'status-dot error';
            statusText.textContent = '连接失败';
            connectBtn.disabled = false;
            
            // 显示错误信息
            this.showConnectionTestResult(false, '连接失败', error.message);
            
            // 显示错误通知
            this.uiController.showNotification(`连接失败: ${error.message}`, 'error');
        }
    }
    
    /**
     * 执行TCP连接
     * @param {Object} params - 连接参数
     */
    async connectTcp(params) {
        // 设置设备连接类型
        this.device.setConnectionType('tcp');
        
        // 更新TCP客户端配置
        CONFIG.TCP = {
            SERVER: params.server,
            PORT: params.port,
            DATA_FORMAT: params.dataFormat,
            ENDIANNESS: params.endianness,
            PROTOCOL: params.protocol,
            HEADER_SIZE: params.headerSize,
            COMMAND_SEQUENCE: params.commandSequence
        };
        
        // 连接TCP
        await this.tcpClient.connect(params.server, params.port);
        
        // 初始化设备
        const deviceInitialized = await this.device.initialize(this.currentDeviceType, 'tcp');
        
        if (!deviceInitialized) {
            // 如果设备初始化失败，断开TCP连接
            this.tcpClient.disconnect();
            throw new Error('设备初始化失败');
        }
        
        // 启动数据流
        await this.device.startStreaming();
        
        // 保存连接参数到localStorage
        this.saveConnectionParams(params);
    }
    
    /**
     * 执行API连接
     * @param {Object} params - 连接参数
     */
    async connectApi(params) {
        // 设置设备连接类型
        this.device.setConnectionType('api');
        
        // 更新API配置
        CONFIG.API_ENDPOINT = params.apiEndpoint;
        CONFIG.WEBSOCKET_ENDPOINT = params.websocketEndpoint;
        
        // 初始化API客户端
        const apiInitialized = await this.apiClient.initialize('websocket');
        
        if (!apiInitialized) {
            throw new Error('API客户端初始化失败');
        }
        
        // 初始化设备
        const deviceInitialized = await this.device.initialize(this.currentDeviceType, 'api');
        
        if (!deviceInitialized) {
            throw new Error('设备初始化失败');
        }
        
        // 启动数据流
        await this.device.startStreaming();
        
        // 保存连接参数到localStorage
        this.saveConnectionParams(params);
    }
    
    /**
     * 执行UDP连接
     * @param {Object} params - 连接参数
     */
    async connectUdp(params) {
        // UDP连接需要特殊处理，这里模拟实现
        throw new Error('UDP连接方式尚未实现');
    }
    
    /**
     * 执行USB连接
     * @param {Object} params - 连接参数
     */
    async connectUsb(params) {
        if (!navigator.usb) {
            throw new Error('当前浏览器不支持WebUSB API');
        }
        
        try {
            // 请求USB设备
            const device = await navigator.usb.requestDevice({
                filters: [{
                    vendorId: parseInt(params.vendorId, 16),
                    productId: parseInt(params.productId, 16)
                }]
            });
            
            // 打开设备
            await device.open();
            
            // 获取接口和端点信息
            // 注：实际应用中可能需要根据设备特性选择适当的配置
            if (device.configuration === null) {
                await device.selectConfiguration(1);
            }
            
            const interface = device.configuration.interfaces[0];
            await device.claimInterface(interface.interfaceNumber);
            
            // 找到批量传输端点
            const inEndpoint = interface.alternate.endpoints.find(e => e.direction === 'in' && e.type === 'bulk');
            const outEndpoint = interface.alternate.endpoints.find(e => e.direction === 'out' && e.type === 'bulk');
            
            if (!inEndpoint || !outEndpoint) {
                throw new Error('未找到适用的USB端点');
            }
            
            // USB连接成功，但需要特殊处理
            throw new Error('USB连接方式尚未完全实现');
        } catch (error) {
            if (error.name === 'NotFoundError') {
                throw new Error('未选择设备或设备不符合要求');
            } else {
                throw error;
            }
        }
    }
    
    /**
     * 断开设备连接
     */
    async disconnect() {
        if (!this.isConnected && !this.isConnecting) {
            return;
        }
        
        // 更新UI状态
        const statusDot = document.getElementById('connectionStatusDot');
        const statusText = document.getElementById('connectionStatusText');
        const connectBtn = document.getElementById('connectBtn');
        const disconnectBtn = document.getElementById('disconnectBtn');
        
        try {
            // 停止数据流
            if (this.device) {
                await this.device.stopStreaming();
            }
            
            // 断开所有连接
            switch(this.currentConnectionType) {
                case 'tcp':
                    if (this.tcpClient) {
                        this.tcpClient.disconnect();
                    }
                    break;
                case 'api':
                    if (this.apiClient) {
                        await this.apiClient.disconnect();
                    }
                    break;
                case 'udp':
                    // UDP特定断开逻辑
                    break;
                case 'usb':
                    // USB特定断开逻辑
                    break;
            }
            
            // 更新连接状态
            this.isConnected = false;
            this.isConnecting = false;
            this.connectionStatus = 'disconnected';
            
            // 更新UI状态
            statusDot.className = 'status-dot';
            statusText.textContent = '已断开';
            connectBtn.disabled = false;
            disconnectBtn.disabled = true;
            
            // 更新连接信息显示
            document.getElementById('connectionInfo').innerHTML = '<span>请配置连接参数并点击连接按钮</span>';
            
            // 显示通知
            this.uiController.showNotification('设备已断开连接', 'info');
        } catch (error) {
            console.error('断开连接时出错:', error);
            
            // 更新UI状态
            statusDot.className = 'status-dot error';
            statusText.textContent = '断开失败';
            
            // 显示通知
            this.uiController.showNotification(`断开连接时出错: ${error.message}`, 'error');
        }
    }
    
    /**
     * 获取当前连接参数
     * @returns {Object} 连接参数
     */
    getConnectionParams() {
        const params = {
            deviceType: this.currentDeviceType
        };
        
        // 根据连接方式获取参数
        switch(this.currentConnectionType) {
            case 'tcp':
                params.server = document.getElementById('tcpServer').value;
                params.port = parseInt(document.getElementById('tcpPort').value);
                params.dataFormat = document.getElementById('tcpFormat').value;
                params.endianness = document.getElementById('tcpEndianness').value;
                params.protocol = document.getElementById('tcpProtocol').value;
                
                // 获取特定协议参数
                if (params.protocol === 'custom') {
                    params.headerSize = parseInt(document.getElementById('customHeaderSize').value || '0');
                    params.commandSequence = this.parseHexString(document.getElementById('customCommandSequence').value || '');
                    params.dataMarker = document.getElementById('customDataMarker').value || '';
                    params.sizeOffset = parseInt(document.getElementById('customSizeOffset').value || '0');
                } else {
                    // 使用预定义设备参数
                    const deviceParams = this.deviceSpecificParams[this.currentDeviceType] || {};
                    params.headerSize = deviceParams.headerSize || 0;
                    params.commandSequence = deviceParams.commandSequence || [];
                    
                    // 获取设备特定参数
                    switch(this.currentDeviceType) {
                        case 'GE7800':
                            if (document.getElementById('ge7800CasId')) {
                                params.casId = document.getElementById('ge7800CasId').value;
                                params.hwDecode = document.getElementById('ge7800HwDecode').value === 'true';
                            }
                            break;
                        case 'TA8030':
                            if (document.getElementById('ta8030DeviceId')) {
                                params.deviceId = parseInt(document.getElementById('ta8030DeviceId').value);
                                params.autoAck = document.getElementById('ta8030AutoAck').value === 'true';
                            }
                            break;
                        case 'HT8200':
                            if (document.getElementById('ht8200TransferMode')) {
                                params.transferMode = document.getElementById('ht8200TransferMode').value;
                                params.chunkSize = parseInt(document.getElementById('ht8200ChunkSize').value);
                            }
                            break;
                    }
                }
                break;
                
            case 'api':
                params.apiEndpoint = document.getElementById('apiEndpoint').value;
                params.websocketEndpoint = document.getElementById('websocketEndpoint').value;
                break;
                
            case 'udp':
                params.server = document.getElementById('udpServer').value;
                params.port = parseInt(document.getElementById('udpPort').value);
                params.dataFormat = document.getElementById('udpFormat').value;
                break;
                
            case 'usb':
                params.vendorId = document.getElementById('usbVendorId').value;
                params.productId = document.getElementById('usbProductId').value;
                break;
        }
        
        return params;
    }
    
    /**
     * 解析十六进制字符串为字节数组
     * @param {string} hexStr - 十六进制字符串（例如 "AA BB CC"）
     * @returns {Array} 字节数组
     */
    parseHexString(hexStr) {
        if (!hexStr) return [];
        
        // 移除所有空格并确保是偶数长度
        const cleanHex = hexStr.replace(/\s+/g, '');
        const result = [];
        
        for (let i = 0; i < cleanHex.length; i += 2) {
            // 如果剩余字符不足2个，使用0填充
            const hexByte = i + 1 < cleanHex.length ? cleanHex.substr(i, 2) : cleanHex.substr(i, 1) + '0';
            const byte = parseInt(hexByte, 16);
            if (!isNaN(byte)) {
                result.push(byte);
            }
        }
        
        return result;
    }
    
    /**
     * 解析设备信息数据
     * @param {Object} data - 设备返回的数据
     * @param {string} protocol - 协议类型
     * @returns {Object} 设备信息
     */
    parseDeviceInfo(data, protocol) {
        // 根据不同协议解析设备信息
        switch (protocol) {
            case 'ge7800':
                // 中科芯源GE7800协议
                if (data && data.device) {
                    return {
                        type: data.device.model || 'GE7800',
                        sampleRates: data.device.supportedRates || [61.44, 122.88, 245.76],
                        status: data.device.status || 'ready'
                    };
                }
                break;
                
            case 'ta8030':
                // 天奥电子TA8030协议
                if (data && data.deviceInfo) {
                    return {
                        type: data.deviceInfo.type || 'TA8030',
                        sampleRates: data.deviceInfo.sampleRates || [61.44, 122.88],
                        status: data.deviceInfo.status || 'ready'
                    };
                }
                break;
                
            case 'ht8200':
                // 航天宏图HT8200协议
                if (data && data.info) {
                    return {
                        type: data.info.deviceModel || 'HT8200',
                        sampleRates: data.info.sampleRates || [61.44, 122.88],
                        status: data.info.deviceStatus || 'ready'
                    };
                }
                break;
                
            case 'standard':
            default:
                // 标准协议
                if (data) {
                    return {
                        type: data.type || data.model || this.currentDeviceType,
                        sampleRates: data.sampleRates || [61.44],
                        status: data.status || 'ready'
                    };
                }
                break;
        }
        
        // 默认返回
        return {
            type: this.currentDeviceType,
            sampleRates: [61.44],
            status: 'unknown'
        };
    }
    
    /**
     * 保存连接参数到localStorage
     * @param {Object} params - 连接参数
     */
    saveConnectionParams(params) {
        localStorage.setItem('connectionType', this.currentConnectionType);
        localStorage.setItem('deviceType', this.currentDeviceType);
        
        // 根据连接类型保存其他参数
        switch(this.currentConnectionType) {
            case 'tcp':
                localStorage.setItem('tcpServer', params.server);
                localStorage.setItem('tcpPort', params.port);
                localStorage.setItem('tcpFormat', params.dataFormat);
                localStorage.setItem('tcpEndianness', params.endianness);
                localStorage.setItem('tcpProtocol', params.protocol);
                break;
                
            case 'api':
                localStorage.setItem('apiEndpoint', params.apiEndpoint);
                localStorage.setItem('websocketEndpoint', params.websocketEndpoint);
                break;
                
            case 'udp':
                localStorage.setItem('udpServer', params.server);
                localStorage.setItem('udpPort', params.port);
                localStorage.setItem('udpFormat', params.dataFormat);
                break;
                
            case 'usb':
                localStorage.setItem('usbVendorId', params.vendorId);
                localStorage.setItem('usbProductId', params.productId);
                break;
        }
    }
    
    /**
     * 从localStorage加载连接参数
     */
    loadConnectionParams() {
        const connectionType = localStorage.getItem('connectionType');
        const deviceType = localStorage.getItem('deviceType');
        
        if (connectionType) {
            this.currentConnectionType = connectionType;
            document.getElementById('connectionMethod').value = connectionType;
            this.onConnectionMethodChange();
        }
        
        if (deviceType) {
            this.currentDeviceType = deviceType;
            const deviceSelect = document.getElementById('deviceType');
            if (deviceSelect.querySelector(`option[value="${deviceType}"]`)) {
                deviceSelect.value = deviceType;
            }
            this.onDeviceTypeChange();
        }
        
        // 根据连接类型加载其他参数
        switch(this.currentConnectionType) {
            case 'tcp':
                const tcpServer = localStorage.getItem('tcpServer');
                const tcpPort = localStorage.getItem('tcpPort');
                const tcpFormat = localStorage.getItem('tcpFormat');
                const tcpEndianness = localStorage.getItem('tcpEndianness');
                const tcpProtocol = localStorage.getItem('tcpProtocol');
                
                if (tcpServer) document.getElementById('tcpServer').value = tcpServer;
                if (tcpPort) document.getElementById('tcpPort').value = tcpPort;
                if (tcpFormat) document.getElementById('tcpFormat').value = tcpFormat;
                if (tcpEndianness) document.getElementById('tcpEndianness').value = tcpEndianness;
                if (tcpProtocol) {
                    document.getElementById('tcpProtocol').value = tcpProtocol;
                    this.onProtocolChange();
                }
                break;
                
            case 'api':
                const apiEndpoint = localStorage.getItem('apiEndpoint');
                const websocketEndpoint = localStorage.getItem('websocketEndpoint');
                
                if (apiEndpoint) document.getElementById('apiEndpoint').value = apiEndpoint;
                if (websocketEndpoint) document.getElementById('websocketEndpoint').value = websocketEndpoint;
                break;
                
            case 'udp':
                const udpServer = localStorage.getItem('udpServer');
                const udpPort = localStorage.getItem('udpPort');
                const udpFormat = localStorage.getItem('udpFormat');
                
                if (udpServer) document.getElementById('udpServer').value = udpServer;
                if (udpPort) document.getElementById('udpPort').value = udpPort;
                if (udpFormat) document.getElementById('udpFormat').value = udpFormat;
                break;
                
            case 'usb':
                const usbVendorId = localStorage.getItem('usbVendorId');
                const usbProductId = localStorage.getItem('usbProductId');
                
                if (usbVendorId) document.getElementById('usbVendorId').value = usbVendorId;
                if (usbProductId) document.getElementById('usbProductId').value = usbProductId;
                break;
        }
    }
    
    /**
     * 更新状态显示
     */
    updateStatusDisplay() {
        const statusDot = document.getElementById('connectionStatusDot');
        const statusText = document.getElementById('connectionStatusText');
        const connectBtn = document.getElementById('connectBtn');
        const disconnectBtn = document.getElementById('disconnectBtn');
        
        if (this.isConnected) {
            statusDot.className = 'status-dot connected';
            statusText.textContent = '已连接';
            disconnectBtn.disabled = false;
        } else if (this.isConnecting) {
            statusDot.className = 'status-dot connecting';
            statusText.textContent = '连接中...';
            connectBtn.disabled = true;
            disconnectBtn.disabled = true;
        } else {
            statusDot.className = 'status-dot';
            statusText.textContent = '未连接';
            connectBtn.disabled = false;
            disconnectBtn.disabled = true;
        }
    }
    
    /**
     * 更新连接信息显示
     */
    updateConnectionInfoDisplay() {
        const connectionInfo = document.getElementById('connectionInfo');
        
        if (!this.isConnected) {
            connectionInfo.innerHTML = '<span>请配置连接参数并点击连接按钮</span>';
            return;
        }
        
        // 格式化连接信息
        let infoHtml = '';
        
        switch(this.connectionInfo.connectionType) {
            case 'tcp':
                infoHtml = `
                    <span>TCP连接 - ${this.connectionInfo.server}:${this.connectionInfo.port}</span><br>
                    <span>设备: ${this.connectionInfo.deviceType}</span><br>
                    <span>协议: ${this.connectionInfo.protocol}</span><br>
                    <span>数据格式: ${this.connectionInfo.dataFormat} (${this.connectionInfo.endianness})</span>
                `;
                break;
                
            case 'api':
                infoHtml = `
                    <span>API/WebSocket连接</span><br>
                    <span>API端点: ${this.connectionInfo.apiEndpoint}</span><br>
                    <span>设备: ${this.connectionInfo.deviceType}</span>
                `;
                break;
                
            case 'udp':
                infoHtml = `
                    <span>UDP连接 - ${this.connectionInfo.server}:${this.connectionInfo.port}</span><br>
                    <span>设备: ${this.connectionInfo.deviceType}</span><br>
                    <span>数据格式: ${this.connectionInfo.dataFormat}</span>
                `;
                break;
                
            case 'usb':
                infoHtml = `
                    <span>USB连接</span><br>
                    <span>厂商ID: ${this.connectionInfo.vendorId}</span><br>
                    <span>产品ID: ${this.connectionInfo.productId}</span><br>
                    <span>设备: ${this.connectionInfo.deviceType}</span>
                `;
                break;
        }
        
        // 添加连接时间信息
        if (this.connectionInfo.connectedAt) {
            const connectedTime = new Date(this.connectionInfo.connectedAt).toLocaleTimeString();
            infoHtml += `<br><span>连接时间: ${connectedTime}</span>`;
        }
        
        if (this.connectionInfo.connectionTime) {
            infoHtml += `<br><span>连接耗时: ${this.connectionInfo.connectionTime}ms</span>`;
        }
        
        connectionInfo.innerHTML = infoHtml;
    }
}