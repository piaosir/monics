/**
 * Constellation Display class for visualizing modulation
 */

class ConstellationDisplay {
    constructor(canvasId) {
        this.canvas = document.getElementById(canvasId);
        this.ctx = this.canvas.getContext('2d');
        this.modulation = CONFIG.CONSTELLATION.DEFAULT_MODULATION;
        this.maxPoints = CONFIG.CONSTELLATION.DEFAULT_POINTS;
        this.points = [];
        this.scale = 1.0;
        this.referencePoints = null;
        this.autodetectedModulation = null;
        
        // Initialize canvas size
        this.resizeCanvas();
        
        // Add resize handler
        window.addEventListener('resize', () => this.resizeCanvas());
    }

    /**
     * Resize canvas to match container size
     */
    resizeCanvas() {
        // Get container dimensions
        const container = this.canvas.parentElement;
        this.canvas.width = container.clientWidth;
        this.canvas.height = container.clientHeight;
        
        // Redraw if we have data
        if (this.points.length > 0) {
            this.draw();
        }
    }

    /**
     * Set modulation type
     * @param {string} modulation - Modulation type
     */
    setModulation(modulation) {
        if (CONFIG.CONSTELLATION.SUPPORTED_MODULATIONS.includes(modulation) || modulation === 'auto') {
            this.modulation = modulation;
            this.updateReferencePoints();
        }
    }

    /**
     * Update reference points for the current modulation
     */
    updateReferencePoints() {
        switch (this.modulation) {
            case 'BPSK':
                this.referencePoints = [
                    [-1, 0], [1, 0]
                ];
                break;
                
            case 'QPSK':
                this.referencePoints = [
                    [-0.7, -0.7], [-0.7, 0.7], [0.7, -0.7], [0.7, 0.7]
                ];
                break;
                
            case '8PSK':
                const radius = 1;
                this.referencePoints = [];
                for (let i = 0; i < 8; i++) {
                    const angle = i * Math.PI / 4 + Math.PI / 8;
                    this.referencePoints.push([
                        radius * Math.cos(angle),
                        radius * Math.sin(angle)
                    ]);
                }
                break;
                
            case '16QAM':
                this.referencePoints = [];
                const values = [-0.9, -0.3, 0.3, 0.9];
                for (let i = 0; i < values.length; i++) {
                    for (let j = 0; j < values.length; j++) {
                        this.referencePoints.push([values[i], values[j]]);
                    }
                }
                break;
                
            case '64QAM':
                this.referencePoints = [];
                const values64 = [-1.05, -0.75, -0.45, -0.15, 0.15, 0.45, 0.75, 1.05];
                for (let i = 0; i < values64.length; i++) {
                    for (let j = 0; j < values64.length; j++) {
                        this.referencePoints.push([values64[i], values64[j]]);
                    }
                }
                break;
                
            case '256QAM':
                // Generate 16x16 grid
                this.referencePoints = [];
                for (let i = -15; i <= 15; i += 2) {
                    for (let j = -15; j <= 15; j += 2) {
                        this.referencePoints.push([i/15, j/15]);
                    }
                }
                break;
                
            default:
                this.referencePoints = null;
                break;
        }
    }

    /**
     * Add new IQ data points to constellation
     * @param {Object} iqData - IQ data with i and q components
     */
    addData(iqData) {
        // Generate constellation points from IQ data
        this.points = DSPUtils.generateConstellationPoints(iqData, this.maxPoints);
        
        // Auto-detect modulation if set to auto
        if (this.modulation === 'auto' && this.points.length > CONFIG.MODULATION.MIN_CONSTELLATION_POINTS) {
            this.autodetectModulation();
        }
        
        // Normalize point amplitude
        this.normalizePoints();
        
        // Draw the constellation
        this.draw();
    }

    /**
     * Normalize the amplitude of constellation points
     */
    normalizePoints() {
        if (this.points.length === 0) {
            return;
        }
        
        // Find maximum amplitude
        let maxAmp = 0;
        for (const point of this.points) {
            const amp = Math.sqrt(point[0] * point[0] + point[1] * point[1]);
            maxAmp = Math.max(maxAmp, amp);
        }
        
        // Skip if maximum amplitude is too small
        if (maxAmp < 1e-6) {
            return;
        }
        
        // Normalize by maximum amplitude
        this.scale = 1.0 / maxAmp;
        
        // Apply normalization
        for (const point of this.points) {
            point[0] *= this.scale;
            point[1] *= this.scale;
        }
    }

    /**
     * Auto-detect modulation type from constellation
     */
    autodetectModulation() {
        // This is a simplified auto-detection algorithm
        // Real implementation would use more sophisticated metrics
        
        if (this.points.length < 100) {
            return; // Not enough points for reliable detection
        }
        
        // Calculate distance from each point to origin
        const distances = this.points.map(p => Math.sqrt(p[0] * p[0] + p[1] * p[1]));
        
        // Calculate variance of distances
        const meanDist = distances.reduce((sum, d) => sum + d, 0) / distances.length;
        const varDist = distances.reduce((sum, d) => sum + Math.pow(d - meanDist, 2), 0) / distances.length;
        
        // Calculate phase angles
        const angles = this.points.map(p => Math.atan2(p[1], p[0]));
        
        // Count unique phase clusters (simplified)
        const phaseBins = new Array(36).fill(0); // 10-degree bins
        for (const angle of angles) {
            const bin = Math.floor((angle + Math.PI) * 18 / Math.PI) % 36;
            phaseBins[bin]++;
        }
        
        let significantBins = 0;
        const threshold = this.points.length / 20; // 5% of points
        for (const bin of phaseBins) {
            if (bin > threshold) {
                significantBins++;
            }
        }
        
        // Simple heuristic detection based on phase distribution and amplitude variance
        if (significantBins <= 2) {
            this.autodetectedModulation = 'BPSK';
        } else if (significantBins <= 4) {
            this.autodetectedModulation = 'QPSK';
        } else if (significantBins <= 8) {
            this.autodetectedModulation = '8PSK';
        } else {
            // QAM detection based on amplitude variance
            if (varDist < 0.05) {
                // PSK-like - all points at similar distance from origin
                this.autodetectedModulation = '8PSK';
            } else {
                // Determine QAM order based on visible clusters
                const visibleClusters = this.estimateNumberOfClusters();
                
                if (visibleClusters <= 16) {
                    this.autodetectedModulation = '16QAM';
                } else if (visibleClusters <= 64) {
                    this.autodetectedModulation = '64QAM';
                } else {
                    this.autodetectedModulation = '256QAM';
                }
            }
        }
        
        // Update reference points with detected modulation
        if (this.autodetectedModulation) {
            this.modulation = this.autodetectedModulation;
            this.updateReferencePoints();
        }
    }

    /**
     * Estimate the number of clusters in the constellation
     * @returns {number} Estimated number of clusters
     */
    estimateNumberOfClusters() {
        // This is a very simplified algorithm for cluster counting
        // In a real implementation, we'd use k-means or DBSCAN
        
        const gridSize = 8;
        const grid = new Array(gridSize * gridSize).fill(0);
        
        // Count points in each grid cell
        for (const point of this.points) {
            const x = Math.floor((point[0] + 1.5) * gridSize / 3);
            const y = Math.floor((point[1] + 1.5) * gridSize / 3);
            
            if (x >= 0 && x < gridSize && y >= 0 && y < gridSize) {
                grid[y * gridSize + x]++;
            }
        }
        
        // Count cells with significant number of points
        const threshold = this.points.length / (gridSize * gridSize * 2);
        let clusters = 0;
        
        for (const count of grid) {
            if (count > threshold) {
                clusters++;
            }
        }
        
        return clusters;
    }

    /**
     * Draw constellation on canvas
     */
    draw() {
        if (this.points.length === 0) {
            return;
        }
        
        // Clear canvas
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        const width = this.canvas.width;
        const height = this.canvas.height;
        const centerX = width / 2;
        const centerY = height / 2;
        const scale = Math.min(width, height) * 0.4;
        
        // Draw background and grid
        this.drawGrid(centerX, centerY, scale);
        
        // Draw constellation points
        this.ctx.globalAlpha = 0.5;
        this.ctx.fillStyle = '#4CAF50';
        
        for (const point of this.points) {
            const x = centerX + point[0] * scale;
            const y = centerY - point[1] * scale;
            
            this.ctx.beginPath();
            this.ctx.arc(x, y, 2, 0, 2 * Math.PI);
            this.ctx.fill();
        }
        
        // Draw reference constellation if available
        if (this.referencePoints) {
            this.ctx.globalAlpha = 1.0;
            this.ctx.fillStyle = '#ff5722';
            
            for (const point of this.referencePoints) {
                const x = centerX + point[0] * scale;
                const y = centerY - point[1] * scale;
                
                this.ctx.beginPath();
                this.ctx.arc(x, y, 4, 0, 2 * Math.PI);
                this.ctx.fill();
            }
        }
        
        // Draw modulation info
        this.ctx.globalAlpha = 1.0;
        this.ctx.fillStyle = '#fff';
        this.ctx.font = '16px Arial';
        this.ctx.textAlign = 'center';
        
        let modulationText = this.modulation;
        if (this.modulation === 'auto' && this.autodetectedModulation) {
            modulationText = `Auto: ${this.autodetectedModulation}`;
        }
        
        this.ctx.fillText(`Modulation: ${modulationText}`, centerX, 30);
    }

    /**
     * Draw grid on canvas
     * @param {number} centerX - Center X coordinate
     * @param {number} centerY - Center Y coordinate
     * @param {number} scale - Scale factor for drawing
     */
    drawGrid(centerX, centerY, scale) {
        // Draw background
        this.ctx.fillStyle = '#0a0a0a';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Draw grid
        this.ctx.strokeStyle = '#333';
        this.ctx.lineWidth = 1;
        
        // Draw horizontal and vertical axes
        this.ctx.beginPath();
        this.ctx.moveTo(0, centerY);
        this.ctx.lineTo(this.canvas.width, centerY);
        this.ctx.moveTo(centerX, 0);
        this.ctx.lineTo(centerX, this.canvas.height);
        this.ctx.stroke();
        
        // Draw unit circle
        this.ctx.beginPath();
        this.ctx.arc(centerX, centerY, scale, 0, 2 * Math.PI);
        this.ctx.stroke();
        
        // Draw grid lines
        this.ctx.strokeStyle = '#222';
        
        // Draw horizontal grid lines
        for (let i = -2; i <= 2; i += 0.5) {
            if (i === 0) continue; // Skip center line (already drawn)
            
            this.ctx.beginPath();
            this.ctx.moveTo(centerX - scale * 2, centerY - i * scale);
            this.ctx.lineTo(centerX + scale * 2, centerY - i * scale);
            this.ctx.stroke();
        }
        
        // Draw vertical grid lines
        for (let i = -2; i <= 2; i += 0.5) {
            if (i === 0) continue; // Skip center line (already drawn)
            
            this.ctx.beginPath();
            this.ctx.moveTo(centerX + i * scale, centerY - scale * 2);
            this.ctx.lineTo(centerX + i * scale, centerY + scale * 2);
            this.ctx.stroke();
        }
    }
}