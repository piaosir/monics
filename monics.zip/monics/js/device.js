/**
 * Device management class for controlling the SDR hardware
 * Handles communication with the ADC hardware for raw IQ data acquisition
 */

class SDRDevice {
    constructor(apiClient) {
        this.apiClient = apiClient;
        this.deviceType = CONFIG.DEVICE.DEFAULT_DEVICE_TYPE;
        this.deviceInfo = null;
        this.isStreaming = false;
        this.currentSettings = {
            centerFreq: CONFIG.DEVICE.DEFAULT_CENTER_FREQ * 1e6, // Convert to Hz
            sampleRate: CONFIG.DEVICE.DEFAULT_SAMPLE_RATE * 1e6, // Convert to Hz
            gainMode: CONFIG.DEVICE.DEFAULT_GAIN_MODE,
            gainValue: CONFIG.DEVICE.DEFAULT_GAIN_VALUE,
            bandwidth: CONFIG.SPECTRUM.DEFAULT_SPAN * 1e6       // Convert to Hz
        };
        this.bufferSize = 0;
        this.connectionType = 'api'; // 'api' or 'tcp'
        this.tcpClient = null;

        // ����DSP������
        this.dspProcessor = {
            rbw: CONFIG.BANDWIDTH.DEFAULT_RBW * 1000, // Hz
            vbw: CONFIG.BANDWIDTH.DEFAULT_VBW * 1000, // Hz

            setRBW: function (rbwHz) {
                this.rbw = rbwHz;
            },

            setVBW: function (vbwHz) {
                this.vbw = vbwHz;
            },

            processIQData: function (iqData, sampleRate) {
                // Ӧ��RBW�˲�
                let filteredData = DSPUtils.applyRBWFilter(iqData, this.rbw, sampleRate);
                return filteredData;
            },

            processSpectrumData: function (freqData, powerData) {
                // Ӧ��VBW�˲�
                const vbwRbwRatio = this.vbw / this.rbw;
                let filteredPowerData = DSPUtils.applyVBWFilter(powerData, vbwRbwRatio);
                return {
                    frequencies: freqData,
                    powers: filteredPowerData
                };
            }
        };
    }

    /**
     * Initialize the device
     * @param {string} deviceType - Type of device to use
     * @param {string} connectionType - Connection type ('api' or 'tcp')
     * @returns {Promise<boolean>} Success status
     */
    async initialize(deviceType = CONFIG.DEVICE.DEFAULT_DEVICE_TYPE, connectionType = 'api') {
        try {
            this.deviceType = deviceType;
            this.connectionType = connectionType;

            if (connectionType === 'tcp') {
                // For TCP connection, we don't need to query device info first
                // Create TCP client if not exists
                if (!this.tcpClient && window.TCPClient) {
                    this.tcpClient = new TCPClient();

                    // Register data handler
                    this.tcpClient.on('data', (data) => {
                        this.apiClient.dispatchEvent('data', { iq: data });
                    });
                }

                // Set default device info for TCP connection
                this.deviceInfo = {
                    type: deviceType,
                    sampleRates: [CONFIG.DEVICE.DEFAULT_SAMPLE_RATE * 1e6],
                    frequencyRange: CONFIG.DEVICE.SUPPORTED_DEVICES[deviceType]?.FREQ_RANGE || [30, 6000],
                    gainRange: [0, 70],
                    bandwidthRange: [1, CONFIG.DEVICE.SUPPORTED_DEVICES[deviceType]?.MAX_BW || 250]
                };
            } else {
                // For API connection, query device capabilities
                const deviceInfo = await this.apiClient.get('/device/info', {
                    type: this.deviceType
                });

                this.deviceInfo = deviceInfo;
            }

            // Set buffer size based on device capabilities
            this.bufferSize = this.calculateOptimalBufferSize();

            // Configure device with default settings
            await this.configure(this.currentSettings);

            return true;
        } catch (error) {
            console.error('Failed to initialize device:', error);
            return false;
        }
    }

    /**
     * Calculate optimal buffer size based on device capabilities
     * @returns {number} Optimal buffer size
     */
    calculateOptimalBufferSize() {
        let bufferSize = 16384; // Default

        // Adjust based on sample rate
        if (this.currentSettings.sampleRate > 100e6) {
            bufferSize = 65536;
        } else if (this.currentSettings.sampleRate > 50e6) {
            bufferSize = 32768;
        }

        return bufferSize;
    }

    /**
     * Configure the device with new settings
     * @param {Object} settings - Device settings
     * @returns {Promise<boolean>} Success status
     */
    async configure(settings = {}) {
        // Merge with current settings
        const newSettings = {
            ...this.currentSettings,
            ...settings
        };

        // Validate settings against device capabilities
        this.validateSettings(newSettings);

        try {
            // Apply settings based on connection type
            if (this.connectionType === 'tcp' && this.tcpClient) {
                // For TCP, send configuration command
                const configSuccess = this.tcpClient.sendCommand({
                    command: 'configure',
                    type: this.deviceType,
                    centerFrequency: newSettings.centerFreq,
                    sampleRate: newSettings.sampleRate,
                    gainMode: newSettings.gainMode,
                    gainValue: newSettings.gainValue,
                    bandwidth: newSettings.bandwidth,
                    bufferSize: this.bufferSize
                });

                if (!configSuccess) {
                    throw new Error('Failed to send configuration command via TCP');
                }
            } else {
                // For API, use REST endpoint
                await this.apiClient.configureDevice({
                    type: this.deviceType,
                    centerFrequency: newSettings.centerFreq,
                    sampleRate: newSettings.sampleRate,
                    gainMode: newSettings.gainMode,
                    gainValue: newSettings.gainValue,
                    bandwidth: newSettings.bandwidth,
                    bufferSize: this.bufferSize
                });
            }

            // Update current settings
            this.currentSettings = newSettings;

            return true;
        } catch (error) {
            console.error('Failed to configure device:', error);
            return false;
        }
    }

    /**
     * Validate settings against device capabilities
     * @param {Object} settings - Device settings to validate
     * @throws {Error} If settings are invalid
     */
    validateSettings(settings) {
        const deviceSpecs = CONFIG.DEVICE.SUPPORTED_DEVICES[this.deviceType];

        if (!deviceSpecs) {
            throw new Error(`Unsupported device type: ${this.deviceType}`);
        }

        // Check frequency range
        const freqMHz = settings.centerFreq / 1e6;
        if (freqMHz < deviceSpecs.FREQ_RANGE[0] || freqMHz > deviceSpecs.FREQ_RANGE[1]) {
            throw new Error(`Center frequency out of range for ${this.deviceType}. Valid range: ${deviceSpecs.FREQ_RANGE[0]}-${deviceSpecs.FREQ_RANGE[1]} MHz`);
        }

        // Check sample rate
        const sampleRateMSPS = settings.sampleRate / 1e6;
        if (sampleRateMSPS > deviceSpecs.MAX_SAMPLE_RATE) {
            throw new Error(`Sample rate exceeds maximum for ${this.deviceType}. Maximum: ${deviceSpecs.MAX_SAMPLE_RATE} MSPS`);
        }

        // Check bandwidth
        const bwMHz = settings.bandwidth / 1e6;
        if (bwMHz > deviceSpecs.MAX_BW) {
            throw new Error(`Bandwidth exceeds maximum for ${this.deviceType}. Maximum: ${deviceSpecs.MAX_BW} MHz`);
        }
    }

    /**
     * Start streaming IQ data from the device
     * @returns {Promise<boolean>} Success status
     */
    async startStreaming() {
        if (this.isStreaming) {
            return true;
        }

        try {
            if (this.connectionType === 'tcp' && this.tcpClient) {
                // For TCP connection
                if (!this.tcpClient.connected) {
                    // Connect if not already connected
                    await this.tcpClient.connect();
                }

                // Send start streaming command
                const success = this.tcpClient.sendCommand({
                    command: 'startStream',
                    bufferSize: this.bufferSize
                });

                if (success) {
                    this.isStreaming = true;
                    return true;
                } else {
                    throw new Error('Failed to send start streaming command via TCP');
                }
            } else {
                // For API connection
                const response = await this.apiClient.startStreaming({
                    type: this.deviceType,
                    bufferSize: this.bufferSize
                });

                if (response.status === 'streaming') {
                    this.isStreaming = true;
                    return true;
                } else {
                    throw new Error('Failed to start streaming');
                }
            }
        } catch (error) {
            console.error('Failed to start streaming:', error);
            return false;
        }
    }

    /**
     * Stop streaming IQ data from the device
     * @returns {Promise<boolean>} Success status
     */
    async stopStreaming() {
        if (!this.isStreaming) {
            return true;
        }

        try {
            if (this.connectionType === 'tcp' && this.tcpClient) {
                // For TCP connection
                const success = this.tcpClient.sendCommand({
                    command: 'stopStream'
                });

                if (success) {
                    this.isStreaming = false;
                    return true;
                } else {
                    throw new Error('Failed to send stop streaming command via TCP');
                }
            } else {
                // For API connection
                const response = await this.apiClient.stopStreaming();

                if (response.status === 'stopped') {
                    this.isStreaming = false;
                    return true;
                } else {
                    throw new Error('Failed to stop streaming');
                }
            }
        } catch (error) {
            console.error('Failed to stop streaming:', error);
            return false;
        }
    }

    /**
     * Set center frequency
     * @param {number} frequency - Frequency in MHz
     * @returns {Promise<boolean>} Success status
     */
    async setCenterFrequency(frequency) {
        return this.configure({
            centerFreq: frequency * 1e6 // Convert to Hz
        });
    }

    /**
     * Set sample rate
     * @param {number} sampleRate - Sample rate in MSPS
     * @returns {Promise<boolean>} Success status
     */
    async setSampleRate(sampleRate) {
        return this.configure({
            sampleRate: sampleRate * 1e6 // Convert to Hz
        });
    }

    /**
     * Set gain mode
     * @param {string} mode - Gain mode ('auto', 'manual', etc.)
     * @returns {Promise<boolean>} Success status
     */
    async setGainMode(mode) {
        return this.configure({
            gainMode: mode
        });
    }

    /**
     * Set gain value (for manual gain mode)
     * @param {number} value - Gain value in dB
     * @returns {Promise<boolean>} Success status
     */
    async setGainValue(value) {
        return this.configure({
            gainValue: value
        });
    }

    /**
     * Set bandwidth
     * @param {number} bandwidth - Bandwidth in MHz
     * @returns {Promise<boolean>} Success status
     */
    async setBandwidth(bandwidth) {
        return this.configure({
            bandwidth: bandwidth * 1e6 // Convert to Hz
        });
    }

    /**
     * Set connection type
     * @param {string} type - Connection type ('api' or 'tcp')
     */
    setConnectionType(type) {
        if (type === 'api' || type === 'tcp') {
            this.connectionType = type;
        }
    }

    /**
     * Set TCP client
     * @param {TCPClient} client - TCP client instance
     */
    setTCPClient(client) {
        this.tcpClient = client;
    }

    /**
     * Get current device settings
     * @returns {Object} Current device settings
     */
    getSettings() {
        return {
            deviceType: this.deviceType,
            centerFreq: this.currentSettings.centerFreq / 1e6, // Convert to MHz
            sampleRate: this.currentSettings.sampleRate / 1e6, // Convert to MSPS
            gainMode: this.currentSettings.gainMode,
            gainValue: this.currentSettings.gainValue,
            bandwidth: this.currentSettings.bandwidth / 1e6,   // Convert to MHz
            bufferSize: this.bufferSize,
            connectionType: this.connectionType
        };
    }

    /**
     * Get device capabilities
     * @returns {Object} Device capabilities
     */
    getCapabilities() {
        return CONFIG.DEVICE.SUPPORTED_DEVICES[this.deviceType];
    }

    /**
     * Disconnect device
     * @returns {Promise<boolean>} Success status
     */
    async disconnect() {
        try {
            // Stop streaming first
            if (this.isStreaming) {
                await this.stopStreaming();
            }

            // Disconnect TCP if applicable
            if (this.connectionType === 'tcp' && this.tcpClient) {
                this.tcpClient.disconnect();
            }

            return true;
        } catch (error) {
            console.error('Error during device disconnect:', error);
            return false;
        }
    }

    /**
     * Set RBWֵ
     * @param {number} rbwKHz - RBWֵ (kHz)
     */
    setRBW(rbwKHz) {
        if (this.dspProcessor) {
            this.dspProcessor.setRBW(rbwKHz * 1000);
        }
    }

    /**
     * Set VBWֵ
     * @param {number} vbwKHz - VBWֵ (kHz)
     */
    setVBW(vbwKHz) {
        if (this.dspProcessor) {
            this.dspProcessor.setVBW(vbwKHz * 1000);
        }
    }

    /**
     * Set�Ƿ��Զ�����RBW
     * @param {boolean} auto - �Ƿ��Զ�
     */
    setAutoRBW(auto) {
        CONFIG.BANDWIDTH.AUTO_RBW = auto;
    }

    /**
     * Set�Ƿ��Զ�����VBW
     * @param {boolean} auto - �Ƿ��Զ�
     */
    setAutoVBW(auto) {
        CONFIG.BANDWIDTH.AUTO_VBW = auto;
    }

    /**
     * Set VBW/RBW����
     * @param {number} ratio - ����ֵ
     */
    setVBWRBWRatio(ratio) {
        CONFIG.BANDWIDTH.VBW_RBW_RATIO = ratio;
    }
}