/**
 * Interference Analyzer class for detecting and analyzing interference
 */

class InterferenceAnalyzer {
    constructor(canvasId) {
        this.canvas = document.getElementById(canvasId);
        this.ctx = this.canvas.getContext('2d');
        this.detectionThreshold = CONFIG.INTERFERENCE.DEFAULT_DETECTION_THRESHOLD;
        this.sensitivity = CONFIG.INTERFERENCE.DEFAULT_SENSITIVITY;
        this.detectionTypes = CONFIG.INTERFERENCE.DETECTION_TYPES;
        this.frequencyData = null;
        this.timeHistory = [];
        this.maxHistoryLength = 100;
        this.interferenceEvents = [];
        this.detectedInterferences = [];

        // Initialize canvas size
        this.resizeCanvas();

        // Add resize handler
        window.addEventListener('resize', () => this.resizeCanvas());
    }

    /**
     * Resize canvas to match container size
     */
    resizeCanvas() {
        // Get container dimensions
        const container = this.canvas.parentElement;
        this.canvas.width = container.clientWidth;
        this.canvas.height = container.clientHeight;

        // Redraw if we have data
        if (this.frequencyData) {
            this.drawAnalysis();
        }
    }

    /**
     * Set detection threshold
     * @param {number} threshold - Detection threshold in dBm
     */
    setDetectionThreshold(threshold) {
        this.detectionThreshold = threshold;
    }

    /**
     * Set sensitivity level
     * @param {string} sensitivity - Sensitivity level ('low', 'medium', 'high')
     */
    setSensitivity(sensitivity) {
        this.sensitivity = sensitivity;
    }

    /**
     * Add new spectrum data for analysis
     * @param {Array} frequencyData - Frequency data in Hz
     * @param {Array} powerData - Power spectrum data in dBm
     */
    addData(frequencyData, powerData) {
        this.frequencyData = frequencyData;

        // Add data to time history
        this.timeHistory.push({
            timestamp: Date.now(),
            powerData: powerData.slice() // Clone the array
        });

        // Limit history length
        if (this.timeHistory.length > this.maxHistoryLength) {
            this.timeHistory.shift();
        }

        // Analyze for interference
        this.analyzeInterference(frequencyData, powerData);

        // Draw analysis results
        this.drawAnalysis();
    }

    /**
     * Analyze spectrum for interference
     * @param {Array} frequencyData - Frequency data in Hz
     * @param {Array} powerData - Power spectrum data in dBm
     */
    analyzeInterference(frequencyData, powerData) {
        // Reset detected interferences
        this.detectedInterferences = [];

        // Get noise floor
        const noiseFloor = DSPUtils.estimateNoiseFloor(powerData);

        // Set threshold based on sensitivity
        let sensitivityFactor;
        switch (this.sensitivity) {
            case 'low': sensitivityFactor = 15; break;
            case 'high': sensitivityFactor = 5; break;
            default: sensitivityFactor = 10; break; // medium
        }

        const effectiveThreshold = Math.max(this.detectionThreshold, noiseFloor + sensitivityFactor);

        // Find peaks above threshold
        const peaks = DSPUtils.findPeaks(powerData, sensitivityFactor);

        // Process each significant peak
        for (const peak of peaks) {
            if (peak.value < effectiveThreshold) continue;

            // Get frequency of the peak
            const peakFreq = frequencyData[peak.index];

            // Analyze the type of interference
            const interferenceType = this.classifyInterference(peak.index, powerData, frequencyData);

            // Create interference entry
            const interference = {
                frequency: peakFreq,
                power: peak.value,
                type: interferenceType,
                bandwidth: this.estimateInterferenceBandwidth(peak.index, powerData, frequencyData, noiseFloor + 3),
                timestamp: Date.now()
            };

            // Add to detected interferences
            this.detectedInterferences.push(interference);

            // Check if this is a new interference event
            if (this.isNewInterferenceEvent(interference)) {
                // Add to interference events with a unique ID
                interference.id = Date.now() + Math.random().toString(36).substr(2, 5);
                this.interferenceEvents.push(interference);

                // Limit the number of stored events
                if (this.interferenceEvents.length > 100) {
                    this.interferenceEvents.shift();
                }
            }
        }
    }

    /**
     * Check if interference is a new event (not previously detected)
     * @param {Object} interference - Interference data
     * @returns {boolean} True if this is a new event
     */
    isNewInterferenceEvent(interference) {
        // If no previous events, this is new
        if (this.interferenceEvents.length === 0) {
            return true;
        }

        // Check against recent events (last 10 seconds)
        const recentTime = Date.now() - 10000;
        const recentEvents = this.interferenceEvents.filter(e => e.timestamp > recentTime);

        // Check if this interference is close to any recent event
        for (const event of recentEvents) {
            // If frequency is within 1% and same type, consider it the same event
            const freqDiff = Math.abs(event.frequency - interference.frequency);
            const relFreqDiff = freqDiff / event.frequency;

            if (relFreqDiff < 0.01 && event.type === interference.type) {
                return false;
            }
        }

        return true;
    }

    /**
     * Classify interference type
     * @param {number} peakIndex - Index of the peak in the power data
     * @param {Array} powerData - Power spectrum data
     * @param {Array} frequencyData - Frequency data
     * @returns {string} Interference type
     */
    classifyInterference(peakIndex, powerData, frequencyData) {
        // This is a simplified classification algorithm
        // Real implementation would use more sophisticated techniques

        const peakWidth = this.estimatePeakWidth(peakIndex, powerData);

        // Check for carrier wave (narrow peak)
        if (peakWidth < 5) {
            return 'CW';
        }

        // Check for wideband signals
        if (peakWidth > 50) {
            return 'WBFM';
        }

        // Check for adjacent channel interference
        if (this.checkForAdjacentInterference(peakIndex, powerData, frequencyData)) {
            return 'Adjacent';
        }

        // Check for pulsed interference by looking at time history
        if (this.checkForPulsedInterference(peakIndex, frequencyData)) {
            return 'Pulsed';
        }

        // Check for frequency sweeping interference
        if (this.checkForSweepInterference(peakIndex, frequencyData)) {
            return 'Sweep';
        }

        // Default to CDMA-like (spread spectrum) for medium width signals
        return 'CDMA';
    }

    /**
     * Estimate width of peak in number of bins
     * @param {number} peakIndex - Index of peak
     * @param {Array} powerData - Power spectrum data
     * @returns {number} Width of peak in bins
     */
    estimatePeakWidth(peakIndex, powerData) {
        const peakValue = powerData[peakIndex];
        const halfPowerThreshold = peakValue - 3; // 3dB below peak

        // Find left edge
        let leftEdge = peakIndex;
        while (leftEdge > 0 && powerData[leftEdge - 1] > halfPowerThreshold) {
            leftEdge--;
        }

        // Find right edge
        let rightEdge = peakIndex;
        while (rightEdge < powerData.length - 1 && powerData[rightEdge + 1] > halfPowerThreshold) {
            rightEdge++;
        }

        return rightEdge - leftEdge + 1;
    }

    /**
     * Check for adjacent channel interference
     * @param {number} peakIndex - Index of peak
     * @param {Array} powerData - Power spectrum data
     * @param {Array} frequencyData - Frequency data
     * @returns {boolean} True if adjacent interference detected
     */
    checkForAdjacentInterference(peakIndex, powerData, frequencyData) {
        // Check for a secondary peak nearby
        const peakValue = powerData[peakIndex];
        const searchRange = 30; // bins

        for (let i = Math.max(0, peakIndex - searchRange); i < Math.min(powerData.length, peakIndex + searchRange); i++) {
            // Skip the primary peak area
            if (Math.abs(i - peakIndex) < 5) continue;

            // If there's another strong peak, likely adjacent interference
            if (powerData[i] > peakValue - 10 && // Within 10dB of main peak
                powerData[i] > powerData[i - 1] &&
                powerData[i] > powerData[i + 1]) {
                return true;
            }
        }

        return false;
    }

    /**
     * Check for pulsed interference using time history
     * @param {number} peakIndex - Index of peak
     * @param {Array} frequencyData - Frequency data
     * @returns {boolean} True if pulsed interference detected
     */
    checkForPulsedInterference(peakIndex, frequencyData) {
        if (this.timeHistory.length < 5) {
            return false; // Not enough history
        }

        const peakFreq = frequencyData[peakIndex];
        const freqTolerance = (frequencyData[1] - frequencyData[0]) * 5; // 5 bins tolerance

        // Count how many times this frequency appears and disappears
        let transitions = 0;
        let prevPresent = false;

        for (const history of this.timeHistory) {
            // Find closest frequency bin in this history entry
            let closest = 0;
            let minDist = Number.MAX_VALUE;

            for (let i = 0; i < this.frequencyData.length; i++) {
                const dist = Math.abs(this.frequencyData[i] - peakFreq);
                if (dist < minDist) {
                    minDist = dist;
                    closest = i;
                }
            }

            // Check if peak is present
            const presentNow = minDist < freqTolerance &&
                history.powerData[closest] > this.detectionThreshold;

            // Count transitions
            if (prevPresent !== presentNow) {
                transitions++;
            }
            prevPresent = presentNow;
        }

        // Pulsed signal should have multiple transitions
        return transitions >= 3;
    }

    /**
     * Check for sweep interference using time history
     * @param {number} peakIndex - Index of peak
     * @param {Array} frequencyData - Frequency data
     * @returns {boolean} True if sweep interference detected
     */
    checkForSweepInterference(peakIndex, frequencyData) {
        if (this.timeHistory.length < 5) {
            return false; // Not enough history
        }

        // Track peak movement over time
        const peakPositions = [];
        const currentFreq = frequencyData[peakIndex];

        // Find peaks in historical data near current frequency range
        const freqMin = currentFreq * 0.98;
        const freqMax = currentFreq * 1.02;

        for (const history of this.timeHistory) {
            // Find peak in the relevant frequency range
            let maxPower = -200;
            let maxFreqIndex = -1;

            for (let i = 0; i < this.frequencyData.length; i++) {
                const freq = this.frequencyData[i];
                if (freq >= freqMin && freq <= freqMax &&
                    history.powerData[i] > this.detectionThreshold &&
                    history.powerData[i] > maxPower) {
                    maxPower = history.powerData[i];
                    maxFreqIndex = i;
                }
            }

            if (maxFreqIndex >= 0) {
                peakPositions.push(this.frequencyData[maxFreqIndex]);
            }
        }

        // Need at least 3 positions to detect sweep
        if (peakPositions.length < 3) {
            return false;
        }

        // Calculate frequency deltas
        const deltas = [];
        for (let i = 1; i < peakPositions.length; i++) {
            deltas.push(peakPositions[i] - peakPositions[i - 1]);
        }

        // Check if deltas are consistently in the same direction (sweep)
        let positiveCount = 0;
        let negativeCount = 0;

        for (const delta of deltas) {
            if (delta > 0) positiveCount++;
            if (delta < 0) negativeCount++;
        }

        const totalDeltas = positiveCount + negativeCount;
        const maxCount = Math.max(positiveCount, negativeCount);

        // If 70% of deltas are in the same direction, consider it a sweep
        return totalDeltas > 0 && maxCount / totalDeltas > 0.7;
    }

    /**
     * Estimate interference bandwidth
     * @param {number} peakIndex - Peak index
     * @param {Array} powerData - Power data
     * @param {Array} frequencyData - Frequency data
     * @param {number} threshold - Power threshold for bandwidth estimation
     * @returns {number} Bandwidth in Hz
     */
    estimateInterferenceBandwidth(peakIndex, powerData, frequencyData, threshold) {
        // Find lower frequency bound
        let lowerIndex = peakIndex;
        while (lowerIndex > 0 && powerData[lowerIndex] > threshold) {
            lowerIndex--;
        }

        // Find upper frequency bound
        let upperIndex = peakIndex;
        while (upperIndex < powerData.length - 1 && powerData[upperIndex] > threshold) {
            upperIndex++;
        }

        // Calculate bandwidth
        return frequencyData[upperIndex] - frequencyData[lowerIndex];
    }

    /**
     * Draw interference analysis on canvas
     */
    drawAnalysis() {
        if (!this.frequencyData || this.timeHistory.length === 0) {
            return;
        }

        // Clear canvas
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

        const width = this.canvas.width;
        const height = this.canvas.height;

        // Draw background
        this.ctx.fillStyle = '#0a0a0a';
        this.ctx.fillRect(0, 0, width, height);

        // Draw current spectrum (half height)
        this.drawSpectrum(0, 0, width, height / 2);

        // Draw interference table
        this.drawInterferenceTable(0, height / 2, width, height / 2);

        // Update interference data table in the DOM
        this.updateInterferenceDataTable();
    }

    /**
     * Draw spectrum with interference markers
     * @param {number} x - X position
     * @param {number} y - Y position
     * @param {number} width - Width
     * @param {number} height - Height
     */
    drawSpectrum(x, y, width, height) {
        if (this.timeHistory.length === 0) {
            return;
        }

        const latestData = this.timeHistory[this.timeHistory.length - 1].powerData;
        const minFreq = this.frequencyData[0];
        const maxFreq = this.frequencyData[this.frequencyData.length - 1];
        const freqRange = maxFreq - minFreq;

        // Find min/max power values
        let minPower = 0;
        let maxPower = -120;

        for (const power of latestData) {
            minPower = Math.min(minPower, power);
            maxPower = Math.max(maxPower, power);
        }

        const powerRange = maxPower - minPower;

        // Draw grid
        this.ctx.strokeStyle = '#333';
        this.ctx.lineWidth = 1;

        // Draw horizontal grid lines
        for (let p = -120; p <= 0; p += 20) {
            const yPos = y + height - ((p - minPower) / powerRange) * height;

            this.ctx.beginPath();
            this.ctx.moveTo(x, yPos);
            this.ctx.lineTo(x + width, yPos);
            this.ctx.stroke();

            // Draw power label
            this.ctx.fillStyle = '#888';
            this.ctx.font = '10px Arial';
            this.ctx.textAlign = 'left';
            this.ctx.fillText(`${p} dBm`, x + 5, yPos - 2);
        }

        // Draw vertical grid lines
        const freqStep = 50e6; // 50 MHz
        for (let f = Math.ceil(minFreq / freqStep) * freqStep; f <= maxFreq; f += freqStep) {
            const xPos = x + ((f - minFreq) / freqRange) * width;

            this.ctx.beginPath();
            this.ctx.moveTo(xPos, y);
            this.ctx.lineTo(xPos, y + height);
            this.ctx.stroke();

            // Draw frequency label
            this.ctx.fillStyle = '#888';
            this.ctx.font = '10px Arial';
            this.ctx.textAlign = 'center';
            this.ctx.fillText(`${(f / 1e6).toFixed(0)} MHz`, xPos, y + height - 5);
        }

        // Draw spectrum
        this.ctx.beginPath();
        this.ctx.strokeStyle = '#4CAF50';
        this.ctx.lineWidth = 2;

        for (let i = 0; i < this.frequencyData.length; i++) {
            const xPos = x + ((this.frequencyData[i] - minFreq) / freqRange) * width;
            const yPos = y + height - ((latestData[i] - minPower) / powerRange) * height;

            if (i === 0) {
                this.ctx.moveTo(xPos, yPos);
            } else {
                this.ctx.lineTo(xPos, yPos);
            }
        }

        this.ctx.stroke();

        // Draw threshold line
        this.ctx.beginPath();
        this.ctx.strokeStyle = '#ff9800';
        this.ctx.lineWidth = 1;
        this.ctx.setLineDash([5, 5]);

        const thresholdY = y + height - ((this.detectionThreshold - minPower) / powerRange) * height;
        this.ctx.moveTo(x, thresholdY);
        this.ctx.lineTo(x + width, thresholdY);
        this.ctx.stroke();
        this.ctx.setLineDash([]);

        // Draw detected interferences
        for (const interference of this.detectedInterferences) {
            const xPos = x + ((interference.frequency - minFreq) / freqRange) * width;

            // Get color based on interference type
            const color = this.getInterferenceColor(interference.type);

            // Draw marker
            this.ctx.fillStyle = color;

            // Draw triangle marker
            this.ctx.beginPath();
            this.ctx.moveTo(xPos, y + 10);
            this.ctx.lineTo(xPos - 8, y + 25);
            this.ctx.lineTo(xPos + 8, y + 25);
            this.ctx.closePath();
            this.ctx.fill();

            // Draw bandwidth indicator
            const leftFreq = interference.frequency - interference.bandwidth / 2;
            const rightFreq = interference.frequency + interference.bandwidth / 2;
            const leftX = x + ((leftFreq - minFreq) / freqRange) * width;
            const rightX = x + ((rightFreq - minFreq) / freqRange) * width;

            this.ctx.fillStyle = `${color}44`; // Semi-transparent
            this.ctx.fillRect(leftX, y, rightX - leftX, height);
        }
    }

    /**
     * Draw interference table
     * @param {number} x - X position
     * @param {number} y - Y position
     * @param {number} width - Width
     * @param {number} height - Height
     */
    drawInterferenceTable(x, y, width, height) {
        // Table header
        const headerHeight = 30;
        this.ctx.fillStyle = '#1a1a1a';
        this.ctx.fillRect(x, y, width, headerHeight);

        this.ctx.fillStyle = '#fff';
        this.ctx.font = '14px Arial';
        this.ctx.textAlign = 'left';

        // Define column widths
        const columns = [
            { name: 'Type', width: 0.15 },
            { name: 'Frequency', width: 0.25 },
            { name: 'Power', width: 0.15 },
            { name: 'Bandwidth', width: 0.25 },
            { name: 'Time', width: 0.2 }
        ];

        let xOffset = x + 10;
        for (const column of columns) {
            this.ctx.fillText(column.name, xOffset, y + 20);
            xOffset += column.width * width;
        }

        // Table rows
        const rowHeight = 25;
        const maxRows = Math.floor((height - headerHeight) / rowHeight);
        const recentInterferences = this.interferenceEvents
            .slice(-maxRows)
            .reverse(); // Show most recent first

        for (let i = 0; i < Math.min(maxRows, recentInterferences.length); i++) {
            const rowY = y + headerHeight + i * rowHeight;
            const interference = recentInterferences[i];

            // Alternate row background
            if (i % 2 === 0) {
                this.ctx.fillStyle = '#121212';
            } else {
                this.ctx.fillStyle = '#0a0a0a';
            }
            this.ctx.fillRect(x, rowY, width, rowHeight);

            // Get color based on interference type
            const color = this.getInterferenceColor(interference.type);

            // Draw row values
            xOffset = x + 10;
            this.ctx.fillStyle = color;
            this.ctx.font = '12px Arial';

            // Type
            
            this.ctx.fillText(interference.type, xOffset, rowY + 17);
            xOffset += columns[0].width * width;
            
            // Frequency
            this.ctx.fillStyle = '#fff';
            this.ctx.fillText(`${(interference.frequency / 1e6).toFixed(3)} MHz`, xOffset, rowY + 17);
            xOffset += columns[1].width * width;
            
            // Power
            this.ctx.fillText(`${interference.power.toFixed(1)} dBm`, xOffset, rowY + 17);
            xOffset += columns[2].width * width;
            
            // Bandwidth
            this.ctx.fillText(`${(interference.bandwidth / 1e3).toFixed(1)} kHz`, xOffset, rowY + 17);
            xOffset += columns[3].width * width;
            
            // Time
            const timeAgo = Math.floor((Date.now() - interference.timestamp) / 1000);
            this.ctx.fillText(`${timeAgo}s ago`, xOffset, rowY + 17);
        }
    }

    /**
     * Update the interference data table in the DOM
     */
    updateInterferenceDataTable() {
        const dataDiv = document.getElementById('interferenceData');
        if (!dataDiv) return;
        
        // Clear existing content
        dataDiv.innerHTML = '';
        
        // Create table element
        const table = document.createElement('table');
        table.className = 'interference-table';
        
        // Create header row
        const header = document.createElement('tr');
        ['Type', 'Frequency (MHz)', 'Power (dBm)', 'Bandwidth (kHz)', 'Time'].forEach(text => {
            const th = document.createElement('th');
            th.textContent = text;
            header.appendChild(th);
        });
        
        table.appendChild(header);
        
        // Add data rows (most recent 10 events)
        const recentInterferences = this.interferenceEvents.slice(-10).reverse();
        
        for (const interference of recentInterferences) {
            const row = document.createElement('tr');
            
            // Type with color
            const typeCell = document.createElement('td');
            typeCell.textContent = interference.type;
            typeCell.style.color = this.getInterferenceColor(interference.type);
            row.appendChild(typeCell);
            
            // Frequency
            const freqCell = document.createElement('td');
            freqCell.textContent = (interference.frequency / 1e6).toFixed(3);
            row.appendChild(freqCell);
            
            // Power
            const powerCell = document.createElement('td');
            powerCell.textContent = interference.power.toFixed(1);
            row.appendChild(powerCell);
            
            // Bandwidth
            const bwCell = document.createElement('td');
            bwCell.textContent = (interference.bandwidth / 1e3).toFixed(1);
            row.appendChild(bwCell);
            
            // Time
            const timeCell = document.createElement('td');
            const timeAgo = Math.floor((Date.now() - interference.timestamp) / 1000);
            timeCell.textContent = `${timeAgo}s ago`;
            row.appendChild(timeCell);
            
            table.appendChild(row);
        }
        
        dataDiv.appendChild(table);
    }

    /**
     * Get color for interference type
     * @param {string} type - Interference type
     * @returns {string} Color in CSS format
     */
    getInterferenceColor(type) {
        switch (type) {
            case 'CW':        return '#ff5722'; // Deep Orange
            case 'Pulsed':    return '#e91e63'; // Pink
            case 'Sweep':     return '#9c27b0'; // Purple
            case 'WBFM':      return '#3f51b5'; // Indigo
            case 'CDMA':      return '#00bcd4'; // Cyan
            case 'Adjacent':  return '#ffc107'; // Amber
            default:          return '#ffffff'; // White
        }
    }
}