/**
 * Main application script for GEO Satellite Digital Spectrum Analyzer
 */

document.addEventListener('DOMContentLoaded', () => {
    // 创建对象
    const uiController = new UIController();
    const device = new SDRDevice(apiClient);
    const tcpClient = new TCPClient();
    const carrierAnalyzer = new CarrierAnalyzer();
    const modulationAnalyzer = new ModulationAnalyzer();

    // 创建连接控制器
    const connectionController = new ConnectionController();

    // 设置设备、TCP客户端和分析器到UI控制器
    uiController.setDevice(device);
    uiController.setCarrierAnalyzer(carrierAnalyzer);
    uiController.setModulationAnalyzer(modulationAnalyzer);

    // 设置TCP客户端到设备
    device.setTCPClient(tcpClient);

    // 初始化连接控制器
    connectionController.initialize(device, tcpClient, apiClient, uiController);

    // 从localStorage加载连接参数
    document.getElementById('settingsView').addEventListener('click', () => {
        // 延迟以确保设置视图已加载
        setTimeout(() => {
            connectionController.loadConnectionParams();
        }, 100);
    });
    
    // Last processed data
    let lastFrequencyData = null;
    let lastPowerData = null;
    let lastIQData = null;
    
    // IQ data buffer for analysis
    const iqBuffer = {
        i: [],
        q: [],
        maxLength: 100000 // Maximum buffer length
    };
    
    // Processing parameters
    const processingParams = {
        fftSize: CONFIG.SPECTRUM.DEFAULT_FFT_SIZE,
        windowType: CONFIG.SPECTRUM.DEFAULT_WINDOW,
        averagingType: 'rms',
        averagingCount: 10
    };
    
    // Register event handlers for data from API
    apiClient.on('data', handleData);
    apiClient.on('status', handleStatus);
    apiClient.on('error', handleError);
    
    // Register TCP event handlers
    tcpClient.on('data', handleTCPData);
    tcpClient.on('connect', () => {
        uiController.showNotification('TCP连接已建立', 'success');
        uiController.elements.connectionStatus.textContent = '已连接(TCP)';
        uiController.elements.connectionStatus.className = 'connected';
    });
    tcpClient.on('disconnect', () => {
        uiController.showNotification('TCP连接已断开', 'warning');
        uiController.elements.connectionStatus.textContent = '已断开';
        uiController.elements.connectionStatus.className = 'disconnected';
    });
    tcpClient.on('error', (error) => {
        uiController.showNotification(`TCP错误: ${error.message}`, 'error');
    });
    
    // Initialize API client and device
    initializeSystem();
    
    /**
     * Initialize the system
     */
    async function initializeSystem() {
        // Check connection type preference from settings or localStorage
        const connectionType = localStorage.getItem('connectionType') || 'api';
        
        // Initialize API client with connection type
        const apiInitialized = await apiClient.initialize(connectionType === 'tcp' ? 'tcp' : 'websocket');
        
        if (apiInitialized) {
            // Initialize device with chosen connection type
            const deviceInitialized = await device.initialize(
                localStorage.getItem('deviceType') || CONFIG.DEVICE.DEFAULT_DEVICE_TYPE,
                connectionType
            );
            
            if (deviceInitialized) {
                uiController.showNotification('系统初始化成功', 'success');
                
                // Update UI with device info
                uiController.updateDeviceInfo();
                uiController.updateFrequencyDisplay();
                
                // Start streaming data
                device.startStreaming();
            } else {
                uiController.showNotification('设备初始化失败', 'error');
            }
        } else {
            uiController.showNotification('API客户端初始化失败', 'error');
        }
    }
    
    /**
     * Handle incoming data from API
     * @param {Object} data - Data from API
     */
    function handleData(data) {
        // Check if data contains IQ samples
        if (data.iq && data.iq.i && data.iq.q) {
            processIQData(data.iq);
        }
    }
    
    /**
     * Handle incoming data from TCP
     * @param {Object} data - Data from TCP
     */
    function handleTCPData(data) {
        // Process received IQ data
        processIQData(data);
    }
    
    /**
     * Process IQ data regardless of source
     * @param {Object} iqData - IQ data with i and q components
     */
    function processIQData(iqData) {
        // Update IQ buffer
        appendToIQBuffer(iqData.i, iqData.q);
        
        // Store last IQ data for analysis
        lastIQData = {
            i: new Float32Array(iqData.i),
            q: new Float32Array(iqData.q)
        };
        
        // Get processing parameters
        const fftSize = parseInt(document.getElementById('fftSize').value) || processingParams.fftSize;
        const windowType = document.getElementById('windowType').value || processingParams.windowType;
        
        // 应用RBW滤波 (如果启用)
        let processedIQData = iqData;
        if (device.dspProcessor) {
            processedIQData = device.dspProcessor.processIQData(iqData, device.getSettings().sampleRate * 1e6);
        }
        
        // 执行FFT
        const fftResult = DSPUtils.performFFT(processedIQData, windowType, fftSize);
        
        // 计算频率数组
        const sampleRate = device.getSettings().sampleRate * 1e6;
        const centerFreq = device.getSettings().centerFreq * 1e6;
        const frequencyArray = DSPUtils.calculateFreqArray(fftSize, sampleRate, centerFreq);
        
        // 应用VBW滤波 (如果启用)
        let processedPowerData = fftResult.powerDb;
        if (device.dspProcessor) {
            const processed = device.dspProcessor.processSpectrumData(frequencyArray, fftResult.powerDb);
            processedPowerData = processed.powers;
        }
        
        // 保存处理后的数据
        lastFrequencyData = frequencyArray;
        lastPowerData = processedPowerData;
        
        // 更新显示和分析
        updateDisplays(frequencyArray, processedPowerData, iqData);
    }
    
    /**
     * Update all displays and analyzers with new data
     * @param {Array} frequencyData - Frequency data
     * @param {Array} powerData - Power data
     * @param {Object} iqData - IQ data
     */
    function updateDisplays(frequencyData, powerData, iqData) {
        // Update spectrum display
        if (uiController.activeView === 'spectrumView') {
            uiController.displays.spectrum.draw(frequencyData, powerData);
            uiController.updateMarkerList();
        }
        
        // Update waterfall display
        if (uiController.activeView === 'waterfallView' || uiController.activeView === 'spectrumView') {
            uiController.displays.waterfall.addData(frequencyData, powerData);
        }
        
        // Update constellation display
        if (uiController.activeView === 'constellationView') {
            uiController.displays.constellation.addData(iqData);
        }
        
        // Update interference analyzer
        if (uiController.activeView === 'interferenceView') {
            uiController.displays.interference.addData(frequencyData, powerData);
        }
        
        // Analyze carriers
        carrierAnalyzer.setSampleRate(device.getSettings().sampleRate * 1e6);
        carrierAnalyzer.setCenterFrequency(device.getSettings().centerFreq * 1e6);
        const carriers = carrierAnalyzer.analyzeSpectrum(frequencyData, powerData, iqData);
        
        // Update measurements display
        if (carriers && carriers.length > 0) {
            const mainCarrier = carriers[0]; // Use strongest carrier
            uiController.updateMeasurements({
                snr: mainCarrier.snr,
                esn0: mainCarrier.esn0,
                cn: mainCarrier.cn
            });
        }
        
        // Update modulation analyzer
        modulationAnalyzer.setSampleRate(device.getSettings().sampleRate * 1e6);
        modulationAnalyzer.analyzeModulation(iqData, device.getSettings().centerFreq * 1e6);
    }
    
    /**
     * Append data to IQ buffer
     * @param {Array} iData - I component data
     * @param {Array} qData - Q component data
     */
    function appendToIQBuffer(iData, qData) {
        // Add new data to buffer
        iqBuffer.i.push(...iData);
        iqBuffer.q.push(...qData);
        
        // Trim buffer if it exceeds maximum length
        if (iqBuffer.i.length > iqBuffer.maxLength) {
            const excess = iqBuffer.i.length - iqBuffer.maxLength;
            iqBuffer.i.splice(0, excess);
            iqBuffer.q.splice(0, excess);
        }
    }
    
    /**
     * Handle status events from API
     * @param {Object} status - Status data
     */
    function handleStatus(status) {
        if (status.connected !== undefined) {
            if (status.connected) {
                uiController.elements.connectionStatus.textContent = '已连接';
                uiController.elements.connectionStatus.className = 'connected';
            } else {
                uiController.elements.connectionStatus.textContent = '已断开';
                uiController.elements.connectionStatus.className = 'disconnected';
            }
        }
    }
    
    /**
     * Handle error events from API
     * @param {Object} error - Error data
     */
    function handleError(error) {
        uiController.showNotification(error.message || '发生错误', 'error');
    }
    
    // Add event listeners for FFT settings
    document.getElementById('fftSize').addEventListener('change', (e) => {
        processingParams.fftSize = parseInt(e.target.value);
        uiController.updateFrequencyDisplay();
    });
    
    document.getElementById('windowType').addEventListener('change', (e) => {
        processingParams.windowType = e.target.value;
        uiController.updateFrequencyDisplay();
    });
    
    document.getElementById('averagingType').addEventListener('change', (e) => {
        processingParams.averagingType = e.target.value;
    });
    
    document.getElementById('averagingCount').addEventListener('change', (e) => {
        processingParams.averagingCount = parseInt(e.target.value);
    });
    
    // Add TCP connection UI
    document.getElementById('settingsView').addEventListener('click', () => {
        // Delay to ensure settings view is loaded
        setTimeout(() => {
            // Check if TCP settings area already exists
            if (!document.getElementById('tcpSettings')) {
                const settingsGroup = document.createElement('div');
                settingsGroup.className = 'settings-group';
                settingsGroup.id = 'tcpSettings';
                settingsGroup.innerHTML = `
                    <h3>TCP连接设置</h3>
                    <div class="setting">
                        <label for="connectionType">连接类型:</label>
                        <select id="connectionType">
                            <option value="api" ${device.getSettings().connectionType === 'api' ? 'selected' : ''}>API/WebSocket</option>
                            <option value="tcp" ${device.getSettings().connectionType === 'tcp' ? 'selected' : ''}>TCP</option>
                        </select>
                    </div>
                    <div class="setting">
                        <label for="tcpServer">TCP服务器地址:</label>
                        <input type="text" id="tcpServer" value="${CONFIG.TCP.SERVER}">
                    </div>
                    <div class="setting">
                        <label for="tcpPort">端口:</label>
                        <input type="number" id="tcpPort" value="${CONFIG.TCP.PORT}">
                    </div>
                    <div class="setting">
                        <label for="tcpFormat">数据格式:</label>
                        <select id="tcpFormat">
                            <option value="int8" ${CONFIG.TCP.DATA_FORMAT === 'int8' ? 'selected' : ''}>8位整数</option>
                            <option value="int16" ${CONFIG.TCP.DATA_FORMAT === 'int16' ? 'selected' : ''}>16位整数</option>
                            <option value="float32" ${CONFIG.TCP.DATA_FORMAT === 'float32' ? 'selected' : ''}>32位浮点数</option>
                        </select>
                    </div>
                    <div class="setting">
                        <label for="tcpEndianness">字节序:</label>
                        <select id="tcpEndianness">
                            <option value="little" ${CONFIG.TCP.ENDIANNESS === 'little' ? 'selected' : ''}>小端序</option>
                            <option value="big" ${CONFIG.TCP.ENDIANNESS === 'big' ? 'selected' : ''}>大端序</option>
                        </select>
                    </div>
                    <button id="connectTCPBtn" class="settings-btn">连接TCP服务器</button>
                `;
                
                // Add to settings form
                document.querySelector('.settings-form').appendChild(settingsGroup);
                
                // Add connection type change event
                document.getElementById('connectionType').addEventListener('change', (e) => {
                    const connectionType = e.target.value;
                    localStorage.setItem('connectionType', connectionType);
                    
                    // Update TCP settings visibility
                    const tcpSettings = document.querySelectorAll('#tcpSettings .setting:not(:first-child)');
                    for (const setting of tcpSettings) {
                        setting.style.display = connectionType === 'tcp' ? 'block' : 'none';
                    }
                    
                    // Update button text
                    const connectBtn = document.getElementById('connectTCPBtn');
                    connectBtn.textContent = connectionType === 'tcp' ? '连接TCP服务器' : '连接API服务器';
                });
                
                // Trigger change event to set initial visibility
                document.getElementById('connectionType').dispatchEvent(new Event('change'));
                
                // Add connect button event
                document.getElementById('connectTCPBtn').addEventListener('click', () => {
                    const connectionType = document.getElementById('connectionType').value;
                    
                    if (connectionType === 'tcp') {
                        const server = document.getElementById('tcpServer').value;
                        const port = parseInt(document.getElementById('tcpPort').value);
                        const format = document.getElementById('tcpFormat').value;
                        const endianness = document.getElementById('tcpEndianness').value;
                        
                        // Update configuration
                        CONFIG.TCP.SERVER = server;
                        CONFIG.TCP.PORT = port;
                        CONFIG.TCP.DATA_FORMAT = format;
                        CONFIG.TCP.ENDIANNESS = endianness;
                        
                        // Connect to TCP server
                        connectToTCPServer();
                    } else {
                        // Connect using API/WebSocket
                        connectToAPIServer();
                    }
                });
            }
        }, 100);
    });
    
    // 频宽选择变化处理
    document.getElementById('spanFreq').addEventListener('change', (e) => {
        const value = e.target.value;
        if (value === 'custom') {
            document.getElementById('customSpanControl').style.display = 'block';
        } else {
            document.getElementById('customSpanControl').style.display = 'none';
            const span = parseFloat(value);
            if (device) {
                device.setBandwidth(span).then(() => {
                    uiController.updateFrequencyDisplay();
                    uiController.updateRbwVbw();
                });
            }
        }
    });
    
    // 自定义频宽处理
    document.getElementById('customSpan').addEventListener('change', (e) => {
        const span = parseFloat(e.target.value);
        if (device && span >= CONFIG.BANDWIDTH.MIN_BANDWIDTH && span <= CONFIG.BANDWIDTH.MAX_BANDWIDTH) {
            device.setBandwidth(span).then(() => {
                uiController.updateFrequencyDisplay();
                uiController.updateRbwVbw();
            });
        }
    });
    
    // RBW选择变化处理
    document.getElementById('rbwSelect').addEventListener('change', (e) => {
        const value = e.target.value;
        if (value === 'custom') {
            document.getElementById('customRbwControl').style.display = 'block';
            CONFIG.BANDWIDTH.AUTO_RBW = false;
        } else if (value === 'auto') {
            document.getElementById('customRbwControl').style.display = 'none';
            CONFIG.BANDWIDTH.AUTO_RBW = true;
            uiController.updateRbwVbw();
        } else {
            document.getElementById('customRbwControl').style.display = 'none';
            CONFIG.BANDWIDTH.AUTO_RBW = false;
            CONFIG.BANDWIDTH.DEFAULT_RBW = parseFloat(value);
            uiController.updateRbwVbw();
        }
    });
    
    // 自定义RBW处理
    document.getElementById('customRbw').addEventListener('change', (e) => {
        const rbw = parseFloat(e.target.value);
        if (rbw > 0) {
            CONFIG.BANDWIDTH.AUTO_RBW = false;
            CONFIG.BANDWIDTH.DEFAULT_RBW = rbw;
            uiController.updateRbwVbw();
        }
    });
    
    // VBW选择变化处理
    document.getElementById('vbwSelect').addEventListener('change', (e) => {
        const value = e.target.value;
        if (value === 'custom') {
            document.getElementById('customVbwControl').style.display = 'block';
            CONFIG.BANDWIDTH.AUTO_VBW = false;
        } else if (value === 'auto') {
            document.getElementById('customVbwControl').style.display = 'none';
            CONFIG.BANDWIDTH.AUTO_VBW = true;
            uiController.updateRbwVbw();
        } else {
            document.getElementById('customVbwControl').style.display = 'none';
            CONFIG.BANDWIDTH.AUTO_VBW = false;
            CONFIG.BANDWIDTH.DEFAULT_VBW = parseFloat(value);
            uiController.updateRbwVbw();
        }
    });
    
    // 自定义VBW处理
    document.getElementById('customVbw').addEventListener('change', (e) => {
        const vbw = parseFloat(e.target.value);
        if (vbw > 0) {
            CONFIG.BANDWIDTH.AUTO_VBW = false;
            CONFIG.BANDWIDTH.DEFAULT_VBW = vbw;
            uiController.updateRbwVbw();
        }
    });
    
    // VBW/RBW比例变化处理
    document.getElementById('vbwRbwRatio').addEventListener('change', (e) => {
        CONFIG.BANDWIDTH.VBW_RBW_RATIO = parseFloat(e.target.value);
        if (CONFIG.BANDWIDTH.AUTO_VBW) {
            uiController.updateRbwVbw();
        }
    });
    
    // Connect to TCP server
    function connectToTCPServer() {
        // Disconnect current connections
        device.disconnect().then(() => {
            // Update status
            uiController.elements.connectionStatus.textContent = '连接中...';
            uiController.elements.connectionStatus.className = 'connecting';
            
            // Set up device with TCP
            device.setConnectionType('tcp');
            apiClient.setConnectionType('tcp');
            
            // Initialize system with TCP connection
            tcpClient.connect(CONFIG.TCP.SERVER, CONFIG.TCP.PORT)
                .then(() => {
                    // Initialize device with TCP connection
                    device.initialize(
                        document.getElementById('deviceType').value || CONFIG.DEVICE.DEFAULT_DEVICE_TYPE,
                        'tcp'
                    ).then(success => {
                        if (success) {
                            uiController.showNotification('TCP连接和设备初始化成功', 'success');
                            
                            // Update UI
                            uiController.updateDeviceInfo();
                            uiController.updateFrequencyDisplay();
                            
                            // Start streaming
                            device.startStreaming();
                        } else {
                            uiController.showNotification('TCP设备初始化失败', 'error');
                        }
                    });
                })
                .catch(error => {
                    uiController.showNotification(`TCP连接失败: ${error.message}`, 'error');
                    uiController.elements.connectionStatus.textContent = '已断开';
                    uiController.elements.connectionStatus.className = 'disconnected';
                });
        });
    }
    
    // Connect to API server
    function connectToAPIServer() {
        // Disconnect current connections
        device.disconnect().then(() => {
            // Update status
            uiController.elements.connectionStatus.textContent = '连接中...';
            uiController.elements.connectionStatus.className = 'connecting';
            
            // Set connection type
            device.setConnectionType('api');
            apiClient.setConnectionType('websocket');
            
            // Initialize system with API connection
            apiClient.initialize('websocket').then(apiSuccess => {
                if (apiSuccess) {
                    // Initialize device with API connection
                    device.initialize(
                        document.getElementById('deviceType').value || CONFIG.DEVICE.DEFAULT_DEVICE_TYPE,
                        'api'
                    ).then(deviceSuccess => {
                        if (deviceSuccess) {
                            uiController.showNotification('API连接和设备初始化成功', 'success');
                            
                            // Update UI
                            uiController.updateDeviceInfo();
                            uiController.updateFrequencyDisplay();
                            
                            // Start streaming
                            device.startStreaming();
                        } else {
                            uiController.showNotification('API设备初始化失败', 'error');
                        }
                    });
                } else {
                    uiController.showNotification('API连接失败', 'error');
                    uiController.elements.connectionStatus.textContent = '已断开';
                    uiController.elements.connectionStatus.className = 'disconnected';
                }
            });
        });
    }
    
    // Add device type change event to store in localStorage
    document.getElementById('deviceType').addEventListener('change', (e) => {
        localStorage.setItem('deviceType', e.target.value);
    });
    
    // Add record IQ data functionality
    document.getElementById('recordBtn').addEventListener('click', () => {
        showRecordingDialog();
    });
    
    // Show recording dialog
    function showRecordingDialog() {
        // Set modal title
        uiController.elements.modalTitle.textContent = '记录IQ数据';
        
        // Create content
        const content = `
            <div class="recording-dialog">
                <div class="setting">
                    <label for="recordDuration">持续时间(秒):</label>
                    <input type="number" id="recordDuration" value="${CONFIG.RECORDING.DEFAULT_DURATION}" min="1" max="${CONFIG.RECORDING.MAX_DURATION}">
                </div>
                <div class="setting">
                    <label for="recordFilename">文件名:</label>
                    <input type="text" id="recordFilename" value="iq_recording_${Date.now()}">
                </div>
                <div class="setting">
                    <label for="recordFormat">格式:</label>
                    <select id="recordFormat">
                        <option value="binary" selected>二进制(原始IQ)</option>
                        <option value="wav">WAV</option>
                        <option value="siq">SigMF IQ</option>
                        <option value="csv">CSV</option>
                    </select>
                </div>
                <div class="setting">
                    <button id="startRecording" class="settings-btn">开始记录</button>
                </div>
            </div>
        `;
        
        // Set modal content
        uiController.elements.modalContent.innerHTML = content;
        
        // Add event listener for record button
        document.getElementById('startRecording').addEventListener('click', () => {
            const duration = parseInt(document.getElementById('recordDuration').value);
            const filename = document.getElementById('recordFilename').value;
            const format = document.getElementById('recordFormat').value;
            
            startRecording(duration, filename, format);
            uiController.closeModal();
        });
        
        // Show modal
        uiController.showModal();
    }
    
    /**
     * Start recording IQ data
     * @param {number} duration - Recording duration in seconds
     * @param {string} filename - Output filename
     * @param {string} format - Output format
     */
    function startRecording(duration, filename, format) {
        // In a real implementation, this would start recording data
        uiController.showNotification(`记录开始: ${duration}秒, ${format}格式`, 'success');
        
        // Create recording object
        const recording = {
            iqData: {
                i: [],
                q: []
            },
            sampleRate: device.getSettings().sampleRate * 1e6,
            centerFrequency: device.getSettings().centerFreq * 1e6,
            startTime: Date.now(),
            duration: duration,
            format: format,
            filename: filename
        };
        
        // Start recording timer and data collection
        let elapsed = 0;
        const interval = setInterval(() => {
            elapsed++;
            
            // Collect IQ data if available
            if (lastIQData) {
                recording.iqData.i.push(...lastIQData.i);
                recording.iqData.q.push(...lastIQData.q);
            }
            
            // Show progress
            uiController.showNotification(`记录中: ${elapsed}/${duration}秒`, 'info');
            
            if (elapsed >= duration) {
                clearInterval(interval);
                finishRecording(recording);
            }
        }, 1000);
    }
    
    /**
     * Finish recording and save data
     * @param {Object} recording - Recording data
     */
    function finishRecording(recording) {
        // In a real implementation, this would save the data to a file
        // Here we'll just show a notification
        uiController.showNotification(`记录完成: ${recording.filename}.${recording.format}`, 'success');
        
        // Display recording stats
        const stats = {
            duration: recording.duration,
            samples: recording.iqData.i.length,
            sampleRate: recording.sampleRate / 1e6,
            centerFreq: recording.centerFrequency / 1e6,
            fileSize: (recording.iqData.i.length * 8) / (1024 * 1024)
        };
        
        console.log('Recording stats:', stats);
        
        // In a real implementation, we would now save the file
        // using the appropriate format
        
        // Show recording details in modal
        uiController.elements.modalTitle.textContent = '记录完成';
        uiController.elements.modalContent.innerHTML = `
            <div class="recording-details">
                <h3>记录详情</h3>
                <div class="detail-row">
                    <span class="detail-label">文件名:</span>
                    <span class="detail-value">${recording.filename}.${recording.format}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">持续时间:</span>
                    <span class="detail-value">${stats.duration} 秒</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">采样数:</span>
                    <span class="detail-value">${stats.samples.toLocaleString()}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">采样率:</span>
                    <span class="detail-value">${stats.sampleRate.toFixed(2)} MSPS</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">中心频率:</span>
                    <span class="detail-value">${stats.centerFreq.toFixed(3)} MHz</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">文件大小:</span>
                    <span class="detail-value">${stats.fileSize.toFixed(2)} MB</span>
                </div>
            </div>
        `;
        
        uiController.showModal();
    }
    
    // 数据导出功能
    document.getElementById('exportBtn').addEventListener('click', () => {
        const format = document.getElementById('exportFormat').value;
        exportData(format);
    });
    
    /**
     * 导出频谱数据
     * @param {string} format - 导出格式
     */
    function exportData(format) {
        if (!lastFrequencyData || !lastPowerData) {
            uiController.showNotification('没有可用的数据可导出', 'warning');
            return;
        }
        
        uiController.showNotification(`正在导出${format}格式数据...`, 'info');
        
        // 创建导出数据
        const exportData = {
            metadata: {
                timestamp: new Date().toISOString(),
                device: device.getSettings().deviceType,
                centerFrequency: device.getSettings().centerFreq,
                sampleRate: device.getSettings().sampleRate,
                bandwidth: device.getSettings().bandwidth,
                rbw: parseFloat(document.getElementById('rbwDisplay').textContent),
                vbw: parseFloat(document.getElementById('vbwDisplay').textContent)
            },
            spectrumData: []
        };
        
        // 组合频率和功率数据
        for (let i = 0; i < lastFrequencyData.length; i++) {
            exportData.spectrumData.push({
                frequency: lastFrequencyData[i] / 1e6, // 转换为MHz
                power: lastPowerData[i]
            });
        }
        
        // 根据格式处理数据
        switch (format) {
            case 'csv':
                exportCSV(exportData);
                break;
            case 'json':
                exportJSON(exportData);
                break;
            case 'binary':
                exportBinary(exportData);
                break;
            case 'raw_iq':
                exportRawIQ();
                break;
            default:
                uiController.showNotification('不支持的导出格式', 'error');
        }
    }
    
    /**
     * 导出CSV格式数据
     * @param {Object} data - 要导出的数据
     */
    function exportCSV(data) {
        // 创建CSV头
        let csvContent = "频率(MHz),功率(dBm),时间戳\n";
        
        // 添加数据行
        data.spectrumData.forEach(point => {
            csvContent += `${point.frequency.toFixed(6)},${point.power.toFixed(2)},${data.metadata.timestamp}\n`;
        });
        
        // 创建并下载文件
        downloadFile(csvContent, `spectrum_${Date.now()}.csv`, 'text/csv');
        
        uiController.showNotification('CSV数据导出成功', 'success');
    }
    
    /**
     * 导出JSON格式数据
     * @param {Object} data - 要导出的数据
     */
    function exportJSON(data) {
        // 将对象转换为JSON字符串
        const jsonContent = JSON.stringify(data, null, 2);
        
        // 创建并下载文件
        downloadFile(jsonContent, `spectrum_${Date.now()}.json`, 'application/json');
        
        uiController.showNotification('JSON数据导出成功', 'success');
    }
    
    /**
     * 导出二进制格式数据
     * @param {Object} data - 要导出的数据
     */
    function exportBinary(data) {
        // 创建二进制头 (简单格式:频率+功率)
        const buffer = new ArrayBuffer(8 + data.spectrumData.length * 8); // 头部8字节 + 每点8字节
        const view = new DataView(buffer);
        
        // 写入头部信息
        view.setFloat64(0, data.metadata.centerFrequency * 1e6, true); // 中心频率(Hz)
        
        // 写入数据
        for (let i = 0; i < data.spectrumData.length; i++) {
            view.setFloat32(8 + i * 8, data.spectrumData[i].frequency * 1e6, true); // 频率(Hz)
            view.setFloat32(8 + i * 8 + 4, data.spectrumData[i].power, true); // 功率(dBm)
        }
        
        // 创建并下载文件
        downloadBinaryFile(buffer, `spectrum_${Date.now()}.bin`);
        
        uiController.showNotification('二进制数据导出成功', 'success');
    }
    
    /**
     * 导出原始IQ数据
     */
    function exportRawIQ() {
        if (!lastIQData || !lastIQData.i || !lastIQData.q) {
            uiController.showNotification('没有可用的IQ数据可导出', 'warning');
            return;
        }
        
        // 创建二进制缓冲区
        const buffer = new ArrayBuffer(16 + lastIQData.i.length * 8); // 头部16字节 + I/Q数据
        const view = new DataView(buffer);
        
        // 写入头部信息
        view.setFloat64(0, device.getSettings().centerFreq * 1e6, true); // 中心频率(Hz)
        view.setFloat64(8, device.getSettings().sampleRate * 1e6, true); // 采样率(Hz)
        
        // 写入I/Q数据
        for (let i = 0; i < lastIQData.i.length; i++) {
            view.setFloat32(16 + i * 8, lastIQData.i[i], true); // I
            view.setFloat32(16 + i * 8 + 4, lastIQData.q[i], true); // Q
        }
        
        // 创建并下载文件
        downloadBinaryFile(buffer, `iq_data_${Date.now()}.iq`);
        
        uiController.showNotification('IQ数据导出成功', 'success');
    }
    
    /**
     * 下载文本文件
     * @param {string} content - 文件内容
     * @param {string} filename - 文件名
     * @param {string} type - MIME类型
     */
    function downloadFile(content, filename, type) {
        const blob = new Blob([content], { type: type });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        link.click();
        URL.revokeObjectURL(url);
    }
    
    /**
     * 下载二进制文件
     * @param {ArrayBuffer} buffer - 二进制缓冲区
     * @param {string} filename - 文件名
     */
    function downloadBinaryFile(buffer, filename) {
        const blob = new Blob([buffer], { type: 'application/octet-stream' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        link.click();
        URL.revokeObjectURL(url);
    }
    
    // Simulate data for testing if in development environment
    if (location.hostname === 'localhost' || location.hostname === '127.0.0.1') {
        console.log('开发环境：启动模拟数据生成');
        startDataSimulation();
    }
    
    /**
     * Generate simulated data for testing
     */
    function startDataSimulation() {
        // Configuration for simulation
        const simulationConfig = {
            sampleRate: 61.44e6, // 61.44 MHz
            centerFreq: 1500e6,  // 1500 MHz
            bufferSize: 8192,    // IQ buffer size
            updateInterval: 100, // ms between updates
            signals: [
                { type: 'carrier', freq: -30e6, power: -20, bandwidth: 2e6, modulation: 'QPSK' },
                { type: 'carrier', freq: 10e6, power: -25, bandwidth: 5e6, modulation: '16QAM' },
                { type: 'interference', freq: -60e6, power: -40, type: 'CW' }
            ],
            noise: {
                floor: -70, // dBm
                variance: 2  // dB
            }
        };
        
        // Set simulated device parameters
        device.currentSettings.sampleRate = simulationConfig.sampleRate / 1e6;
        device.currentSettings.centerFreq = simulationConfig.centerFreq / 1e6;
        
        // Update UI
        uiController.updateDeviceInfo();
        uiController.updateFrequencyDisplay();
        
        // Start simulation
        let simulationRunning = true;
        
        // Generate simulated data periodically
        const simulationInterval = setInterval(() => {
            if (!simulationRunning) {
                clearInterval(simulationInterval);
                return;
            }
            
            // Generate IQ data
            const simulatedData = generateSimulatedData(simulationConfig);
            
            // Send data to handler
            handleData({ iq: simulatedData });
            
        }, simulationConfig.updateInterval);
        
        // Stop simulation when page is closed
        window.addEventListener('beforeunload', () => {
            simulationRunning = false;
        });
    }
    
    /**
     * Generate simulated IQ data
     * @param {Object} config - Simulation configuration
     * @returns {Object} IQ data
     */
    function generateSimulatedData(config) {
        const bufferSize = config.bufferSize;
        const iData = new Float32Array(bufferSize);
        const qData = new Float32Array(bufferSize);
        
        // Time step
        const timeStep = 1 / config.sampleRate;
        
        // Generate noise floor
        for (let i = 0; i < bufferSize; i++) {
            // Generate Gaussian noise
            const noiseI = (Math.random() + Math.random() + Math.random() + Math.random() - 2) * 0.5;
            const noiseQ = (Math.random() + Math.random() + Math.random() + Math.random() - 2) * 0.5;
            
            // Convert noise floor from dBm to amplitude
            const noiseFloor = Math.pow(10, config.noise.floor / 20) / 1000;
            const noiseVariance = Math.pow(10, config.noise.variance / 20);
            
            iData[i] = noiseI * noiseFloor * noiseVariance;
            qData[i] = noiseQ * noiseFloor * noiseVariance;
        }
        
        // Add signals
        for (const signal of config.signals) {
            // Convert frequency offset to radians per sample
            const freqOffset = 2 * Math.PI * signal.freq * timeStep;
            
            // Convert power from dBm to amplitude
            const amplitude = Math.pow(10, signal.power / 20) / 1000;
            
            if (signal.type === 'carrier') {
                // Get symbol rate from bandwidth
                const symbolRate = signal.bandwidth / 2;
                const samplesPerSymbol = Math.floor(config.sampleRate / symbolRate);
                
                // Generate modulated signal
                let symbolI = 1;
                let symbolQ = 0;
                let symbolCounter = 0;
                
                for (let i = 0; i < bufferSize; i++) {
                    // Generate new symbol when needed
                    if (symbolCounter === 0) {
                        switch (signal.modulation) {
                            case 'BPSK':
                                symbolI = Math.random() > 0.5 ? 1 : -1;
                                symbolQ = 0;
                                break;
                            case 'QPSK':
                                symbolI = Math.random() > 0.5 ? 1 : -1;
                                symbolQ = Math.random() > 0.5 ? 1 : -1;
                                break;
                            case '16QAM':
                                symbolI = (Math.floor(Math.random() * 4) - 1.5) * 0.6667;
                                symbolQ = (Math.floor(Math.random() * 4) - 1.5) * 0.6667;
                                break;
                            default:
                                symbolI = Math.random() > 0.5 ? 1 : -1;
                                symbolQ = Math.random() > 0.5 ? 1 : -1;
                        }
                    }
                    
                    // Apply signal to buffer
                    const time = i * timeStep;
                    const phase = freqOffset * i;
                    iData[i] += amplitude * (symbolI * Math.cos(phase) - symbolQ * Math.sin(phase));
                    qData[i] += amplitude * (symbolI * Math.sin(phase) + symbolQ * Math.cos(phase));
                    
                    // Update symbol counter
                    symbolCounter = (symbolCounter + 1) % samplesPerSymbol;
                }
            } else if (signal.type === 'interference') {
                // Generate interference signal
                for (let i = 0; i < bufferSize; i++) {
                    const time = i * timeStep;
                    const phase = freqOffset * i;
                    
                    if (signal.type === 'CW') {
                        // Continuous wave
                        iData[i] += amplitude * Math.cos(phase);
                        qData[i] += amplitude * Math.sin(phase);
                    } else if (signal.type === 'Pulsed') {
                        // Pulsed interference
                        const pulseFreq = 1000; // Hz
                        const pulseOn = Math.sin(2 * Math.PI * pulseFreq * time) > 0;
                        if (pulseOn) {
                            iData[i] += amplitude * Math.cos(phase);
                            qData[i] += amplitude * Math.sin(phase);
                        }
                    } else if (signal.type === 'Sweep') {
                        // Frequency sweep
                        const sweepRate = 1e6; // Hz/s
                        const sweepPhase = phase + Math.PI * sweepRate * time * time;
                        iData[i] += amplitude * Math.cos(sweepPhase);
                        qData[i] += amplitude * Math.sin(sweepPhase);
                    }
                }
            }
        }
        
        return { i: iData, q: qData };
    }
});