/**
 * Modulation Analyzer for digital modulation analysis
 */

class ModulationAnalyzer {
    constructor() {
        this.autoRecognition = CONFIG.MODULATION.AUTOMATIC_RECOGNITION;
        this.symbolRate = CONFIG.MODULATION.DEFAULT_SYMBOL_RATE * 1e6; // Convert to Hz
        this.currentModulation = null;
        this.modParams = {};
        this.constellationPoints = [];
        this.symbolTiming = [];
        this.eyeDiagram = [];
        this.sampleRate = CONFIG.DEVICE.DEFAULT_SAMPLE_RATE * 1e6;
    }

    /**
     * Set automatic recognition mode
     * @param {boolean} enabled - Whether auto recognition is enabled
     */
    setAutoRecognition(enabled) {
        this.autoRecognition = enabled;
    }

    /**
     * Set symbol rate
     * @param {number} symbolRate - Symbol rate in symbols per second
     */
    setSymbolRate(symbolRate) {
        this.symbolRate = symbolRate;
    }

    /**
     * Set sample rate
     * @param {number} sampleRate - Sample rate in Hz
     */
    setSampleRate(sampleRate) {
        this.sampleRate = sampleRate;
    }

    /**
     * Analyze IQ data for modulation parameters
     * @param {Object} iqData - IQ data with i and q components
     * @param {number} centerFreq - Center frequency of the signal in Hz
     * @returns {Object} Analysis results
     */
    analyzeModulation(iqData, centerFreq) {
        // Check if enough data is available
        if (!iqData || !iqData.i || !iqData.q || iqData.i.length < 1000) {
            return null;
        }
        
        // Normalize IQ data
        const normalizedIQ = this.normalizeIQData(iqData);
        
        // Generate constellation points
        this.constellationPoints = DSPUtils.generateConstellationPoints(normalizedIQ, 1000);
        
        // Detect modulation if auto recognition is enabled
        if (this.autoRecognition) {
            this.currentModulation = this.detectModulationType(normalizedIQ);
        }
        
        // Calculate modulation parameters
        this.modParams = this.calculateModulationParameters(normalizedIQ, this.currentModulation);
        
        // Generate eye diagram for visualization
        this.generateEyeDiagram(normalizedIQ);
        
        // Generate symbol timing estimation
        this.estimateSymbolTiming(normalizedIQ);
        
        // Return analysis results
        return {
            modulation: this.currentModulation,
            constellation: this.constellationPoints,
            eyeDiagram: this.eyeDiagram,
            symbolTiming: this.symbolTiming,
            parameters: this.modParams
        };
    }

    /**
     * Normalize IQ data for analysis
     * @param {Object} iqData - IQ data with i and q components
     * @returns {Object} Normalized IQ data
     */
    normalizeIQData(iqData) {
        // Find maximum amplitude
        let maxAmp = 0;
        for (let i = 0; i < iqData.i.length; i++) {
            const amp = Math.sqrt(iqData.i[i] * iqData.i[i] + iqData.q[i] * iqData.q[i]);
            maxAmp = Math.max(maxAmp, amp);
        }
        
        // Skip if maximum amplitude is too small
        if (maxAmp < 1e-6) {
            return iqData;
        }
        
        // Normalize by maximum amplitude
        const scale = 1.0 / maxAmp;
        
        const normalizedI = new Float32Array(iqData.i.length);
        const normalizedQ = new Float32Array(iqData.q.length);
        
        // Apply normalization
        for (let i = 0; i < iqData.i.length; i++) {
            normalizedI[i] = iqData.i[i] * scale;
            normalizedQ[i] = iqData.q[i] * scale;
        }
        
        return {
            i: normalizedI,
            q: normalizedQ
        };
    }

    /**
     * Detect modulation type from IQ data
     * @param {Object} iqData - IQ data with i and q components
     * @returns {string} Detected modulation type
     */
    detectModulationType(iqData) {
        // This is a simplified modulation detection algorithm
        // In a real implementation, it would use more sophisticated techniques
        
        // Generate denser constellation for analysis
        const points = DSPUtils.generateConstellationPoints(iqData, 2000);
        
        // Calculate distance from each point to origin
        const distances = points.map(p => Math.sqrt(p[0] * p[0] + p[1] * p[1]));
        
        // Calculate variance of distances
        const meanDist = distances.reduce((sum, d) => sum + d, 0) / distances.length;
        const varDist = distances.reduce((sum, d) => sum + Math.pow(d - meanDist, 2), 0) / distances.length;
        
        // Calculate phase angles
        const angles = points.map(p => Math.atan2(p[1], p[0]));
        
        // Count unique phase clusters (simplified)
        const phaseBins = new Array(36).fill(0); // 10-degree bins
        for (const angle of angles) {
            const bin = Math.floor((angle + Math.PI) * 18 / Math.PI) % 36;
            phaseBins[bin]++;
        }
        
        let significantBins = 0;
        const threshold = points.length / 20; // 5% of points
        for (const bin of phaseBins) {
            if (bin > threshold) {
                significantBins++;
            }
        }
        
        // Simple heuristic detection based on phase distribution and amplitude variance
        if (significantBins <= 2) {
            return 'BPSK';
        } else if (significantBins <= 4) {
            return 'QPSK';
        } else if (significantBins <= 8) {
            return '8PSK';
        } else {
            // QAM detection based on amplitude variance
            if (varDist < 0.05) {
                // PSK-like - all points at similar distance from origin
                return '8PSK';
            } else {
                // Estimate number of clusters
                const clusters = this.estimateNumberOfClusters(points);
                
                if (clusters <= 16) {
                    return '16QAM';
                } else if (clusters <= 64) {
                    return '64QAM';
                } else {
                    return '256QAM';
                }
            }
        }
    }

    /**
     * Estimate number of clusters in constellation points
     * @param {Array} points - Constellation points
     * @returns {number} Estimated number of clusters
     */
    estimateNumberOfClusters(points) {
        // This is a simplified algorithm for cluster counting
        // Real implementation would use k-means or DBSCAN
        
        const gridSize = 8;
        const grid = new Array(gridSize * gridSize).fill(0);
        
        // Count points in each grid cell
        for (const point of points) {
            const x = Math.floor((point[0] + 1.5) * gridSize / 3);
            const y = Math.floor((point[1] + 1.5) * gridSize / 3);
            
            if (x >= 0 && x < gridSize && y >= 0 && y < gridSize) {
                grid[y * gridSize + x]++;
            }
        }
        
        // Count cells with significant number of points
        const threshold = points.length / (gridSize * gridSize * 2);
        let clusters = 0;
        
        for (const count of grid) {
            if (count > threshold) {
                clusters++;
            }
        }
        
        return clusters;
    }

    /**
     * Calculate modulation parameters based on modulation type
     * @param {Object} iqData - IQ data with i and q components
     * @param {string} modulation - Modulation type
     * @returns {Object} Modulation parameters
     */
    calculateModulationParameters(iqData, modulation) {
        // Default parameters
        const params = {
            evm: 0,          // Error Vector Magnitude
            mse: 0,          // Mean Square Error
            snr: 0,          // Signal to Noise Ratio
            phaseError: 0,   // Phase Error
            frequencyError: 0 // Frequency Error
        };
        
        // Skip if modulation is unknown
        if (!modulation) {
            return params;
        }
        
        // Generate ideal constellation based on modulation type
        const idealConstellation = this.generateIdealConstellation(modulation);
        
        // Calculate EVM and other parameters
        params.evm = this.calculateEVM(this.constellationPoints, idealConstellation, modulation);
        params.mse = this.calculateMSE(this.constellationPoints, idealConstellation, modulation);
        params.snr = this.calculateConstellationSNR(params.evm);
        params.phaseError = this.estimatePhaseError(iqData);
        params.frequencyError = this.estimateFrequencyError(iqData);
        
        return params;
    }

    /**
     * Generate ideal constellation points for given modulation
     * @param {string} modulation - Modulation type
     * @returns {Array} Ideal constellation points
     */
    generateIdealConstellation(modulation) {
        switch (modulation) {
            case 'BPSK':
                return [
                    [-1, 0], [1, 0]
                ];
                
            case 'QPSK':
                return [
                    [-0.7071, -0.7071], [-0.7071, 0.7071], 
                    [0.7071, -0.7071], [0.7071, 0.7071]
                ];
                
            case '8PSK':
                const points8PSK = [];
                for (let i = 0; i < 8; i++) {
                    const angle = i * Math.PI / 4;
                    points8PSK.push([Math.cos(angle), Math.sin(angle)]);
                }
                return points8PSK;
                
            case '16QAM':
                const points16QAM = [];
                const values16QAM = [-0.9487, -0.3162, 0.3162, 0.9487];
                for (let i = 0; i < values16QAM.length; i++) {
                    for (let j = 0; j < values16QAM.length; j++) {
                        points16QAM.push([values16QAM[i], values16QAM[j]]);
                    }
                }
                return points16QAM;
                
            case '64QAM':
                const points64QAM = [];
                const values64QAM = [-1.1667, -0.8333, -0.5, -0.1667, 0.1667, 0.5, 0.8333, 1.1667];
                for (let i = 0; i < values64QAM.length; i++) {
                    for (let j = 0; j < values64QAM.length; j++) {
                        points64QAM.push([values64QAM[i], values64QAM[j]]);
                    }
                }
                return points64QAM;
                
            default:
                return [];
        }
    }

    /**
     * Calculate Error Vector Magnitude (EVM)
     * @param {Array} measuredPoints - Measured constellation points
     * @param {Array} idealPoints - Ideal constellation points
     * @param {string} modulation - Modulation type
     * @returns {number} EVM as percentage
     */
    calculateEVM(measuredPoints, idealPoints, modulation) {
        if (measuredPoints.length === 0 || idealPoints.length === 0) {
            return 0;
        }
        
        let totalErrorPower = 0;
        let totalSignalPower = 0;
        let count = 0;
        
        // For each measured point, find the closest ideal point
        for (const measured of measuredPoints) {
            let minDistance = Number.MAX_VALUE;
            let closestIdeal = null;
            
            for (const ideal of idealPoints) {
                const distance = Math.sqrt(
                    Math.pow(measured[0] - ideal[0], 2) + 
                    Math.pow(measured[1] - ideal[1], 2)
                );
                
                if (distance < minDistance) {
                    minDistance = distance;
                    closestIdeal = ideal;
                }
            }
            
            if (closestIdeal) {
                const errorPower = Math.pow(minDistance, 2);
                const signalPower = Math.pow(closestIdeal[0], 2) + Math.pow(closestIdeal[1], 2);
                
                totalErrorPower += errorPower;
                totalSignalPower += signalPower;
                count++;
            }
        }
        
        if (count === 0 || totalSignalPower === 0) {
            return 0;
        }
        
        // Calculate RMS EVM as percentage
        return 100 * Math.sqrt(totalErrorPower / count) / Math.sqrt(totalSignalPower / count);
    }

    /**
     * Calculate Mean Square Error (MSE)
     * @param {Array} measuredPoints - Measured constellation points
     * @param {Array} idealPoints - Ideal constellation points
     * @param {string} modulation - Modulation type
     * @returns {number} MSE
     */
    calculateMSE(measuredPoints, idealPoints, modulation) {
        if (measuredPoints.length === 0 || idealPoints.length === 0) {
            return 0;
        }
        
        let totalError = 0;
        let count = 0;
        
        // For each measured point, find the closest ideal point
        for (const measured of measuredPoints) {
            let minDistance = Number.MAX_VALUE;
            
            for (const ideal of idealPoints) {
                const distance = Math.sqrt(
                    Math.pow(measured[0] - ideal[0], 2) + 
                    Math.pow(measured[1] - ideal[1], 2)
                );
                
                if (distance < minDistance) {
                    minDistance = distance;
                }
            }
            
            totalError += Math.pow(minDistance, 2);
            count++;
        }
        
        if (count === 0) {
            return 0;
        }
        
        return totalError / count;
    }

    /**
     * Calculate SNR from EVM
     * @param {number} evm - Error Vector Magnitude as percentage
     * @returns {number} SNR in dB
     */
    calculateConstellationSNR(evm) {
        if (evm <= 0) {
            return 100; // Maximum value
        }
        
        // SNR ≈ -20 * log10(EVM/100)
        return -20 * Math.log10(evm / 100);
    }

    /**
     * Estimate frequency error from IQ data
     * @param {Object} iqData - IQ data with i and q components
     * @returns {number} Frequency error in Hz
     */
    estimateFrequencyError(iqData) {
        // This is a simplified algorithm for frequency error estimation
        // Real implementation would use phase unwrapping and linear regression
        
        // Calculate phase for each sample
        const phases = [];
        for (let i = 0; i < Math.min(iqData.i.length, 1000); i++) {
            phases.push(Math.atan2(iqData.q[i], iqData.i[i]));
        }
        
        // Calculate phase differences between consecutive samples
        let totalDiff = 0;
        let count = 0;
        
        for (let i = 1; i < phases.length; i++) {
            let diff = phases[i] - phases[i-1];
            
            // Unwrap phase
            if (diff > Math.PI) diff -= 2 * Math.PI;
            if (diff < -Math.PI) diff += 2 * Math.PI;
            
            totalDiff += diff;
            count++;
        }
        
        if (count === 0) {
            return 0;
        }
        
        // Calculate average phase difference per sample
        const avgPhaseDiff = totalDiff / count;
        
        // Convert to frequency (phase difference per sample * sample rate / (2*PI))
        return avgPhaseDiff * this.sampleRate / (2 * Math.PI);
    }

    /**
     * Estimate phase error from IQ data
     * @param {Object} iqData - IQ data with i and q components
     * @returns {number} Phase error in radians
     */
    estimatePhaseError(iqData) {
        // This function estimates the average phase offset
        // It's a simplified algorithm that works for PSK modulations
        
        if (this.currentModulation !== 'BPSK' && 
            this.currentModulation !== 'QPSK' && 
            this.currentModulation !== '8PSK') {
            return 0; // Only relevant for PSK
        }
        
        // Generate constellation points
        const points = this.constellationPoints;
        
        // Generate ideal constellation
        const idealPoints = this.generateIdealConstellation(this.currentModulation);
        
        // Calculate average phase error
        let totalError = 0;
        let count = 0;
        
        for (const point of points) {
            // Find closest ideal point
            let minDistance = Number.MAX_VALUE;
            let closestIdeal = null;
            
            for (const ideal of idealPoints) {
                const distance = Math.sqrt(
                    Math.pow(point[0] - ideal[0], 2) + 
                    Math.pow(point[1] - ideal[1], 2)
                );
                
                if (distance < minDistance) {
                    minDistance = distance;
                    closestIdeal = ideal;
                }
            }
            
            if (closestIdeal) {
                // Calculate phase of ideal and measured points
                const idealPhase = Math.atan2(closestIdeal[1], closestIdeal[0]);
                const measuredPhase = Math.atan2(point[1], point[0]);
                
                // Calculate phase difference
                let phaseDiff = measuredPhase - idealPhase;
                
                // Unwrap phase
                if (phaseDiff > Math.PI) phaseDiff -= 2 * Math.PI;
                if (phaseDiff < -Math.PI) phaseDiff += 2 * Math.PI;
                
                totalError += phaseDiff;
                count++;
            }
        }
        
        if (count === 0) {
            return 0;
        }
        
        return totalError / count;
    }

    /**
     * Generate eye diagram for signal quality assessment
     * @param {Object} iqData - IQ data with i and q components
     */
    generateEyeDiagram(iqData) {
        // This is a simplified eye diagram generation
        // Real implementation would use precise symbol timing recovery
        
        // Calculate samples per symbol
        const samplesPerSymbol = Math.floor(this.sampleRate / this.symbolRate);
        
        if (samplesPerSymbol < 2) {
            this.eyeDiagram = [];
            return; // Not enough samples per symbol
        }
        
        // Generate eye diagram for I component
        const eyeI = [];
        const eyeQ = [];
        
        // Number of symbols to display
        const symbolsToDisplay = 2;
        
        // Generate traces for eye diagram (2 symbols wide)
        for (let i = 0; i < iqData.i.length - symbolsToDisplay * samplesPerSymbol; i += samplesPerSymbol) {
            const traceI = [];
            const traceQ = [];
            
            for (let j = 0; j < symbolsToDisplay * samplesPerSymbol; j++) {
                traceI.push(iqData.i[i + j]);
                traceQ.push(iqData.q[i + j]);
            }
            
            eyeI.push(traceI);
            eyeQ.push(traceQ);
            
            // Limit the number of traces
            if (eyeI.length >= 50) break;
        }
        
        this.eyeDiagram = {
            i: eyeI,
            q: eyeQ,
            samplesPerSymbol: samplesPerSymbol,
            symbolsToDisplay: symbolsToDisplay
        };
    }

    /**
     * Estimate symbol timing from IQ data
     * @param {Object} iqData - IQ data with i and q components
     */
    estimateSymbolTiming(iqData) {
        // This is a simplified symbol timing estimation
        // Real implementation would use more sophisticated algorithms like Gardner, M&M, etc.
        
        // Calculate samples per symbol
        const samplesPerSymbol = Math.floor(this.sampleRate / this.symbolRate);
        
        if (samplesPerSymbol < 2) {
            this.symbolTiming = [];
            return; // Not enough samples per symbol
        }
        
        // Calculate signal power for timing estimation
        const power = [];
        for (let i = 0; i < iqData.i.length; i++) {
            power.push(iqData.i[i] * iqData.i[i] + iqData.q[i] * iqData.q[i]);
        }
        
        // Find timing using power maximum (simplified approach)
        const timingMetric = [];
        
        for (let i = 0; i < samplesPerSymbol; i++) {
            let sum = 0;
            let count = 0;
            
            for (let j = i; j < power.length; j += samplesPerSymbol) {
                sum += power[j];
                count++;
            }
            
            timingMetric.push(sum / (count || 1));
        }
        
        // Find optimum timing
        let maxVal = -Infinity;
        let optimumTiming = 0;
        
        for (let i = 0; i < timingMetric.length; i++) {
            if (timingMetric[i] > maxVal) {
                maxVal = timingMetric[i];
                optimumTiming = i;
            }
        }
        
        this.symbolTiming = {
            metric: timingMetric,
            optimum: optimumTiming,
            samplesPerSymbol: samplesPerSymbol
        };
    }
}