/**
 * Spectrum Display class for visualizing frequency spectrum
 */

class SpectrumDisplay {
    constructor(canvasId) {
        this.canvas = document.getElementById(canvasId);
        this.ctx = this.canvas.getContext('2d');
        this.displayMode = CONFIG.SPECTRUM.DEFAULT_DISPLAY_MODE;
        this.dynamicRange = CONFIG.SPECTRUM.DEFAULT_DYNAMIC_RANGE;
        this.referenceLevel = CONFIG.SPECTRUM.DEFAULT_REF_LEVEL;
        this.markers = [];
        this.maxHoldData = null;
        this.minData = null;
        this.averageData = null;
        this.averageCount = 0;
        this.averageAlpha = 0.1; // For exponential averaging
        this.frequencyData = null;
        this.fftSize = CONFIG.SPECTRUM.DEFAULT_FFT_SIZE;

        // Initialize canvas size
        this.resizeCanvas();

        // Add resize handler
        window.addEventListener('resize', () => this.resizeCanvas());
    }

    /**
     * Resize canvas to match container size
     */
    resizeCanvas() {
        // Get container dimensions
        const container = this.canvas.parentElement;
        this.canvas.width = container.clientWidth;
        this.canvas.height = container.clientHeight;

        // Redraw if we have data
        if (this.frequencyData && this.powerData) {
            this.draw(this.frequencyData, this.powerData);
        }
    }

    /**
     * Set display mode
     * @param {string} mode - Display mode
     */
    setDisplayMode(mode) {
        if (CONFIG.SPECTRUM.DISPLAY_MODES.includes(mode)) {
            this.displayMode = mode;

            // Reset accumulated data if mode changes
            if (mode === 'normal') {
                this.maxHoldData = null;
                this.minData = null;
                this.averageData = null;
                this.averageCount = 0;
            }
        }
    }

    /**
     * Set dynamic range
     * @param {number} range - Dynamic range in dB
     */
    setDynamicRange(range) {
        this.dynamicRange = range;
    }



    setReferenceLevel(level) {
        this.referenceLevel = level;
    }

    /**
     * Add a marker at specified frequency
     * @param {number} frequency - Frequency in Hz
     * @returns {Object} Marker object
     */
    addMarker(frequency) {
        if (this.markers.length >= CONFIG.SPECTRUM.MAX_MARKERS) {
            console.warn(`Maximum number of markers (${CONFIG.SPECTRUM.MAX_MARKERS}) reached`);
            return null;
        }
        
        const marker = {
            id: Date.now(),
            frequency: frequency,
            power: null // Will be updated during drawing
        };
        
        this.markers.push(marker);
        return marker;
    }

    /**
     * Remove marker by ID
     * @param {number} id - Marker ID
     * @returns {boolean} Success
     */
    removeMarker(id) {
        const initialLength = this.markers.length;
        this.markers = this.markers.filter(marker => marker.id !== id);
        return this.markers.length < initialLength;
    }

    /**
     * Clear all markers
     */
    clearMarkers() {
        this.markers = [];
    }

    /**
     * Add peak marker at the highest power point
     * @returns {Object} Marker object
     */
    addPeakMarker() {
        if (!this.frequencyData || !this.powerData) {
            return null;
        }
        
        // Find peak power
        let peakIndex = 0;
        let peakValue = this.powerData[0];
        
        for (let i = 1; i < this.powerData.length; i++) {
            if (this.powerData[i] > peakValue) {
                peakValue = this.powerData[i];
                peakIndex = i;
            }
        }
        
        return this.addMarker(this.frequencyData[peakIndex]);
    }

    /**
     * Update data based on display mode
     * @param {Array} powerData - Power spectrum data
     * @returns {Array} Updated power data
     */
    updateDisplayData(powerData) {
        const dataLength = powerData.length;
        
        switch (this.displayMode) {
            case 'max-hold':
                if (!this.maxHoldData || this.maxHoldData.length !== dataLength) {
                    this.maxHoldData = new Float32Array(dataLength);
                    for (let i = 0; i < dataLength; i++) {
                        this.maxHoldData[i] = powerData[i];
                    }
                } else {
                    for (let i = 0; i < dataLength; i++) {
                        this.maxHoldData[i] = Math.max(this.maxHoldData[i], powerData[i]);
                    }
                }
                return this.maxHoldData;
                
            case 'average':
                if (!this.averageData || this.averageData.length !== dataLength) {
                    this.averageData = new Float32Array(dataLength);
                    for (let i = 0; i < dataLength; i++) {
                        this.averageData[i] = powerData[i];
                    }
                    this.averageCount = 1;
                } else {
                    // Exponential moving average
                    for (let i = 0; i < dataLength; i++) {
                        this.averageData[i] = this.averageData[i] * (1 - this.averageAlpha) + 
                                              powerData[i] * this.averageAlpha;
                    }
                    this.averageCount++;
                }
                return this.averageData;
                
            case 'min-max':
                if (!this.maxHoldData || this.maxHoldData.length !== dataLength) {
                    this.maxHoldData = new Float32Array(dataLength);
                    this.minData = new Float32Array(dataLength);
                    for (let i = 0; i < dataLength; i++) {
                        this.maxHoldData[i] = powerData[i];
                        this.minData[i] = powerData[i];
                    }
                } else {
                    for (let i = 0; i < dataLength; i++) {
                        this.maxHoldData[i] = Math.max(this.maxHoldData[i], powerData[i]);
                        this.minData[i] = Math.min(this.minData[i], powerData[i]);
                    }
                }
                // Return the current data, draw method will handle drawing both
                return powerData;
                
            default: // 'normal'
                return powerData;
        }
    }

    /**
     * Draw spectrum on canvas
     * @param {Array} frequencyData - Frequency data in Hz
     * @param {Array} powerData - Power spectrum data in dBm
     */
    draw(frequencyData, rawPowerData) {
        if (!frequencyData || !rawPowerData || frequencyData.length !== rawPowerData.length) {
            console.error('Invalid frequency or power data');
            return;
        }
        
        // Store data for later use
        this.frequencyData = frequencyData;
        this.powerData = rawPowerData;
        
        // Update data based on display mode
        const powerData = this.updateDisplayData(rawPowerData);
        
        // Clear canvas
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Get canvas dimensions
        const width = this.canvas.width;
        const height = this.canvas.height;
        
        // Set Y axis limits
        const minPower = this.referenceLevel - this.dynamicRange;
        const maxPower = this.referenceLevel;
        
        // Set X axis limits
        const minFreq = frequencyData[0];
        const maxFreq = frequencyData[frequencyData.length - 1];
        const freqRange = maxFreq - minFreq;
        
        // Draw grid
        this.drawGrid(minFreq, maxFreq, minPower, maxPower);
        
        // Draw spectrum
        this.ctx.beginPath();
        this.ctx.strokeStyle = '#4CAF50';
        this.ctx.lineWidth = 2;
        
        for (let i = 0; i < frequencyData.length; i++) {
            // Map frequency to X coordinate
            const x = ((frequencyData[i] - minFreq) / freqRange) * width;
            
            // Map power to Y coordinate
            const y = height - ((powerData[i] - minPower) / this.dynamicRange) * height;
            
            if (i === 0) {
                this.ctx.moveTo(x, y);
            } else {
                this.ctx.lineTo(x, y);
            }
        }
        
        this.ctx.stroke();
        
        // Draw min-max area if in min-max mode
        if (this.displayMode === 'min-max' && this.maxHoldData && this.minData) {
            this.ctx.fillStyle = 'rgba(76, 175, 80, 0.2)';
            
            // Start a new path for the area
            this.ctx.beginPath();
            
            // Draw top edge (max)
            for (let i = 0; i < frequencyData.length; i++) {
                const x = ((frequencyData[i] - minFreq) / freqRange) * width;
                const y = height - ((this.maxHoldData[i] - minPower) / this.dynamicRange) * height;
                
                if (i === 0) {
                    this.ctx.moveTo(x, y);
                } else {
                    this.ctx.lineTo(x, y);
                }
            }
            
            // Draw bottom edge (min) in reverse
            for (let i = frequencyData.length - 1; i >= 0; i--) {
                const x = ((frequencyData[i] - minFreq) / freqRange) * width;
                const y = height - ((this.minData[i] - minPower) / this.dynamicRange) * height;
                this.ctx.lineTo(x, y);
            }
            
            this.ctx.closePath();
            this.ctx.fill();
        }
        
        // Draw markers
        this.drawMarkers(frequencyData, powerData, minFreq, maxFreq, minPower);
    }

    /**
     * Draw grid on canvas
     * @param {number} minFreq - Minimum frequency
     * @param {number} maxFreq - Maximum frequency
     * @param {number} minPower - Minimum power
     * @param {number} maxPower - Maximum power
     */
    drawGrid(minFreq, maxFreq, minPower, maxPower) {
        const width = this.canvas.width;
        const height = this.canvas.height;
        
        // Draw background
        this.ctx.fillStyle = '#0a0a0a';
        this.ctx.fillRect(0, 0, width, height);
        
        // Grid settings
        this.ctx.strokeStyle = '#333';
        this.ctx.lineWidth = 1;
        
        // Draw horizontal grid lines (power)
        const powerStep = 10; // 10 dB steps
        for (let power = Math.ceil(minPower / powerStep) * powerStep; power <= maxPower; power += powerStep) {
            const y = height - ((power - minPower) / this.dynamicRange) * height;
            
            this.ctx.beginPath();
            this.ctx.moveTo(0, y);
            this.ctx.lineTo(width, y);
            this.ctx.stroke();
            
            // Label the power levels
            this.ctx.fillStyle = '#888';
            this.ctx.font = '10px Arial';
            this.ctx.textAlign = 'left';
            this.ctx.fillText(`${power} dBm`, 5, y - 2);
        }
        
        // Draw vertical grid lines (frequency)
        const freqRange = maxFreq - minFreq;
        let freqStep;
        
        // Determine appropriate frequency step
        if (freqRange > 500e6) {
            freqStep = 100e6; // 100 MHz
        } else if (freqRange > 200e6) {
            freqStep = 50e6;  // 50 MHz
        } else if (freqRange > 100e6) {
            freqStep = 20e6;  // 20 MHz
        } else if (freqRange > 50e6) {
            freqStep = 10e6;  // 10 MHz
        } else {
            freqStep = 5e6;   // 5 MHz
        }
        
        for (let freq = Math.ceil(minFreq / freqStep) * freqStep; freq <= maxFreq; freq += freqStep) {
            const x = ((freq - minFreq) / freqRange) * width;
            
            this.ctx.beginPath();
            this.ctx.moveTo(x, 0);
            this.ctx.lineTo(x, height);
            this.ctx.stroke();
            
            // Label the frequencies
            this.ctx.fillStyle = '#888';
            this.ctx.font = '10px Arial';
            this.ctx.textAlign = 'center';
            this.ctx.fillText(`${(freq / 1e6).toFixed(1)} MHz`, x, height - 5);
        }
    }

    /**
     * Draw markers on canvas
     * @param {Array} frequencyData - Frequency data in Hz
     * @param {Array} powerData - Power spectrum data in dBm
     * @param {number} minFreq - Minimum frequency
     * @param {number} maxFreq - Maximum frequency
     * @param {number} minPower - Minimum power
     */
    drawMarkers(frequencyData, powerData, minFreq, maxFreq, minPower) {
        const width = this.canvas.width;
        const height = this.canvas.height;
        const freqRange = maxFreq - minFreq;
        
        // Update marker power values and draw them
        this.markers.forEach((marker, index) => {
            // Find nearest frequency bin
            let nearestIndex = 0;
            let minDistance = Math.abs(frequencyData[0] - marker.frequency);
            
            for (let i = 1; i < frequencyData.length; i++) {
                const distance = Math.abs(frequencyData[i] - marker.frequency);
                if (distance < minDistance) {
                    minDistance = distance;
                    nearestIndex = i;
                }
            }
            
            // Update marker power
            marker.power = powerData[nearestIndex];
            
            // Calculate marker position
            const x = ((marker.frequency - minFreq) / freqRange) * width;
            const y = height - ((marker.power - minPower) / this.dynamicRange) * height;
            
            // Draw marker
            this.ctx.beginPath();
            this.ctx.arc(x, y, 5, 0, 2 * Math.PI);
            this.ctx.fillStyle = `hsl(${index * 30 % 360}, 100%, 50%)`;
            this.ctx.fill();
            
            // Draw marker label
            this.ctx.font = '12px Arial';
            this.ctx.textAlign = 'left';
            this.ctx.fillStyle = `hsl(${index * 30 % 360}, 100%, 75%)`;
            this.ctx.fillText(`M${index + 1}`, x + 8, y - 8);
            
            // Draw marker info
            const freqText = `${(marker.frequency / 1e6).toFixed(3)} MHz`;
            const powerText = `${marker.power.toFixed(2)} dBm`;
            this.ctx.fillText(`${freqText}, ${powerText}`, x + 8, y + 8);
        });
    }

    /**
     * Get marker data
     * @returns {Array} Array of marker objects
     */
    getMarkerData() {
        return this.markers.map(marker => ({
            id: marker.id,
            frequency: marker.frequency,
            frequencyText: `${(marker.frequency / 1e6).toFixed(3)} MHz`,
            power: marker.power,
            powerText: marker.power !== null ? `${marker.power.toFixed(2)} dBm` : 'N/A'
        }));
    }
}