/**
 * TCP客户端类 - 用于通过WebSocket与TCP服务器通信
 * 支持标准协议和国产设备特定协议
 */
class TCPClient {
    constructor() {
        this.socket = null;
        this.connected = false;
        this.connecting = false;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 5;
        this.reconnectTimeout = 2000; // 毫秒

        // 事件处理器
        this.eventHandlers = {
            'connect': [],
            'disconnect': [],
            'data': [],
            'error': []
        };

        // 添加国产设备协议处理器
        this.protocolHandlers = {
            'standard': this.handleStandardProtocol.bind(this),
            'ge7800': this.handleGE7800Protocol.bind(this),
            'ta8030': this.handleTA8030Protocol.bind(this),
            'ht8200': this.handleHT8200Protocol.bind(this),
            'custom': this.handleCustomProtocol.bind(this)
        };

        // 国产设备的数据解析器
        this.dataParserHandlers = {
            'standard': this.parseStandardData.bind(this),
            'ge7800': this.parseGE7800Data.bind(this),
            'ta8030': this.parseTA8030Data.bind(this),
            'ht8200': this.parseHT8200Data.bind(this),
            'custom': this.parseCustomData.bind(this)
        };

        // 当前协议
        this.currentProtocol = 'standard';

        // 当前数据格式
        this.dataFormat = 'int16';

        // 字节序
        this.endianness = 'little';

        // 自定义协议配置
        this.customProtocolConfig = {
            headerSize: 0,
            commandSequence: [],
            dataMarker: '',
            sizeOffset: 0
        };
    }

    /**
     * 连接到TCP服务器
     * @param {string} host - 服务器主机名或IP
     * @param {number} port - 服务器端口
     * @returns {Promise} 连接Promise
     */
    connect(host = CONFIG.TCP.SERVER, port = CONFIG.TCP.PORT) {
        if (this.connected || this.connecting) {
            console.warn('TCP客户端已连接或正在连接中');
            return Promise.resolve();
        }

        this.connecting = true;

        return new Promise((resolve, reject) => {
            try {
                // 确保之前的socket已关闭
                if (this.socket) {
                    this.socket.close();
                }

                // 使用WebSocket作为代理连接到TCP服务器
                const socketUrl = `ws://${location.hostname}:${CONFIG.TCP.PROXY_PORT}/tcp/${host}/${port}`;
                this.socket = new WebSocket(socketUrl);

                // 设置超时
                const connectionTimeout = setTimeout(() => {
                    if (!this.connected) {
                        this.connecting = false;
                        this.socket.close();
                        reject(new Error('连接TCP服务器超时'));
                    }
                }, 10000);

                // 注册WebSocket事件
                this.socket.onopen = () => {
                    clearTimeout(connectionTimeout);
                    this.connected = true;
                    this.connecting = false;
                    this.reconnectAttempts = 0;
                    console.info(`TCP客户端已连接到 ${host}:${port}`);

                    // 触发连接事件
                    this.triggerEvent('connect');
                    resolve();
                };

                this.socket.onclose = (event) => {
                    clearTimeout(connectionTimeout);

                    // 仅当之前连接成功才触发断开事件
                    if (this.connected) {
                        this.connected = false;
                        console.info(`TCP客户端已断开: ${event.code} - ${event.reason || '无原因'}`);

                        // 触发断开连接事件
                        this.triggerEvent('disconnect');
                    }

                    this.connecting = false;

                    // 如果不是手动关闭，则尝试重连
                    if (event.code !== 1000) {
                        this.attemptReconnect(host, port);
                    }

                    if (this.connecting) {
                        reject(new Error(`连接关闭: ${event.code} - ${event.reason || '无原因'}`));
                    }
                };

                this.socket.onerror = (error) => {
                    clearTimeout(connectionTimeout);
                    this.connecting = false;
                    console.error('TCP客户端错误:', error);

                    // 触发错误事件
                    this.triggerEvent('error', { message: '连接错误', error });

                    reject(new Error('连接TCP服务器时发生错误'));
                };

                this.socket.onmessage = (event) => {
                    this.handleMessage(event.data);
                };

            } catch (error) {
                this.connecting = false;
                console.error('创建TCP连接失败:', error);
                reject(error);
            }
        });
    }

    /**
     * 尝试重新连接
     * @param {string} host - 服务器主机名或IP
     * @param {number} port - 服务器端口
     * @private
     */
    attemptReconnect(host, port) {
        if (this.reconnectAttempts >= this.maxReconnectAttempts) {
            console.warn('达到最大重连次数，停止尝试');
            return;
        }

        this.reconnectAttempts++;

        console.info(`尝试重连(${this.reconnectAttempts}/${this.maxReconnectAttempts})...`);

        setTimeout(() => {
            if (!this.connected && !this.connecting) {
                this.connect(host, port).catch(error => {
                    console.error('重连失败:', error);
                });
            }
        }, this.reconnectTimeout * this.reconnectAttempts);
    }

    /**
     * 断开连接
     */
    disconnect() {
        if (this.socket) {
            // 使用正常关闭代码
            this.socket.close(1000, 'Client disconnected');
            this.socket = null;
        }

        this.connected = false;
        this.connecting = false;
    }

    /**
     * 处理接收到的消息
     * @param {*} data - 接收到的数据
     * @private
     */
    handleMessage(data) {
        if (typeof data === 'string') {
            try {
                // 尝试解析为JSON
                const jsonData = JSON.parse(data);
                this.triggerEvent('data', jsonData);
            } catch (e) {
                // 如果不是有效的JSON，作为文本数据处理
                this.triggerEvent('data', { text: data });
            }
        } else if (data instanceof Blob) {
            // 处理二进制数据
            const reader = new FileReader();
            reader.onload = () => {
                const arrayBuffer = reader.result;
                // 使用当前协议解析二进制数据
                const parsedData = this.parseData(arrayBuffer);
                this.triggerEvent('data', parsedData);
            };
            reader.readAsArrayBuffer(data);
        }
    }

    /**
     * 设置当前协议
     * @param {string} protocol - 协议名称
     */
    setProtocol(protocol) {
        if (this.protocolHandlers[protocol]) {
            this.currentProtocol = protocol;
        } else {
            console.warn(`不支持的协议: ${protocol}，使用标准协议`);
            this.currentProtocol = 'standard';
        }
    }

    /**
     * 设置数据格式
     * @param {string} format - 数据格式 ('int8', 'int16', 'float32')
     */
    setDataFormat(format) {
        if (['int8', 'int16', 'float32'].includes(format)) {
            this.dataFormat = format;
        } else {
            console.warn(`不支持的数据格式: ${format}，使用int16`);
            this.dataFormat = 'int16';
        }
    }

    /**
     * 设置字节序
     * @param {string} endianness - 字节序 ('little', 'big')
     */
    setEndianness(endianness) {
        if (['little', 'big'].includes(endianness)) {
            this.endianness = endianness;
        } else {
            console.warn(`不支持的字节序: ${endianness}，使用little`);
            this.endianness = 'little';
        }
    }

    /**
     * 设置自定义协议配置
     * @param {Object} config - 自定义协议配置
     */
    setCustomProtocolConfig(config) {
        this.customProtocolConfig = {
            ...this.customProtocolConfig,
            ...config
        };
    }

    /**
     * 解析接收到的二进制数据
     * @param {ArrayBuffer} arrayBuffer - 接收到的二进制数据
     * @returns {Object} 解析后的数据
     */
    parseData(arrayBuffer) {
        // 使用协议特定的解析器
        const parser = this.dataParserHandlers[this.currentProtocol] || this.parseStandardData;
        return parser(arrayBuffer);
    }

    /**
     * 解析标准协议数据
     * @param {ArrayBuffer} arrayBuffer - 接收到的二进制数据
     * @returns {Object} 解析后的数据
     */
    parseStandardData(arrayBuffer) {
        const isLittleEndian = this.endianness === 'little';

        // 根据数据格式解析IQ数据
        const dataView = new DataView(arrayBuffer);
        const resultData = {
            i: [],
            q: []
        };

        let bytesPerSample;
        let totalSamples;

        switch (this.dataFormat) {
            case 'int8':
                bytesPerSample = 1;
                totalSamples = Math.floor(arrayBuffer.byteLength / (bytesPerSample * 2));

                for (let i = 0; i < totalSamples; i++) {
                    const iValue = dataView.getInt8(i * 2);
                    const qValue = dataView.getInt8(i * 2 + 1);
                    resultData.i.push(iValue / 128.0); // 归一化为-1.0到1.0
                    resultData.q.push(qValue / 128.0);
                }
                break;

            case 'int16':
                bytesPerSample = 2;
                totalSamples = Math.floor(arrayBuffer.byteLength / (bytesPerSample * 2));

                for (let i = 0; i < totalSamples; i++) {
                    const iValue = dataView.getInt16(i * 4, isLittleEndian);
                    const qValue = dataView.getInt16(i * 4 + 2, isLittleEndian);
                    resultData.i.push(iValue / 32768.0); // 归一化为-1.0到1.0
                    resultData.q.push(qValue / 32768.0);
                }
                break;

            case 'float32':
                bytesPerSample = 4;
                totalSamples = Math.floor(arrayBuffer.byteLength / (bytesPerSample * 2));

                for (let i = 0; i < totalSamples; i++) {
                    const iValue = dataView.getFloat32(i * 8, isLittleEndian);
                    const qValue = dataView.getFloat32(i * 8 + 4, isLittleEndian);
                    resultData.i.push(iValue);
                    resultData.q.push(qValue);
                }
                break;

            default:
                console.error(`不支持的数据格式: ${this.dataFormat}`);
                return { i: [], q: [] };
        }

        return resultData;
    }

    /**
     * 解析中科芯源GE7800协议数据
     * @param {ArrayBuffer} arrayBuffer - 接收到的二进制数据
     * @returns {Object} 解析后的数据
     */
    parseGE7800Data(arrayBuffer) {
        const dataView = new DataView(arrayBuffer);
        const isLittleEndian = this.endianness === 'little';

        // GE7800数据包格式:
        // 头部: [0xAA, 0xBB, 0xCC, 0xDD, data_type(1), data_length(4), timestamp(8), reserved(3)]
        // 数据部分: IQ数据

        // 检查头部标记
        const header = new Uint8Array(arrayBuffer, 0, 4);
        if (header[0] !== 0xAA || header[1] !== 0xBB || header[2] !== 0xCC || header[3] !== 0xDD) {
            console.warn('GE7800数据头部标记无效');
            // 尝试使用标准解析
            return this.parseStandardData(arrayBuffer);
        }

        // 解析头部
        const dataType = dataView.getUint8(4);
        const dataLength = dataView.getUint32(5, isLittleEndian);

        // 头部大小为16字节
        const headerSize = 16;

        // 根据数据类型和格式解析数据
        const resultData = {
            i: [],
            q: []
        };

        // 确保数据类型为IQ数据 (0x01)
        if (dataType === 0x01) {
            let bytesPerSample;
            let totalSamples;

            switch (this.dataFormat) {
                case 'int16':
                    bytesPerSample = 2;
                    totalSamples = Math.floor((arrayBuffer.byteLength - headerSize) / (bytesPerSample * 2));

                    for (let i = 0; i < totalSamples; i++) {
                        const offset = headerSize + i * 4;
                        const iValue = dataView.getInt16(offset, isLittleEndian);
                        const qValue = dataView.getInt16(offset + 2, isLittleEndian);
                        resultData.i.push(iValue / 32768.0);
                        resultData.q.push(qValue / 32768.0);
                    }
                    break;

                case 'float32':
                    bytesPerSample = 4;
                    totalSamples = Math.floor((arrayBuffer.byteLength - headerSize) / (bytesPerSample * 2));

                    for (let i = 0; i < totalSamples; i++) {
                        const offset = headerSize + i * 8;
                        const iValue = dataView.getFloat32(offset, isLittleEndian);
                        const qValue = dataView.getFloat32(offset + 4, isLittleEndian);
                        resultData.i.push(iValue);
                        resultData.q.push(qValue);
                    }
                    break;

                default:
                    console.error(`GE7800协议不支持的数据格式: ${this.dataFormat}`);
                    return { i: [], q: [] };
            }
        } else {
            console.warn(`未知的GE7800数据类型: ${dataType}`);
            return { i: [], q: [] };
        }

        return resultData;
    }

    /**
     * 解析天奥电子TA8030协议数据
     * @param {ArrayBuffer} arrayBuffer - 接收到的二进制数据
     * @returns {Object} 解析后的数据
     */
    parseTA8030Data(arrayBuffer) {
        const dataView = new DataView(arrayBuffer);
        const isLittleEndian = this.endianness === 'little';

        // TA8030数据包格式:
        // 头部: [0xA0, 0x00, 0x00, 0x00, data_type(1), data_length(2), device_id(1)]
        // 数据部分: IQ数据

        // 检查头部标记
        const header = new Uint8Array(arrayBuffer, 0, 4);
        if (header[0] !== 0xA0 || header[1] !== 0x00 || header[2] !== 0x00 || header[3] !== 0x00) {
            console.warn('TA8030数据头部标记无效');
            // 尝试使用标准解析
            return this.parseStandardData(arrayBuffer);
        }

        // 解析头部
        const dataType = dataView.getUint8(4);
        const dataLength = dataView.getUint16(5, isLittleEndian);

        // 头部大小为8字节
        const headerSize = 8;

        // 根据数据类型和格式解析数据
        const resultData = {
            i: [],
            q: []
        };

        // TA8030的数据类型为IQ数据 (0x02)
        if (dataType === 0x02) {
            let bytesPerSample;
            let totalSamples;

            switch (this.dataFormat) {
                case 'int16':
                    bytesPerSample = 2;
                    totalSamples = Math.floor((arrayBuffer.byteLength - headerSize) / (bytesPerSample * 2));

                    for (let i = 0; i < totalSamples; i++) {
                        const offset = headerSize + i * 4;
                        const iValue = dataView.getInt16(offset, isLittleEndian);
                        const qValue = dataView.getInt16(offset + 2, isLittleEndian);
                        resultData.i.push(iValue / 32768.0);
                        resultData.q.push(qValue / 32768.0);
                    }
                    break;

                default:
                    console.error(`TA8030协议不支持的数据格式: ${this.dataFormat}`);
                    return { i: [], q: [] };
            }
        } else {
            console.warn(`未知的TA8030数据类型: ${dataType}`);
            return { i: [], q: [] };
        }

        return resultData;
    }

    /**
     * 解析航天宏图HT8200协议数据
     * @param {ArrayBuffer} arrayBuffer - 接收到的二进制数据
     * @returns {Object} 解析后的数据
     */
    parseHT8200Data(arrayBuffer) {
        const dataView = new DataView(arrayBuffer);
        const isLittleEndian = this.endianness === 'little';

        // HT8200数据包格式:
        // 头部: [0x48, 0x54, 0x82, 0x00, packet_id(4), data_length(4)]
        // 数据部分: IQ数据

        // 检查头部标记
        const header = new Uint8Array(arrayBuffer, 0, 4);
        if (header[0] !== 0x48 || header[1] !== 0x54 || header[2] !== 0x82 || header[3] !== 0x00) {
            console.warn('HT8200数据头部标记无效');
            // 尝试使用标准解析
            return this.parseStandardData(arrayBuffer);
        }

        // 解析头部
        const packetId = dataView.getUint32(4, isLittleEndian);
        const dataLength = dataView.getUint32(8, isLittleEndian);

        // 头部大小为12字节
        const headerSize = 12;

        // 根据数据格式解析数据
        const resultData = {
            i: [],
            q: []
        };

        let bytesPerSample;
        let totalSamples;

        switch (this.dataFormat) {
            case 'int16':
                bytesPerSample = 2;
                totalSamples = Math.floor((arrayBuffer.byteLength - headerSize) / (bytesPerSample * 2));

                for (let i = 0; i < totalSamples; i++) {
                    const offset = headerSize + i * 4;
                    const iValue = dataView.getInt16(offset, isLittleEndian);
                    const qValue = dataView.getInt16(offset + 2, isLittleEndian);
                    resultData.i.push(iValue / 32768.0);
                    resultData.q.push(qValue / 32768.0);
                }
                break;

            case 'float32':
                bytesPerSample = 4;
                totalSamples = Math.floor((arrayBuffer.byteLength - headerSize) / (bytesPerSample * 2));

                for (let i = 0; i < totalSamples; i++) {
                    const offset = headerSize + i * 8;
                    const iValue = dataView.getFloat32(offset, isLittleEndian);
                    const qValue = dataView.getFloat32(offset + 4, isLittleEndian);
                    resultData.i.push(iValue);
                    resultData.q.push(qValue);
                }
                break;

            default:
                console.error(`HT8200协议不支持的数据格式: ${this.dataFormat}`);
                return { i: [], q: [] };
        }

        return resultData;
    }

    /**
     * 解析自定义协议数据
     * @param {ArrayBuffer} arrayBuffer - 接收到的二进制数据
     * @returns {Object} 解析后的数据
     */
    parseCustomData(arrayBuffer) {
        const dataView = new DataView(arrayBuffer);
        const isLittleEndian = this.endianness === 'little';

        // 获取自定义协议配置
        const { headerSize, dataMarker } = this.customProtocolConfig;

        // 如果有数据标记，检查标记
        if (dataMarker && dataMarker.length > 0) {
            const markerBytes = this.hexStringToBytes(dataMarker);
            const headerBytes = new Uint8Array(arrayBuffer, 0, markerBytes.length);

            let markerValid = true;
            for (let i = 0; i < markerBytes.length; i++) {
                if (headerBytes[i] !== markerBytes[i]) {
                    markerValid = false;
                    break;
                }
            }

            if (!markerValid) {
                console.warn('自定义协议数据标记无效');
                return { i: [], q: [] };
            }
        }

        // 根据数据格式和头部大小解析IQ数据
        const resultData = {
            i: [],
            q: []
        };

        let bytesPerSample;
        let totalSamples;

        switch (this.dataFormat) {
            case 'int8':
                bytesPerSample = 1;
                totalSamples = Math.floor((arrayBuffer.byteLength - headerSize) / (bytesPerSample * 2));

                for (let i = 0; i < totalSamples; i++) {
                    const offset = headerSize + i * 2;
                    const iValue = dataView.getInt8(offset);
                    const qValue = dataView.getInt8(offset + 1);
                    resultData.i.push(iValue / 128.0);
                    resultData.q.push(qValue / 128.0);
                }
                break;

            case 'int16':
                bytesPerSample = 2;
                totalSamples = Math.floor((arrayBuffer.byteLength - headerSize) / (bytesPerSample * 2));

                for (let i = 0; i < totalSamples; i++) {
                    const offset = headerSize + i * 4;
                    const iValue = dataView.getInt16(offset, isLittleEndian);
                    const qValue = dataView.getInt16(offset + 2, isLittleEndian);
                    resultData.i.push(iValue / 32768.0);
                    resultData.q.push(qValue / 32768.0);
                }
                break;

            case 'float32':
                bytesPerSample = 4;
                totalSamples = Math.floor((arrayBuffer.byteLength - headerSize) / (bytesPerSample * 2));

                for (let i = 0; i < totalSamples; i++) {
                    const offset = headerSize + i * 8;
                    const iValue = dataView.getFloat32(offset, isLittleEndian);
                    const qValue = dataView.getFloat32(offset + 4, isLittleEndian);
                    resultData.i.push(iValue);
                    resultData.q.push(qValue);
                }
                break;

            default:
                console.error(`不支持的数据格式: ${this.dataFormat}`);
                return { i: [], q: [] };
        }

        return resultData;
    }

    /**
     * 发送命令
     * @param {Object} command - 命令对象
     * @returns {boolean} 是否成功发送
     */
    sendCommand(command) {
        if (!this.socket || !this.connected) {
            console.error('TCP客户端未连接');
            return false;
        }

        try {
            // 根据协议格式化命令
            const formattedCommand = this.formatCommand(command);

            // 发送数据
            this.socket.send(formattedCommand);
            return true;
        } catch (error) {
            console.error('发送命令失败:', error);
            return false;
        }
    }

    /**
     * 根据当前协议格式化命令
     * @param {Object} command - 命令对象
     * @returns {ArrayBuffer|string} 格式化后的命令
     */
    formatCommand(command) {
        // 获取协议，首选命令中的，否则使用当前设置
        const protocol = command.protocol || this.currentProtocol;

        // 使用相应的协议处理器
        if (this.protocolHandlers[protocol]) {
            return this.protocolHandlers[protocol](command);
        } else {
            return this.protocolHandlers.standard(command);
        }
    }

    /**
     * 处理标准协议
     * @param {Object} command - 命令对象
     * @returns {string} 格式化后的命令
     */
    handleStandardProtocol(command) {
        return JSON.stringify(command);
    }

    /**
     * 处理中科芯源GE7800协议
     * @param {Object} command - 命令对象
     * @returns {ArrayBuffer} 格式化后的命令
     */
    handleGE7800Protocol(command) {
        // GE7800协议格式:
        // 头部: [0xAA, 0xBB, 0xCC, 0xDD, cmd_type(1), cmd_length(2), cas_id(2)]
        // 数据部分: 命令特定数据
        // 尾部: 2字节校验和

        const casId = parseInt(command.casId || '0001', 16);
        const cmdType = this.getGE7800CommandType(command.command);

        // 准备命令数据
        let data;
        switch (command.command) {
            case 'configure':
                data = this.prepareGE7800ConfigCommand(command);
                break;
            case 'startStream':
                data = this.prepareGE7800StartStreamCommand(command);
                break;
            case 'stopStream':
                data = this.prepareGE7800StopStreamCommand();
                break;
            case 'getInfo':
                data = this.prepareGE7800InfoCommand();
                break;
            default:
                data = new Uint8Array(0);
                break;
        }

        // 计算命令长度
        const cmdLength = data.length;

        // 创建命令缓冲区 (头部 + 数据 + 校验和)
        const buffer = new ArrayBuffer(9 + cmdLength + 2);
        const view = new DataView(buffer);
        const bytes = new Uint8Array(buffer);

        // 写入头部
        bytes[0] = 0xAA;
        bytes[1] = 0xBB;
        bytes[2] = 0xCC;
        bytes[3] = 0xDD;
        bytes[4] = cmdType;
        view.setUint16(5, cmdLength, true);
        view.setUint16(7, casId, true);

        // 写入数据
        bytes.set(data, 9);

        // 计算并写入校验和 (所有数据的简单和)
        let checksum = 0;
        for (let i = 0; i < 9 + cmdLength; i++) {
            checksum += bytes[i];
        }
        view.setUint16(9 + cmdLength, checksum & 0xFFFF, true);

        return buffer;
    }

    /**
     * 获取GE7800命令类型
     * @param {string} command - 命令
     * @returns {number} 命令类型值
     */
    getGE7800CommandType(command) {
        switch (command) {
            case 'configure': return 0x01;
            case 'startStream': return 0x02;
            case 'stopStream': return 0x03;
            case 'getInfo': return 0x04;
            default: return 0x00;
        }
    }

    /**
     * 准备GE7800配置命令数据
     * @param {Object} command - 命令对象
     * @returns {Uint8Array} 命令数据
     */
    prepareGE7800ConfigCommand(command) {
        // 配置命令格式:
        // centerFrequency(8), sampleRate(4), gainMode(1), gainValue(1), bandwidth(4)

        const buffer = new ArrayBuffer(18);
        const view = new DataView(buffer);

        // 写入参数
        view.setFloat64(0, command.centerFrequency || 1500e6, true);
        view.setUint32(8, command.sampleRate || 61.44e6, true);
        view.setUint8(12, command.gainMode === 'manual' ? 1 : 0);
        view.setUint8(13, command.gainValue || 0);
        view.setUint32(14, command.bandwidth || 250e6, true);

        return new Uint8Array(buffer);
    }

    /**
     * 准备GE7800开始流命令数据
     * @param {Object} command - 命令对象
     * @returns {Uint8Array} 命令数据
     */
    prepareGE7800StartStreamCommand(command) {
        // 开始流命令格式:
        // bufferSize(4), hwDecode(1)

        const buffer = new ArrayBuffer(5);
        const view = new DataView(buffer);

        // 写入参数
        view.setUint32(0, command.bufferSize || 16384, true);
        view.setUint8(4, command.hwDecode ? 1 : 0);

        return new Uint8Array(buffer);
    }

    /**
     * 准备GE7800停止流命令数据
     * @returns {Uint8Array} 命令数据
     */
    prepareGE7800StopStreamCommand() {
        // 停止流命令没有额外参数
        return new Uint8Array(0);
    }

    /**
     * 准备GE7800信息命令数据
     * @returns {Uint8Array} 命令数据
     */
    prepareGE7800InfoCommand() {
        // 获取信息命令没有额外参数
        return new Uint8Array(0);
    }

    /**
     * 处理天奥电子TA8030协议
     * @param {Object} command - 命令对象
     * @returns {ArrayBuffer} 格式化后的命令
     */
    handleTA8030Protocol(command) {
        // TA8030协议格式:
        // 头部: [0xA0, 0x00, 0x00, 0x00, cmd_id(1), cmd_length(2), device_id(1)]
        // 数据部分: 命令特定数据

        const deviceId = command.deviceId || 1;
        const cmdId = this.getTA8030CommandId(command.command);

        // 准备命令数据
        let data;
        switch (command.command) {
            case 'configure':
                data = this.prepareTA8030ConfigCommand(command);
                break;
            case 'startStream':
                data = this.prepareTA8030StartStreamCommand(command);
                break;
            case 'stopStream':
                data = this.prepareTA8030StopStreamCommand();
                break;
            case 'getInfo':
                data = this.prepareTA8030InfoCommand();
                break;
            default:
                data = new Uint8Array(0);
                break;
        }

        // 计算命令长度
        const cmdLength = data.length;

        // 创建命令缓冲区 (头部 + 数据)
        const buffer = new ArrayBuffer(8 + cmdLength);
        const view = new DataView(buffer);
        const bytes = new Uint8Array(buffer);

        // 写入头部
        bytes[0] = 0xA0;
        bytes[1] = 0x00;
        bytes[2] = 0x00;
        bytes[3] = 0x00;
        bytes[4] = cmdId;
        view.setUint16(5, cmdLength, true);
        bytes[7] = deviceId;

        // 写入数据
        bytes.set(data, 8);

        return buffer;
    }

    /**
     * 获取TA8030命令ID
     * @param {string} command - 命令
     * @returns {number} 命令ID值
     */
    getTA8030CommandId(command) {
        switch (command) {
            case 'configure': return 0x10;
            case 'startStream': return 0x20;
            case 'stopStream': return 0x21;
            case 'getInfo': return 0x30;
            default: return 0x00;
        }
    }

    /**
     * 准备TA8030配置命令数据
     * @param {Object} command - 命令对象
     * @returns {Uint8Array} 命令数据
     */
    prepareTA8030ConfigCommand(command) {
        // 配置命令格式 (参考天奥电子TA8030规格):
        // centerFrequency(8), sampleRate(4), gainMode(1), gainValue(1), bandwidth(4), autoAck(1)

        const buffer = new ArrayBuffer(19);
        const view = new DataView(buffer);

        // 写入参数
        view.setFloat64(0, command.centerFrequency || 1500e6, true);
        view.setUint32(8, command.sampleRate || 61.44e6, true);
        view.setUint8(12, command.gainMode === 'manual' ? 1 : 0);
        view.setUint8(13, command.gainValue || 0);
        view.setUint32(14, command.bandwidth || 250e6, true);
        view.setUint8(18, command.autoAck ? 1 : 0);

        return new Uint8Array(buffer);
    }

    /**
     * 准备TA8030开始流命令数据
     * @param {Object} command - 命令对象
     * @returns {Uint8Array} 命令数据
     */
    prepareTA8030StartStreamCommand(command) {
        // 开始流命令格式:
        // bufferSize(4)

        const buffer = new ArrayBuffer(4);
        const view = new DataView(buffer);

        // 写入参数
        view.setUint32(0, command.bufferSize || 16384, true);

        return new Uint8Array(buffer);
    }

    /**
     * 准备TA8030停止流命令数据
     * @returns {Uint8Array} 命令数据
     */
    prepareTA8030StopStreamCommand() {
        // 停止流命令没有额外参数
        return new Uint8Array(0);
    }

    /**
     * 准备TA8030信息命令数据
     * @returns {Uint8Array} 命令数据
     */
    prepareTA8030InfoCommand() {
        // 获取信息命令没有额外参数
        return new Uint8Array(0);
    }

    /**
     * 处理航天宏图HT8200协议
     * @param {Object} command - 命令对象
     * @returns {ArrayBuffer} 格式化后的命令
     */
    handleHT8200Protocol(command) {
        // HT8200协议格式:
        // 头部: [0x48, 0x54, 0x82, 0x00, cmd_code(4), data_length(4)]
        // 数据部分: 命令特定数据

        const cmdCode = this.getHT8200CommandCode(command.command);

        // 准备命令数据
        let data;
        switch (command.command) {
            case 'configure':
                data = this.prepareHT8200ConfigCommand(command);
                break;
            case 'startStream':
                data = this.prepareHT8200StartStreamCommand(command);
                break;
            case 'stopStream':
                data = this.prepareHT8200StopStreamCommand();
                break;
            case 'getInfo':
                data = this.prepareHT8200InfoCommand();
                break;
            default:
                data = new Uint8Array(0);
                break;
        }

        // 计算命令长度
        const dataLength = data.length;

        // 创建命令缓冲区 (头部 + 数据)
        const buffer = new ArrayBuffer(12 + dataLength);
        const view = new DataView(buffer);
        const bytes = new Uint8Array(buffer);

        // 写入头部
        bytes[0] = 0x48; // H
        bytes[1] = 0x54; // T
        bytes[2] = 0x82; // 0x82
        bytes[3] = 0x00; // 0x00
        view.setUint32(4, cmdCode, true);
        view.setUint32(8, dataLength, true);

        // 写入数据
        bytes.set(data, 12);

        return buffer;
    }

    /**
     * 获取HT8200命令代码
     * @param {string} command - 命令
     * @returns {number} 命令代码值
     */
    getHT8200CommandCode(command) {
        switch (command) {
            case 'configure': return 0x00010001;
            case 'startStream': return 0x00010002;
            case 'stopStream': return 0x00010003;
            case 'getInfo': return 0x00010004;
            default: return 0x00000000;
        }
    }

    /**
     * 准备HT8200配置命令数据
     * @param {Object} command - 命令对象
     * @returns {Uint8Array} 命令数据
     */
    prepareHT8200ConfigCommand(command) {
        // 配置命令格式 (航天宏图HT8200规格):
        // centerFrequency(8), sampleRate(4), gainMode(1), gainValue(1), bandwidth(4),
        // transferMode(1), reserved(5)

        const buffer = new ArrayBuffer(24);
        const view = new DataView(buffer);

        // 写入参数
        view.setFloat64(0, command.centerFrequency || 1500e6, true);
        view.setUint32(8, command.sampleRate || 61.44e6, true);
        view.setUint8(12, command.gainMode === 'manual' ? 1 : 0);
        view.setUint8(13, command.gainValue || 0);
        view.setUint32(14, command.bandwidth || 250e6, true);
        view.setUint8(18, command.transferMode === 'packet' ? 1 : 0);
        // 保留5个字节

        return new Uint8Array(buffer);
    }

    /**
     * 准备HT8200开始流命令数据
     * @param {Object} command - 命令对象
     * @returns {Uint8Array} 命令数据
     */
    prepareHT8200StartStreamCommand(command) {
        // 开始流命令格式:
        // bufferSize(4), chunkSize(4)

        const buffer = new ArrayBuffer(8);
        const view = new DataView(buffer);

        // 写入参数
        view.setUint32(0, command.bufferSize || 16384, true);
        view.setUint32(4, command.chunkSize || 8192, true);

        return new Uint8Array(buffer);
    }

    /**
     * 准备HT8200停止流命令数据
     * @returns {Uint8Array} 命令数据
     */
    prepareHT8200StopStreamCommand() {
        // 停止流命令没有额外参数
        return new Uint8Array(0);
    }

    /**
     * 准备HT8200信息命令数据
     * @returns {Uint8Array} 命令数据
     */
    prepareHT8200InfoCommand() {
        // 获取信息命令没有额外参数
        return new Uint8Array(0);
    }

    /**
     * 处理自定义协议
     * @param {Object} command - 命令对象
     * @returns {ArrayBuffer} 格式化后的命令
     */
    handleCustomProtocol(command) {
        // 获取自定义协议配置
        const { headerSize, commandSequence, dataMarker, sizeOffset } = this.customProtocolConfig;

        // 准备命令数据
        let data;
        switch (command.command) {
            case 'configure':
                data = this.prepareCustomConfigCommand(command);
                break;
            case 'startStream':
                data = this.prepareCustomStartStreamCommand(command);
                break;
            case 'stopStream':
                data = this.prepareCustomStopStreamCommand();
                break;
            case 'getInfo':
                data = this.prepareCustomInfoCommand();
                break;
            default:
                data = new Uint8Array(0);
                break;
        }

        // 计算命令长度
        const dataLength = data.length;

        // 创建命令缓冲区 (头部 + 数据)
        const buffer = new ArrayBuffer(headerSize + dataLength);
        const view = new DataView(buffer);
        const bytes = new Uint8Array(buffer);

        // 写入命令序列
        if (commandSequence && commandSequence.length > 0) {
            const seqLength = Math.min(commandSequence.length, headerSize);
            for (let i = 0; i < seqLength; i++) {
                bytes[i] = commandSequence[i];
            }
        }

        // 如果有数据标记，写入数据标记
        if (dataMarker && dataMarker.length > 0) {
            const markerBytes = this.hexStringToBytes(dataMarker);
            const markerLength = Math.min(markerBytes.length, headerSize);
            for (let i = 0; i < markerLength; i++) {
                bytes[i] = markerBytes[i];
            }
        }

        // 如果有大小偏移，写入数据长度
        if (sizeOffset >= 0 && sizeOffset < headerSize - 3) {
            view.setUint32(sizeOffset, dataLength, true);
        }

        // 写入数据
        bytes.set(data, headerSize);

        return buffer;
    }

    /**
     * 准备自定义配置命令数据
     * @param {Object} command - 命令对象
     * @returns {Uint8Array} 命令数据
     */
    prepareCustomConfigCommand(command) {
        // 配置命令格式 (通用):
        // centerFrequency(8), sampleRate(4), gainMode(1), gainValue(1), bandwidth(4)

        const buffer = new ArrayBuffer(18);
        const view = new DataView(buffer);

        // 写入参数
        view.setFloat64(0, command.centerFrequency || 1500e6, true);
        view.setUint32(8, command.sampleRate || 61.44e6, true);
        view.setUint8(12, command.gainMode === 'manual' ? 1 : 0);
        view.setUint8(13, command.gainValue || 0);
        view.setUint32(14, command.bandwidth || 250e6, true);

        return new Uint8Array(buffer);
    }

    /**
     * 准备自定义开始流命令数据
     * @param {Object} command - 命令对象
     * @returns {Uint8Array} 命令数据
     */
    prepareCustomStartStreamCommand(command) {
        // 开始流命令格式:
        // bufferSize(4)

        const buffer = new ArrayBuffer(4);
        const view = new DataView(buffer);

        // 写入参数
        view.setUint32(0, command.bufferSize || 16384, true);

        return new Uint8Array(buffer);
    }

    /**
     * 准备自定义停止流命令数据
     * @returns {Uint8Array} 命令数据
     */
    prepareCustomStopStreamCommand() {
        // 停止流命令没有额外参数
        return new Uint8Array(0);
    }

    /**
     * 准备自定义信息命令数据
     * @returns {Uint8Array} 命令数据
     */
    prepareCustomInfoCommand() {
        // 获取信息命令没有额外参数
        return new Uint8Array(0);
    }

    /**
     * 将十六进制字符串转换为字节数组
     * @param {string} hexString - 十六进制字符串(例如 "AABB")
     * @returns {Uint8Array} 字节数组
     */
    hexStringToBytes(hexString) {
        if (!hexString) return new Uint8Array(0);

        // 移除所有空格
        const cleanHex = hexString.replace(/\s+/g, '');

        // 确保长度为偶数
        const paddedHex = cleanHex.length % 2 === 0 ? cleanHex : '0' + cleanHex;

        // 创建字节数组
        const bytes = new Uint8Array(paddedHex.length / 2);

        // 转换为字节
        for (let i = 0; i < bytes.length; i++) {
            bytes[i] = parseInt(paddedHex.substr(i * 2, 2), 16);
        }

        return bytes;
    }

    /**
     * 注册事件处理器
     * @param {string} eventName - 事件名
     * @param {Function} handler - 处理函数
     */
    on(eventName, handler) {
        if (this.eventHandlers[eventName]) {
            this.eventHandlers[eventName].push(handler);
        }
    }

    /**
     * 移除事件处理器
     * @param {string} eventName - 事件名
     * @param {Function} handler - 处理函数
     */
    off(eventName, handler) {
        if (this.eventHandlers[eventName]) {
            this.eventHandlers[eventName] = this.eventHandlers[eventName].filter(h => h !== handler);
        }
    }

    /**
     * 触发事件
     * @param {string} eventName - 事件名
     * @param {*} data - 事件数据
     * @private
     */
    triggerEvent(eventName, data) {
        if (this.eventHandlers[eventName]) {
            for (const handler of this.eventHandlers[eventName]) {
                try {
                    handler(data);
                } catch (error) {
                    console.error(`Error in ${eventName} event handler:`, error);
                }
            }
        }
    }
}