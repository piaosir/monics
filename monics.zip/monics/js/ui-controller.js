/**
 * UI控制器用于管理用户界面交互
 */

class UIController {
    constructor() {
        this.displays = {
            spectrum: null,
            waterfall: null,
            constellation: null,
            interference: null
        };

        this.activeView = 'spectrumView';
        this.device = null;
        this.carrierAnalyzer = null;
        this.modulationAnalyzer = null;

        // DOM元素
        this.elements = {
            connectionStatus: document.getElementById('connectionStatus'),
            deviceInfo: document.getElementById('deviceInfo'),
            centerFreqDisplay: document.getElementById('centerFreqDisplay'),
            spanFreqDisplay: document.getElementById('spanFreqDisplay'),
            rbwDisplay: document.getElementById('rbwDisplay'),
            snrDisplay: document.getElementById('snrDisplay'),
            esn0Display: document.getElementById('esn0Display'),
            cnDisplay: document.getElementById('cnDisplay'),
            markerList: document.getElementById('markerList'),
            modal: document.getElementById('modal'),
            modalTitle: document.getElementById('modal-title'),
            modalContent: document.getElementById('modal-content'),
            notification: document.getElementById('notification')
        };

        // 初始化显示组件
        this.initDisplays();

        // 初始化事件监听器
        this.initEventListeners();
    }

    /**
     * 初始化频谱和其他显示组件
     */
    initDisplays() {
        this.displays.spectrum = new SpectrumDisplay('spectrumCanvas');
        this.displays.waterfall = new WaterfallDisplay('waterfallCanvas');
        this.displays.constellation = new ConstellationDisplay('constellationCanvas');
        this.displays.interference = new InterferenceAnalyzer('interferenceCanvas');
    }

    /**
     * 设置设备对象
     * @param {SDRDevice} device - SDR设备对象
     */
    setDevice(device) {
        this.device = device;
    }

    /**
     * 设置载波分析器
     * @param {CarrierAnalyzer} analyzer - 载波分析器对象
     */
    setCarrierAnalyzer(analyzer) {
        this.carrierAnalyzer = analyzer;
    }

    /**
     * 设置调制分析器
     * @param {ModulationAnalyzer} analyzer - 调制分析器对象
     */
    setModulationAnalyzer(analyzer) {
        this.modulationAnalyzer = analyzer;
    }

    /**
     * 初始化UI控制事件监听器
     */
    initEventListeners() {
        // 视图标签
        document.getElementById('spectrumView').addEventListener('click', () => this.switchView('spectrumView'));
        document.getElementById('waterfallView').addEventListener('click', () => this.switchView('waterfallView'));
        document.getElementById('constellationView').addEventListener('click', () => this.switchView('constellationView'));
        document.getElementById('interferenceView').addEventListener('click', () => this.switchView('interferenceView'));
        document.getElementById('settingsView').addEventListener('click', () => this.switchView('settingsView'));

        // 频率控制
        document.getElementById('centerFreq').addEventListener('change', (e) => {
            const value = parseFloat(e.target.value);
            if (this.device) {
                this.device.setCenterFrequency(value).then(() => {
                    this.updateFrequencyDisplay();
                });
            }
        });

        document.getElementById('spanFreq').addEventListener('change', (e) => {
            const value = parseFloat(e.target.value);
            if (this.device) {
                this.device.setBandwidth(value).then(() => {
                    this.updateFrequencyDisplay();
                });
            }
        });

        document.getElementById('resolution').addEventListener('change', (e) => {
            this.updateFrequencyDisplay();
        });

        // 显示设置
        document.getElementById('displayMode').addEventListener('change', (e) => {
            if (this.displays.spectrum) {
                this.displays.spectrum.setDisplayMode(e.target.value);
            }
        });

        document.getElementById('dynamicRange').addEventListener('change', (e) => {
            const value = parseFloat(e.target.value);
            if (this.displays.spectrum) {
                this.displays.spectrum.setDynamicRange(value);
            }
            if (this.displays.waterfall) {
                this.displays.waterfall.setDynamicRange(value);
            }
        });

        document.getElementById('referenceLevel').addEventListener('change', (e) => {
            const value = parseFloat(e.target.value);
            if (this.displays.spectrum) {
                this.displays.spectrum.setReferenceLevel(value);
            }
            if (this.displays.waterfall) {
                this.displays.waterfall.setReferenceLevel(value);
            }
        });

        // 分析按钮
        document.getElementById('carrierBtn').addEventListener('click', () => this.showCarrierAnalysis());
        document.getElementById('interferenceBtn').addEventListener('click', () => this.switchView('interferenceView'));
        document.getElementById('modulationBtn').addEventListener('click', () => this.showModulationAnalysis());
        document.getElementById('recordBtn').addEventListener('click', () => this.showRecordingDialog());

        // 设备设置
        document.getElementById('sampleRate').addEventListener('change', (e) => {
            const value = parseFloat(e.target.value);
            if (this.device) {
                this.device.setSampleRate(value).then(() => {
                    this.updateDeviceInfo();
                });
            }
        });

        document.getElementById('gainMode').addEventListener('change', (e) => {
            if (this.device) {
                this.device.setGainMode(e.target.value).then(() => {
                    this.updateGainControls();
                });
            }
        });

        document.getElementById('gainValue').addEventListener('input', (e) => {
            document.getElementById('gainValueDisplay').textContent = `${e.target.value} dB`;
        });

        document.getElementById('gainValue').addEventListener('change', (e) => {
            const value = parseFloat(e.target.value);
            if (this.device) {
                this.device.setGainValue(value);
            }
        });

        // 标记控制
        document.getElementById('addMarkerBtn').addEventListener('click', () => this.addMarker());
        document.getElementById('peakSearchBtn').addEventListener('click', () => this.addPeakMarker());
        document.getElementById('clearMarkersBtn').addEventListener('click', () => this.clearMarkers());

        // 设置视图
        document.getElementById('connectBtn').addEventListener('click', () => this.connectDevice());
        document.getElementById('exportBtn').addEventListener('click', () => this.exportData());

        // 模态框关闭
        document.querySelector('.close').addEventListener('click', () => this.closeModal());
        // 频宽选择变化处理
        document.getElementById('spanFreq').addEventListener('change', (e) => {
            const value = e.target.value;
            if (value === 'custom') {
                document.getElementById('customSpanControl').style.display = 'block';
            } else {
                document.getElementById('customSpanControl').style.display = 'none';
                const span = parseFloat(value);
                if (this.device) {
                    this.device.setBandwidth(span).then(() => {
                        this.updateFrequencyDisplay();
                        this.updateRbwVbw();
                    });
                }
            }
        });

        // 自定义频宽处理
        document.getElementById('customSpan').addEventListener('change', (e) => {
            const span = parseFloat(e.target.value);
            if (this.device && span >= CONFIG.BANDWIDTH.MIN_BANDWIDTH && span <= CONFIG.BANDWIDTH.MAX_BANDWIDTH) {
                this.device.setBandwidth(span).then(() => {
                    this.updateFrequencyDisplay();
                    this.updateRbwVbw();
                });
            }
        });

        // RBW选择变化处理
        document.getElementById('rbwSelect').addEventListener('change', (e) => {
            const value = e.target.value;
            if (value === 'custom') {
                document.getElementById('customRbwControl').style.display = 'block';
                CONFIG.BANDWIDTH.AUTO_RBW = false;
            } else if (value === 'auto') {
                document.getElementById('customRbwControl').style.display = 'none';
                CONFIG.BANDWIDTH.AUTO_RBW = true;
                this.updateRbwVbw();
            } else {
                document.getElementById('customRbwControl').style.display = 'none';
                CONFIG.BANDWIDTH.AUTO_RBW = false;
                CONFIG.BANDWIDTH.DEFAULT_RBW = parseFloat(value);
                this.updateRbwVbw();
            }
        });

        // 自定义RBW处理
        document.getElementById('customRbw').addEventListener('change', (e) => {
            const rbw = parseFloat(e.target.value);
            if (rbw > 0) {
                CONFIG.BANDWIDTH.AUTO_RBW = false;
                CONFIG.BANDWIDTH.DEFAULT_RBW = rbw;
                this.updateRbwVbw();
            }
        });

        // VBW选择变化处理
        document.getElementById('vbwSelect').addEventListener('change', (e) => {
            const value = e.target.value;
            if (value === 'custom') {
                document.getElementById('customVbwControl').style.display = 'block';
                CONFIG.BANDWIDTH.AUTO_VBW = false;
            } else if (value === 'auto') {
                document.getElementById('customVbwControl').style.display = 'none';
                CONFIG.BANDWIDTH.AUTO_VBW = true;
                this.updateRbwVbw();
            } else {
                document.getElementById('customVbwControl').style.display = 'none';
                CONFIG.BANDWIDTH.AUTO_VBW = false;
                CONFIG.BANDWIDTH.DEFAULT_VBW = parseFloat(value);
                this.updateRbwVbw();
            }
        });

        // 自定义VBW处理
        document.getElementById('customVbw').addEventListener('change', (e) => {
            const vbw = parseFloat(e.target.value);
            if (vbw > 0) {
                CONFIG.BANDWIDTH.AUTO_VBW = false;
                CONFIG.BANDWIDTH.DEFAULT_VBW = vbw;
                this.updateRbwVbw();
            }
        });

        // VBW/RBW比例变化处理
        document.getElementById('vbwRbwRatio').addEventListener('change', (e) => {
            CONFIG.BANDWIDTH.VBW_RBW_RATIO = parseFloat(e.target.value);
            if (CONFIG.BANDWIDTH.AUTO_VBW) {
                this.updateRbwVbw();
            }
        });
        // 窗口大小调整处理
        window.addEventListener('resize', () => this.handleResize());
    }

    /**
     * 切换不同视图
     * @param {string} viewId - 要切换到的视图ID
     */
    switchView(viewId) {
        // 更新活动标签
        const tabs = document.querySelectorAll('nav ul li a');
        tabs.forEach(tab => {
            tab.classList.remove('active');
            if (tab.id === viewId) {
                tab.classList.add('active');
            }
        });

        // 隐藏所有显示
        const displays = document.querySelectorAll('.display');
        displays.forEach(display => {
            display.classList.remove('active');
        });

        // 显示选定的显示
        const displayId = viewId.replace('View', '-display');
        document.getElementById(displayId).classList.add('active');

        // 存储活动视图
        this.activeView = viewId;
    }
    updateRbwVbw() {
        if (!this.device) return;

        const settings = this.device.getSettings();
        const fftSize = parseInt(document.getElementById('fftSize').value);
        const windowType = document.getElementById('windowType').value;

        // 计算默认RBW (基于采样率和FFT大小)
        const defaultRbw = DSPUtils.calculateRBW(settings.sampleRate * 1e6, fftSize, windowType) / 1000;

        // 如果启用自动RBW，使用计算的默认值
        let rbw = CONFIG.BANDWIDTH.AUTO_RBW ? defaultRbw : CONFIG.BANDWIDTH.DEFAULT_RBW;

        // 如果启用自动VBW，根据比例计算VBW
        let vbw = CONFIG.BANDWIDTH.AUTO_VBW ?
            rbw * CONFIG.BANDWIDTH.VBW_RBW_RATIO :
            CONFIG.BANDWIDTH.DEFAULT_VBW;

        // 更新显示
        this.elements.rbwDisplay.textContent = `${rbw.toFixed(3)} kHz`;
        this.elements.vbwDisplay.textContent = `${vbw.toFixed(3)} kHz`;

        // 更新DSP处理参数
        if (this.device.dspProcessor) {
            this.device.dspProcessor.setRBW(rbw * 1000); // 转换为Hz
            this.device.dspProcessor.setVBW(vbw * 1000); // 转换为Hz
        }

        // 如果频谱显示存在，更新其RBW和VBW设置
        if (this.displays.spectrum) {
            this.displays.spectrum.setRBW(rbw * 1000);
            this.displays.spectrum.setVBW(vbw * 1000);
        }
    }
    /**
     * 更新频率显示信息
     */
    updateFrequencyDisplay() {
        if (!this.device) return;

        const settings = this.device.getSettings();

        // 更新中心频率
        this.elements.centerFreqDisplay.textContent = `${settings.centerFreq.toFixed(3)} MHz`;

        // 更新频宽
        this.elements.spanFreqDisplay.textContent = `${settings.bandwidth.toFixed(3)} MHz`;

        // 更新RBW和VBW
        this.updateRbwVbw();
    }

    /**
     * 更新设备信息显示
     */
    updateDeviceInfo() {
        if (!this.device) return;

        const settings = this.device.getSettings();
        this.elements.deviceInfo.textContent = `${settings.deviceType} | ${settings.sampleRate} MSPS`;
    }

    /**
     * 根据增益模式更新增益控制
     */
    updateGainControls() {
        const gainMode = document.getElementById('gainMode').value;
        const gainSlider = document.getElementById('gainValue');
        const gainDisplay = document.getElementById('gainValueDisplay');

        if (gainMode === 'auto') {
            gainSlider.disabled = true;
            gainDisplay.classList.add('disabled');
        } else {
            gainSlider.disabled = false;
            gainDisplay.classList.remove('disabled');
        }
    }

    /**
     * 连接到设备
     */
    connectDevice() {
        const deviceType = document.getElementById('deviceType').value;
        const apiEndpoint = document.getElementById('apiEndpoint').value;
        const websocketEndpoint = document.getElementById('websocketEndpoint').value;

        // 更新API端点
        CONFIG.API_ENDPOINT = apiEndpoint;
        CONFIG.WEBSOCKET_ENDPOINT = websocketEndpoint;

        // 显示连接状态
        this.elements.connectionStatus.textContent = '连接中...';
        this.elements.connectionStatus.className = 'connecting';

        // 初始化API客户端
        apiClient.initialize().then(success => {
            if (success) {
                // 初始化设备
                this.device.initialize(deviceType).then(deviceSuccess => {
                    if (deviceSuccess) {
                        this.elements.connectionStatus.textContent = '已连接';
                        this.elements.connectionStatus.className = 'connected';
                        this.updateDeviceInfo();
                        this.updateFrequencyDisplay();
                        this.showNotification('成功连接到设备', 'success');
                    } else {
                        this.elements.connectionStatus.textContent = '设备错误';
                        this.elements.connectionStatus.className = 'disconnected';
                        this.showNotification('设备初始化失败', 'error');
                    }
                });
            } else {
                this.elements.connectionStatus.textContent = '已断开';
                this.elements.connectionStatus.className = 'disconnected';
                this.showNotification('无法连接到API服务器', 'error');
            }
        });
    }

    /**
     * 在中心频率添加新标记
     */
    addMarker() {
        if (!this.displays.spectrum) return;

        if (!this.device) return;

        const settings = this.device.getSettings();
        const centerFreq = settings.centerFreq * 1e6;

        const marker = this.displays.spectrum.addMarker(centerFreq);
        if (marker) {
            this.updateMarkerList();
        } else {
            this.showNotification('已达到最大标记数量', 'warning');
        }
    }

    /**
     * 在峰值信号处添加标记
     */
    addPeakMarker() {
        if (!this.displays.spectrum) return;

        const marker = this.displays.spectrum.addPeakMarker();
        if (marker) {
            this.updateMarkerList();
        } else {
            this.showNotification('无可用频谱数据或已达最大标记数', 'warning');
        }
    }

    /**
     * 清除所有标记
     */
    clearMarkers() {
        if (!this.displays.spectrum) return;

        this.displays.spectrum.clearMarkers();
        this.updateMarkerList();
    }

    /**
     * 在UI中更新标记列表
     */
    updateMarkerList() {
        if (!this.displays.spectrum || !this.elements.markerList) return;

        const markers = this.displays.spectrum.getMarkerData();

        // 清除当前列表
        this.elements.markerList.innerHTML = '';

        // 添加标记项
        markers.forEach((marker, index) => {
            const markerDiv = document.createElement('div');
            markerDiv.className = 'marker-item';

            const nameSpan = document.createElement('span');
            nameSpan.textContent = `M${index + 1}: ${marker.frequencyText}, ${marker.powerText}`;

            const deleteBtn = document.createElement('span');
            deleteBtn.className = 'marker-delete';
            deleteBtn.innerHTML = '&times;';
            deleteBtn.addEventListener('click', () => {
                this.displays.spectrum.removeMarker(marker.id);
                this.updateMarkerList();
            });

            markerDiv.appendChild(nameSpan);
            markerDiv.appendChild(deleteBtn);
            this.elements.markerList.appendChild(markerDiv);
        });
    }

    /**
     * 显示载波分析模态框
     */
    showCarrierAnalysis() {
        if (!this.carrierAnalyzer) return;

        const carriers = this.carrierAnalyzer.getCarriers();

        if (carriers.length === 0) {
            this.showNotification('未检测到载波', 'warning');
            return;
        }

        // 设置模态框标题
        this.elements.modalTitle.textContent = '载波分析';

        // 创建内容
        let content = '<div class="carrier-list">';

        carriers.forEach((carrier, index) => {
            const analysis = this.carrierAnalyzer.getCarrierAnalysis(index);

            content += `
                <div class="carrier-item">
                    <h3>载波 ${index + 1}</h3>
                    <div class="carrier-details">
                        <div class="detail-row">
                            <span class="detail-label">频率:</span>
                            <span class="detail-value">${analysis.frequency}</span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">功率:</span>
                            <span class="detail-value">${analysis.power}</span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">带宽:</span>
                            <span class="detail-value">${analysis.bandwidth}</span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">符号率:</span>
                            <span class="detail-value">${analysis.symbolRate}</span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">调制类型:</span>
                            <span class="detail-value">${analysis.modulation}</span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">信噪比:</span>
                            <span class="detail-value">${analysis.snr}</span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Es/N0:</span>
                            <span class="detail-value">${analysis.esn0}</span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">载噪比:</span>
                            <span class="detail-value">${analysis.cn}</span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">频率偏移:</span>
                            <span class="detail-value">${analysis.frequencyOffset}</span>
                        </div>
                    </div>
                </div>
            `;
        });

        content += '</div>';

        // 设置模态框内容
        this.elements.modalContent.innerHTML = content;

        // 显示模态框
        this.showModal();
    }

    /**
     * 显示调制分析模态框
     */
    showModulationAnalysis() {
        if (!this.modulationAnalyzer) return;

        const analysis = this.modulationAnalyzer.analyzeModulation();

        if (!analysis || !analysis.modulation) {
            this.showNotification('未检测到调制或数据不足', 'warning');
            return;
        }

        // 设置模态框标题
        this.elements.modalTitle.textContent = '调制分析';

        // 创建内容
        const content = `
            <div class="modulation-analysis">
                <div class="analysis-header">
                    <h3>检测到的调制类型: ${analysis.modulation}</h3>
                </div>
                <div class="analysis-details">
                    <div class="detail-row">
                        <span class="detail-label">误差矢量幅度(EVM):</span>
                        <span class="detail-value">${analysis.parameters.evm.toFixed(2)}%</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">信噪比:</span>
                        <span class="detail-value">${analysis.parameters.snr.toFixed(2)} dB</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">相位误差:</span>
                        <span class="detail-value">${(analysis.parameters.phaseError * 180 / Math.PI).toFixed(2)}°</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">频率误差:</span>
                        <span class="detail-value">${(analysis.parameters.frequencyError / 1000).toFixed(2)} kHz</span>
                    </div>
                </div>
                <div class="analysis-actions">
                    <button id="viewConstellation" class="settings-btn">查看星座图</button>
                </div>
            </div>
        `;

        // 设置模态框内容
        this.elements.modalContent.innerHTML = content;

        // 为星座图按钮添加事件监听器
        document.getElementById('viewConstellation').addEventListener('click', () => {
            this.closeModal();
            this.switchView('constellationView');
        });

        // 显示模态框
        this.showModal();
    }

    /**
     * 显示记录对话框
     */
    showRecordingDialog() {
        // 设置模态框标题
        this.elements.modalTitle.textContent = '记录IQ数据';

        // 创建内容
        const content = `
            <div class="recording-dialog">
                <div class="setting">
                    <label for="recordDuration">持续时间(秒):</label>
                    <input type="number" id="recordDuration" value="10" min="1" max="3600">
                </div>
                <div class="setting">
                    <label for="recordFilename">文件名:</label>
                    <input type="text" id="recordFilename" value="iq_recording_${Date.now()}">
                </div>
                <div class="setting">
                    <label for="recordFormat">格式:</label>
                    <select id="recordFormat">
                        <option value="binary" selected>二进制(原始IQ)</option>
                        <option value="wav">WAV</option>
                        <option value="csv">CSV</option>
                    </select>
                </div>
                <div class="setting">
                    <button id="startRecording" class="settings-btn">开始记录</button>
                </div>
            </div>
        `;

        // 设置模态框内容
        this.elements.modalContent.innerHTML = content;

        // 为记录按钮添加事件监听器
        document.getElementById('startRecording').addEventListener('click', () => {
            const duration = parseInt(document.getElementById('recordDuration').value);
            const filename = document.getElementById('recordFilename').value;
            const format = document.getElementById('recordFormat').value;

            this.startRecording(duration, filename, format);
            this.closeModal();
        });

        // 显示模态框
        this.showModal();
    }

    /**
     * 开始记录IQ数据
     * @param {number} duration - 记录持续时间(秒)
     * @param {string} filename - 输出文件名
     * @param {string} format - 输出格式
     */
    startRecording(duration, filename, format) {
        // 在实际实现中，这会启动通过API记录数据
        this.showNotification(`记录开始: ${duration}秒, ${format}格式`, 'success');

        // 模拟记录进度
        let elapsed = 0;
        const interval = setInterval(() => {
            elapsed++;

            if (elapsed >= duration) {
                clearInterval(interval);
                this.showNotification(`记录完成: ${filename}.${format}`, 'success');
            } else {
                this.showNotification(`记录中: ${elapsed}/${duration}秒`, 'info');
            }
        }, 1000);
    }

    /**
     * 导出频谱数据
     */
    exportData() {
        const format = document.getElementById('exportFormat').value;

        // 在实际实现中，这会通过API导出数据
        this.showNotification(`正在导出${format}格式数据...`, 'info');

        // 模拟导出进度
        setTimeout(() => {
            this.showNotification(`数据导出成功: spectrum_${Date.now()}.${format}`, 'success');
        }, 2000);
    }

    /**
     * 显示模态对话框
     */
    showModal() {
        this.elements.modal.style.display = 'block';
    }

    /**
     * 关闭模态对话框
     */
    closeModal() {
        this.elements.modal.style.display = 'none';
    }

    /**
     * 显示通知消息
     * @param {string} message - 通知消息
     * @param {string} type - 通知类型 ('success', 'error', 'warning', 'info')
     */
    showNotification(message, type = 'info') {
        this.elements.notification.textContent = message;
        this.elements.notification.className = 'notification';
        this.elements.notification.classList.add(type);
        this.elements.notification.style.display = 'block';

        // 超时后隐藏通知
        setTimeout(() => {
            this.elements.notification.style.display = 'none';
        }, CONFIG.UI.NOTIFICATION_TIMEOUT);
    }

    /**
     * 处理窗口大小变化事件
     */
    handleResize() {
        // 根据需要调整活动显示的大小
        if (this.activeView === 'spectrumView' && this.displays.spectrum) {
            this.displays.spectrum.resizeCanvas();
        } else if (this.activeView === 'waterfallView' && this.displays.waterfall) {
            this.displays.waterfall.resizeCanvas();
        } else if (this.activeView === 'constellationView' && this.displays.constellation) {
            this.displays.constellation.resizeCanvas();
        } else if (this.activeView === 'interferenceView' && this.displays.interference) {
            this.displays.interference.resizeCanvas();
        }
    }

    /**
     * 更新测量显示
     * @param {Object} measurements - 测量数据
     */
    updateMeasurements(measurements) {
        if (!measurements) return;

        // 更新信噪比
        if (measurements.snr !== undefined) {
            this.elements.snrDisplay.textContent = `${measurements.snr.toFixed(1)} dB`;
        }

        // 更新Es/N0
        if (measurements.esn0 !== undefined) {
            this.elements.esn0Display.textContent = `${measurements.esn0.toFixed(1)} dB`;
        }

        // 更新C/N
        if (measurements.cn !== undefined) {
            this.elements.cnDisplay.textContent = `${measurements.cn.toFixed(1)} dB`;
        }
    }
}